# Coursework - References

1. Reference 1
https://docs.pytorch.org/docs/stable/generated/torch.nn.Conv2d.html
2. Reference 2
https://pytorch.org/docs/stable/generated/torch.nn.ConvTranspose2d.html
3. Reference 3
https://docs.pytorch.org/docs/stable/generated/torch.nn.L1Loss.html
4. Reference 4
https://docs.pytorch.org/docs/stable/generated/torch.optim.Adam.html
5. Reference 5
https://docs.pytorch.org/docs/stable/generated/torch.nn.BatchNorm2d.html

6. Reference 6
https://docs.pytorch.org/docs/stable/generated/torch.quantile.html
7. Reference 7
https://docs.pytorch.org/docs/stable/generated/torch.nn.MaxPool2d.html
8. Reference 8
https://docs.pytorch.org/docs/stable/generated/torch.nn.Conv1d.html
9. Reference 9
https://docs.pytorch.org/docs/stable/generated/torch.nn.CrossEntropyLoss.html
10. Reference 10
https://en.wikipedia.org/wiki/Electrocardiography
11. Reference 11
https://docs.pytorch.org/docs/stable/generated/torch.nn.Dropout.html
12. Reference 12
https://scikit-learn.org/stable/modules/generated/sklearn.metrics.confusion_matrix.html

generate AI tool: chatgpt5(open AI)
https://chatgpt.com/share/693c2995-5980-800d-9d17-072d20c81245