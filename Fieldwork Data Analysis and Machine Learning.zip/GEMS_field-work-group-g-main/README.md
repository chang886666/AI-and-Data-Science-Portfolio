# GEMS_field-work

To access the presentation recording follow the link below. The meeting is within the Group G sharepoint and should be downloadable as you are the owner of the channel.

Presentation Recording: https://imperiallondon.sharepoint.com/:v:/r/sites/GEMSfieldtrip202526-EA-GroupG/Shared%20Documents/Recordings/View%20Only/Meeting%20in%20Group%20G-20260508_163039-Meeting%20Recording.mp4?csf=1&web=1&e=f35J0m&nav=eyJyZWZlcnJhbEluZm8iOnsicmVmZXJyYWxBcHAiOiJTdHJlYW1XZWJBcHAiLCJyZWZlcnJhbFZpZXciOiJTaGFyZURpYWxvZy1MaW5rIiwicmVmZXJyYWxBcHBQbGF0Zm9ybSI6IldlYiIsInJlZmVycmFsTW9kZSI6InZpZXcifX0%3D
