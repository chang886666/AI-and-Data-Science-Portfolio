# References

Use this space to list any references such as books or websites you used to complete the assessment, such as links to documentation or forum posts (please link to the specific question). You do not need to list any materials provided as part of the NPP course.

If you used any Chat GPT sessions to help you, please link to the specific session (see https://help.openai.com/en/articles/7925741-chatgpt-shared-links-faq for details on how to do this).

If you used other AI tools (e.g. GitHub Copilot) then list the tool and explain exactly how it helped you (e.g. "I asked GitHub Copilot to generate a function to calculate the aritmetic-geoemtric mean of a list of numbers, and then modified the code to be able to work on a pandas DataFrame"). You should also include a comment in the appropriate place in your code to indicate where you used the tool.

You may delete the examples given when you make your own entries. If you did not use any reference of a particular type, you must write "None used" under the relevant heading, especially for Chat GPT and other AI tools.

### Websites
https://blog.csdn.net/qq_41854911/article/details/122696986?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522ee72430d95705bf174eabd1ff232c346%2522%252C%2522scm%2522%253A%252220140713.130102334..%2522%257D&request_id=ee72430d95705bf174eabd1ff232c346&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~top_positive~default-1-122696986-null-null.142^v102^pc_search_result_base6&utm_term=pandas%E6%95%99%E7%A8%8B&spm=1018.2226.3001.4187
#### Example:
- [Pandas Documentation](https://pandas.pydata.org/docs/)

### Books

### Videos

### Chat GPT Sessions
https://chatgpt.com/share/68e836e9-9164-800d-9f87-a048f7869c83
#### Example:

### Other AI Tools
