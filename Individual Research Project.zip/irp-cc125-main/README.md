# Statistical Downscaling of ERA5 Wind Speed over Scotland

[![Python 3.8](https://img.shields.io/badge/Python-3.8-3776AB.svg)](https://www.python.org/)
[![Data: Copernicus Climate Data Store](https://img.shields.io/badge/data-Copernicus%20CDS-005AA0.svg)](https://cds.climate.copernicus.eu/)

A reproducible research pipeline for bias-correcting and statistically
downscaling ERA5 10 m wind speed towards the higher-resolution Copernicus
European Regional ReAnalysis (CERRA) over Scotland.

The primary experiment evaluates 2,022 fixed Scottish land points. Models are
trained on 2016--2018 and tested on the untouched 2019--2020 period. CERRA is
used as the high-resolution reanalysis target; it is **not** treated as direct
observational ground truth.

## Results at a glance

| Method                                | Test RMSE (m s⁻¹) | Comparison with bilinear ERA5 |
| ------------------------------------- | ------------------: | ----------------------------: |
| Bilinearly interpolated ERA5          |               1.438 |                     Reference |
| Per-point, per-month quantile mapping |               0.936 |              34.9% lower RMSE |
| **XGBoost**                     |     **0.901** |    **37.3% lower RMSE** |

XGBoost reduced RMSE by 3.7% relative to the stronger quantile-mapping
baseline. These values apply only to the study domain, sampling design and
2019--2020 test period described here. Full interpretation is provided in the
[final report](deliverables/cc125-final-report.pdf).

## Study design

- **Domain:** 2,022 fixed land points on the CERRA grid over Scotland.
- **Predictand:** CERRA 10 m wind speed (`si10`).
- **Predictors:** bilinearly interpolated ERA5 wind speed, elevation, slope,
  hilliness, 5 km and 75 km terrain position indices, distance to coast, and
  sine/cosine encodings of calendar month.
- **Training period:** 2016--2018.
- **Independent temporal test:** 2019--2020.
- **Retained times:** 00:00 and 12:00 UTC. Source downloads contain all
  three-hourly analysis times; dataset construction selects these two times.
- **Models:** ordinary least squares, Random Forest and XGBoost.
- **Baselines:** bilinear ERA5 and per-point, per-month empirical quantile
  mapping fitted on training years only.
- **Model selection:** forward-chaining validation (2016 -> 2017 and
  2016--2017 -> 2018); the 2019--2020 test set is not used for tuning.
- **Spatial robustness check:** a deterministic stratified holdout of 405
  points, leaving 1,617 points for fitting.

## Repository layout

```text
.
├── environment.yml                 Conda environment used to reproduce the run
├── pyproject.toml                  Package metadata and CLI entry point
├── src/
│   ├── 00_check_data.py            Validate raw ERA5/CERRA inputs
│   ├── 01_process_terrain_scotland.py
│   ├── 02_build_dataset.py         Assemble paired train/test arrays
│   ├── 03a_validate_experiment.py  Validate inputs and write SHA-256 manifest
│   ├── 03b_tune_models.py          Forward-chaining model selection
│   ├── 03c_train_final_models.py   Fit selected RF and XGBoost models
│   ├── 03d_train_linear_baselines.py
│   ├── 04_evaluate_versioned.py
│   ├── 05a_block_permutation_importance.py
│   ├── 05b_versioned_ablation.py
│   ├── 05c_spatial_holdout_versioned.py
│   ├── 06_summarize_versioned_experiment.py
│   ├── 07_visualize_versioned_results.py
│   ├── run_projected_scotland_experiment.py
│   └── irp_cc125/                  Reusable installable package
├── tests/                          Package smoke tests
├── deliverables/                   Submitted report and project plan
├── logbook/                        Project record
└── title/                          Project-title metadata
```

The numbered scripts are explicit research-workflow stages. Reusable code is
kept in the `irp_cc125` package. Raw data, generated arrays, fitted models and
figures are excluded from Git because of their size.

## Data sources

| Source                          | Product used                                                                                                                                           | Variables / role                                                                  | Access                                                                                                                                        |
| ------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------ | --------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------- |
| Copernicus Climate Data Store   | [ERA5 hourly data on single levels](https://cds.climate.copernicus.eu/datasets/reanalysis-era5-single-levels) (`reanalysis-era5-single-levels`)       | `10m_u_component_of_wind`, `10m_v_component_of_wind`; converted to wind speed | CDS web form or`cdsapi`; DOI [10.24381/cds.adbb2d47](https://doi.org/10.24381/cds.adbb2d47)                                                  |
| Copernicus Climate Data Store   | [CERRA sub-daily data on single levels](https://cds.climate.copernicus.eu/datasets/reanalysis-cerra-single-levels) (`reanalysis-cerra-single-levels`) | `10m_wind_speed`, analysis product; modelling target                            | CDS web form or`cdsapi`; DOI [10.24381/cds.622a565a](https://doi.org/10.24381/cds.622a565a)                                                  |
| Copernicus Data Space Ecosystem | [Copernicus DEM GLO-30](https://dataspace.copernicus.eu/explore-data/data-collections/copernicus-contributing-missions/collections-description/COP-DEM) | Elevation GeoTIFF tiles used to derive terrain predictors                         | Copernicus Browser, OData API or S3; product identifier`COP-DEM_GLO-30-DGED`; DOI [10.5270/ESA-c5d3d65](https://doi.org/10.5270/ESA-c5d3d65) |
| Office for National Statistics  | [Countries (December 2023) Boundaries UK BGC](https://geoportal.statistics.gov.uk/datasets/ons::countries-december-2023-boundaries-uk-bgc)              | Scotland mask and dissolved UK land/coast boundary                                | ONS Open Geography Portal download/API; Open Government Licence v3.0                                                                          |

ERA5 is a global reanalysis on a regular latitude/longitude grid (the CDS
single-level reanalysis is supplied at 0.25-degree resolution). CERRA is a
European regional reanalysis on a Lambert conformal grid at approximately
5.5 km resolution. Their differing grids are handled explicitly during
dataset construction.

### Climate Data Store API access

1. Create or sign in to a [Climate Data Store account](https://cds.climate.copernicus.eu/).
2. Open both dataset pages above and accept their terms of use.
3. Follow the official [CDS API setup instructions](https://cds.climate.copernicus.eu/how-to-api).
4. Save the displayed personal token in `~/.cdsapirc`:

```yaml
url: https://cds.climate.copernicus.eu/api
key: <PERSONAL-ACCESS-TOKEN>
```

Never commit this token. The `cdsapi` client is included in `environment.yml`.

The experiment used the following logical selections for every month from
January 2016 through December 2020:

| Request field   | ERA5                                | CERRA                                                 |
| --------------- | ----------------------------------- | ----------------------------------------------------- |
| Dataset ID      | `reanalysis-era5-single-levels`   | `reanalysis-cerra-single-levels`                    |
| Product fields  | `product_type: reanalysis`        | `data_type: reanalysis`; `product_type: analysis` |
| Variable        | 10 m u- and v-components of wind    | 10 m wind speed                                       |
| Times requested | 00, 03, 06, 09, 12, 15, 18, 21 UTC  | Same                                                  |
| Years           | 2016--2020                          | 2016--2020                                            |
| ERA5 area       | North 61, West -9, South 49, East 3 | Full CERRA field; Scotland selected locally           |
| Local format    | One NetCDF file per month           | One NetCDF file per month                             |

The CDS download form can generate current API request code via **Show API
request code**. Prefer that generated request if the service schema changes.
The following one-month examples document the request structure used by this
study (repeat for each year/month and change the target filename):

```python
import cdsapi

client = cdsapi.Client()
days = [f"{day:02d}" for day in range(1, 32)]
times = [f"{hour:02d}:00" for hour in range(0, 24, 3)]

client.retrieve(
    "reanalysis-era5-single-levels",
    {
        "product_type": ["reanalysis"],
        "variable": [
            "10m_u_component_of_wind",
            "10m_v_component_of_wind",
        ],
        "year": ["2016"],
        "month": ["01"],
        "day": days,
        "time": times,
        "area": [61, -9, 49, 3],  # north, west, south, east
        "data_format": "netcdf",
    },
    "data/era5/era5_2016_01.nc",
)

client.retrieve(
    "reanalysis-cerra-single-levels",
    {
        "variable": ["10m_wind_speed"],
        "level_type": "surface_or_atmosphere",
        "data_type": ["reanalysis"],
        "product_type": "analysis",
        "year": ["2016"],
        "month": ["01"],
        "day": days,
        "time": times,
        "data_format": "netcdf",
    },
    "data/cerra/cerra_2016_01.nc",
)
```

For months shorter than January, generate only valid calendar days. If a
generated request differs, use the code produced by the current CDS form.

The local filenames expected by this project are:

```text
data/era5/era5_YYYY_MM.nc
data/cerra/cerra_YYYY_MM.nc
```

There must be 60 files for each reanalysis. The validation stage expects ERA5
variables `u10` and `v10`, and CERRA variable `si10`, in the resulting NetCDF
files. It also verifies the timestamps used by the experiment.

### Terrain and boundary data

Place the Copernicus DEM GLO-30 DGED tiles covering the study area under
`data/dem/` as GeoTIFF files. The terrain stage mosaics and reprojects them to
British National Grid (`EPSG:27700`) before deriving the six static terrain
features. Consult the current [Copernicus DEM access documentation](https://documentation.dataspace.copernicus.eu/Data/Others/CCM.html)
because registration and access procedures can change.

The boundary preprocessing used the complete four-country ONS BGC product,
not a Scotland-only export. UK polygons are dissolved so internal national
borders are not mistaken for coastline. When redistributing derived boundary
material, retain the attribution required by the
[ONS licensing guidance](https://www.ons.gov.uk/methodology/geography/licences).

## Required local inputs

Create the following structure before running the full workflow:

```text
data/
├── era5/
│   └── era5_YYYY_MM.nc              60 monthly files, 2016--2020
├── cerra/
│   └── cerra_YYYY_MM.nc             60 monthly files, 2016--2020
├── dem/
│   └── *.tif                        Copernicus DEM GLO-30 tiles
├── boundaries/
│   └── uk_land.gpkg                 Dissolved UK land polygon
└── processed/
    ├── land_lats.npy                Fixed 2,022-point sample
    ├── land_lons.npy
    └── land_indices.npy
```

### Important reproducibility boundary

The three fixed-point arrays in `data/processed/` define the exact 2,022-point
sample and its order. `01_process_terrain_scotland.py` validates and preserves
them; it does not create a new sample from scratch. They are excluded from Git
with the rest of `data/`. Reproducing the reported numerical results therefore
requires the original arrays (and matching source data), not merely a newly
sampled set of Scottish points. This constraint is stated explicitly to avoid
claiming bit-for-bit reproducibility from public downloads alone.

## Installation

[Miniforge](https://github.com/conda-forge/miniforge) or another Conda-compatible
distribution is recommended because Rasterio, Cartopy, GDAL, GEOS and PROJ
include compiled dependencies.

```bash
git clone https://github.com/ese-ada-lovelace-2025/irp-cc125.git
cd irp-cc125
conda env create -f environment.yml
conda activate irp-cc125
python -m pip install --no-deps -e .
```

Python, NumPy, scikit-learn, XGBoost and Joblib are pinned to the versions
recorded in the saved experiment provenance. The remaining data/geospatial
packages are resolved from `conda-forge` because their exact preprocessing
versions were not retained.

Confirm the installation without starting an experiment:

```bash
python -c "import irp_cc125; print(irp_cc125.__version__)"
```

## Running the workflow

All commands assume the repository root as the working directory.

Validate the raw monthly files first:

```bash
python src/00_check_data.py
```

Inspect the ordered 13-stage workflow without executing it:

```bash
python src/run_projected_scotland_experiment.py
```

Execute all stages only after the required inputs have been supplied:

```bash
python src/run_projected_scotland_experiment.py --run
```

Resume or restrict a run with inclusive stage boundaries:

```bash
python src/run_projected_scotland_experiment.py \
  --run \
  --start-at 03a_validate_experiment.py \
  --stop-after 04_evaluate_versioned.py
```

Model tuning, ablation and spatial-holdout stages are computationally and
memory intensive. Use the dry run above before execution. The orchestrator
stops immediately if any stage fails.

### Spatial-holdout workflow

After installation, inspect its options with:

```bash
irp-cc125-spatial-holdout --help
```

Equivalent script-level examples are:

```bash
python src/05c_spatial_holdout_versioned.py --validate-only
python src/05c_spatial_holdout_versioned.py --phase tune --n-jobs 8
python src/05c_spatial_holdout_versioned.py --phase fit-evaluate --n-jobs 8
```

## Generated outputs and provenance

The principal versioned output directory is:

```text
data/processed/experiments/projected_ons_bgc_v1/
├── experiment_manifest.json
├── tuning_results.json
├── model_metadata.json
├── evaluation_results.json
├── rf_model.joblib
├── xgb_model.joblib
├── figures/
├── tables/
└── spatial_holdout_v1/
```

Validation records array schemas, train/test years, software versions and
SHA-256 fingerprints. Later stages check these records before reusing tuning
or model artefacts. Random seeds and point splits are fixed where applicable.
Generated data and models remain untracked.

## Testing and packaging

Run the package smoke tests:

```bash
python -m pip install --no-deps -e ".[test]"
python -m pytest
```

Build an installable wheel without resolving dependencies again:

```bash
python -m pip wheel --no-deps --wheel-dir dist .
```

The wheel contains only `irp_cc125` package code and distribution metadata;
it does not include numbered pipeline scripts, raw data, results, reports or
local environments.

## Limitations

- Evaluation is against CERRA reanalysis rather than surface observations.
- Only 00:00 and 12:00 UTC are retained, so the full diurnal cycle is not
  represented in the main experiment.
- The primary temporal test uses locations also represented in training.
- The spatial experiment holds out stratified random points rather than a
  contiguous independent region.
- Findings are specific to Scotland, the fixed grid-point sample and the
  2016--2020 study period.
- The tracked repository does not contain the large source datasets or the
  fixed point-selection arrays needed for exact numerical reproduction.


## Project documents

- [Final report](deliverables/cc125-final-report.pdf)
- [Project plan](deliverables/cc125-project-plan.pdf)

