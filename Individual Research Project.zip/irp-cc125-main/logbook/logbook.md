# Logbook

Meeting (6 May 2026)

Present:  Warder, Simon C（Main supervisor）; Piggott, Matthew D（Second supervisor）; Retsou, Eirini; Cao, Chang; Kokkilagadda, Varun; Chen, Yuxin O;(students) Wang, Yan(Research Postgraduate); SINHA, ARUSHI(Research Postgraduate
)

Key points discussed:

This was a group meeting for students working on related IRP topics in the general area of wind/renewables, with machine learning involved in most projects.
Simon Warder introduced the background and structure of the projects, and clarified that my current project direction is the bias correction project.
The discussion covered the importance of starting from the literature and identifying papers that are relevant to each student’s own project direction.
Simon suggested that papers with accompanying datasets or software can be useful starting points, as they may provide practical examples or reproducible methods.
It was noted that the project direction may evolve as the literature review progresses, and that shifting to a slightly different but related direction is acceptable if it leads to a clearer and more manageable project.

Feedback received:

Matthew Piggott emphasised that the project should be something I genuinely understand, including why I am doing it and how the methods work.
He highlighted that it is important to choose a project direction that I can explain clearly and defend in the viva.
He advised that if a particular direction or part of the literature is too difficult to understand within the available time, I should consider whether I can realistically get up to speed or whether the project should be adjusted.
He also stressed the importance of developing enough intuition about the problem to recognise when results may be physically unreasonable, contradictory, or difficult to justify.
Simon Warder encouraged students to begin reading relevant papers and to use the next meeting to discuss ideas in more detail.

Work plan before next meeting:

Start reading literature related to wind/renewables bias correction and machine learning methods for correcting systematic errors in data or model outputs.
Prioritise papers that include datasets, software, or reproducible workflows, as these may help define a practical project direction.
Clarify the possible research question for the bias correction project, for example whether machine learning can improve on traditional or linear correction methods.
Think about what input features may be relevant for the project, such as spatial, seasonal, terrain-related, coastal, or turbine-density features.
Prepare initial ideas for the project plan before the 12 June deadline.
Identify any parts of the project direction that I do not yet understand clearly, so that these can be discussed with the supervisors in the next meeting.

Meeting (8 June 2026)

Present:  Warder, Simon C（Main supervisor）;  Wang, Yan(Research Postgraduate); Cao, Chang;(student)

Key points discussed:

This meeting focused on refining and adjusting the direction of my IRP project on wind data bias correction.
Simon first explained the existing workflow used in Yan’s work. In that workflow, a reanalysis dataset such as ERA5 is corrected, then used to simulate wind farm power production, and the simulated production is compared with actual wind farm production data.
Simon explained that the wind farm production data used in the existing workflow has limitations. It is only available at wind farm locations, so the spatial coverage is limited, and the temporal resolution is relatively coarse, for example monthly production data.
Simon suggested that instead of following the existing wind farm production-data workflow directly, my project could focus more specifically on the reanalysis datasets themselves.
The suggested new direction is to train a bias-correction or mapping model that takes one reanalysis product as input and predicts another reanalysis product as output.
Possible reanalysis datasets discussed included ERA5, MERRA-2, and higher-resolution products such as CERRA or CARRA.
A key motivation for this direction is that different reanalysis products have different spatial resolutions and model structures, which can lead to systematic differences in wind speed estimates.
Simon explained that some useful explanatory features may include terrain or hilliness, distance to the coast, coastline effects, and other spatial features. These features are relevant because low-resolution reanalysis products may not fully resolve local topography or coastlines, leading to larger wind-speed biases in certain areas.

Feedback received:
Simon advised me to move away from directly using the existing wind farm production-data workflow and instead consider focusing on bias correction between different reanalysis products.
He suggested that a project along these lines would be interesting to the research group and could also be more suitable as an independent research project.
Simon emphasised that I do not have to follow the suggested idea exactly. Instead, I should use it as a starting point and develop the parts of the project that I find most interesting and manageable.
He mentioned that Yan’s papers would be a useful starting point for motivating the project and finding relevant references.
Simon also suggested that Yan may be able to provide support, especially in relation to useful input features and access to relevant reanalysis datasets.
Simon reminded me to keep the GitHub repository and logbook up to date as part of documenting engagement with the project.
He also said that I could email the supervisors if I have questions about technical details, datasets, or methods.
Work plan before next meeting:
Read Yan’s papers and the references cited in them to better understand the motivation for wind-speed bias correction.
Investigate the main differences between reanalysis products such as ERA5, MERRA-2, CERRA, and CARRA, especially in terms of spatial resolution, temporal resolution, and wind-speed representation.
Refine the project aim around machine-learning-based bias correction or mapping between different reanalysis wind datasets.
Think about a possible workflow where one reanalysis dataset is used as the input and another reanalysis dataset is used as the target output.
Identify potentially useful input features, such as terrain, hilliness, distance to coast, spatial location, and seasonal variables.
Begin drafting the project plan and clarify the research question, data sources, baseline method, machine learning method, and evaluation metrics.
Update the GitHub repository and commit the logbook entry after the meeting.

Meeting (18 June 2026)

**Present:** Warder, Simon C (Main supervisor); Cao, Chang (student)

This meeting followed the submission of the IRP project plan on 12 June 2026 and focused on Simon's written feedback on the plan, as well as a review of initial data pipeline work completed during the first week.

Simon shared written feedback on the project plan. The plan was described as mostly well thought out, well structured, and written in an appropriate scientific style. The following areas were identified for improvement:

The literature review would benefit from drawing on a broader range of sources to more fully motivate the project. In particular, greater explanation is needed as to why the lag of CERRA is problematic, and for which specific applications this delay creates a practical constraint.

The proposal relies on CERRA having reduced biases compared with ERA5. While this is noted as a potential limitation in the plan, Simon advised reviewing additional literature on CERRA's performance to strengthen this assumption.

The methodological rationale for training a separate model for each CERRA grid cell is currently unclear. Since the topographic features are intended to ensure generalisability across diverse geographic areas, it is not obvious why a cell-wise approach is necessary. This needs to be better justified or reconsidered.

Minor points raised: references should be avoided in the abstract where possible; GLO-30 is not explained when first introduced; and the plan would benefit from additional figures, such as a workflow diagram and a Gantt chart of the proposed timeline.

Simon also noted that the project plan was generally at a good level and that the inclusion of simpler baseline approaches such as quantile mapping was better

Work plan before next meeting

Review additional literature on CERRA's performance relative to ERA5, particularly for wind speed and over complex terrain (e.g. Ridal et al. 2024; Mediterranean evaluation studies).

Revise the project plan to address all feedback points above: broaden literature review, clarify cell-wise justification, remove abstract references, explain GLO-30, add figures.

Continue data pipeline work: download ERA5 and CERRA data for the full UK domain and begin computing GLO-30 terrain features at CERRA grid resolution.

Prepare preliminary bias results (ERA5 vs CERRA mean wind speed comparison) for the next meeting.

Update the GitHub repository and logbook with this week's progress.

Meeting (10 July 2026)

**Present:** Warder, Simon C (Main supervisor); Cao, Chang (student)

- I had completed the download of nearly ten years of data and was preparing to determine an appropriate time period for the experiments.
- I was beginning to explore feature selection, model selection, and the detailed experimental design.
- I had encountered repeated memory and computational constraints. Running the analysis over the full UK domain was beyond the available computing capacity, as was using every available time step throughout each day.
- Hyperparameter selection also created substantial computational and memory demands.
- I discussed these methodological design issues and computational constraints with Simon.
- We discussed how the experimental scope and methodology would need to take account of the available computational resources.
To do:
- Select an appropriate experimental time range from the downloaded data.
- Continue exploring and justifying the feature set and model choices.
- Refine the spatial and temporal scope of the experiments so that the pipeline can run within the available memory and computing capacity.
- Develop a computationally feasible approach to model training and hyperparameter selection.
Meeting (24 July 2026)
**Present:** Warder, Simon C (Main supervisor); Cao, Chang (student)

- I presented the initial model-training work and the literature I had found on related experimental comparisons.
- Many of the methods identified in the literature focused more heavily on deep learning. I asked whether the project direction should be adjusted because the original experimental design appeared too simple and the choice of baselines was limited.
- I was uncertain about how to improve the experimental design. I had considered following a more complex approach from the literature, but abandoned this option because its code was difficult to reproduce reliably.
- Simon suggested using quantile mapping as an additional baseline for comparison with the machine-learning models.
To do
- Implement a quantile-mapping baseline and compare it with the existing baseline and trained models.
- Continue reviewing relevant literature for reproducible experimental comparisons and possible improvements to the methodology.
- Refine the experimental design and baseline selection without relying on methods that cannot be reproduced reliably within the available time.


Meeting (4 August 2026)

**Present:** Warder, Simon C (Main supervisor); Cao, Chang (student)

- I presented the current experimental results, including the models used for training and their final predictive performance.
- We discussed the rationale for the selected engineered features and whether the current results provided sufficient evidence for their contribution.
- We also discussed the motivation for the project, particularly the claimed practical importance of the delay in the availability of CERRA data, and the role of quantile mapping as a comparison method.
- Simon noted that the feature-engineering choices were not yet supported by sufficiently strong evidence because relevant supporting experiments were missing.
- The project motivation may have overestimated the practical importance of the delay in CERRA data availability. Simon advised reconsidering whether this assumption was sufficiently well founded.
- My understanding and explanation of quantile mapping needed further improvement.
To do
- Add relevant experiments to provide stronger evidence for the contribution of the selected engineered features.
- Reassess and refine the project motivation concerning the delay in CERRA data availability, supported by appropriate evidence.
- Develop a clearer understanding of quantile mapping and explain its methodology and role as a baseline more accurately in the report.

eeting (18 August 2026)
**Present:** Warder, Simon C (Main supervisor); Cao, Chang (student)

Key points discussed:

Simon confirmed the items that must be completed before the final submission.

- The discussion covered requirements and points to consider when writing and finalising the report, including completion of the required AI-use declaration.
- I raised a concern that the remaining time was limited and discussed adding an experiment to evaluate the spatial generalisability of the model.

Work plan before next meeting:

finish the draft and get feedback. Then finish the whole work
