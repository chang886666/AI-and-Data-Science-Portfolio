"""Smoke tests for the installable research package."""

import numpy as np

import irp_cc125
from irp_cc125 import config
from irp_cc125.spatial_holdout.config import (
    N_HOLDOUT_POINTS,
    N_POINTS_EXPECTED,
    N_TRAIN_POINTS,
    RF_GRID,
    XGB_GRID,
    rf_fixed,
    xgb_fixed,
)
from irp_cc125.spatial_holdout.utils import regression_metrics
from irp_cc125.spatial_holdout.validation import make_split


def test_package_metadata_and_experiment_config():
    assert irp_cc125.__version__ == "0.1.0"
    assert config.EXPERIMENT_ID == "projected_ons_bgc_v1"
    assert len(config.FEATURE_NAMES) == 9


def test_model_grids_and_fixed_parameters():
    assert len(XGB_GRID) == 12
    assert len(RF_GRID) == 6
    assert xgb_fixed(3)["n_jobs"] == 3
    assert rf_fixed(3)["random_state"] == 42


def test_regression_metrics_for_exact_prediction():
    values = np.array([1.0, 2.0, 4.0], dtype=np.float64)
    metrics = regression_metrics(values, values)
    assert metrics["n"] == 3
    assert metrics["rmse"] == 0.0
    assert metrics["mae"] == 0.0
    assert metrics["bias"] == 0.0
    assert metrics["r2"] == 1.0


def test_spatial_split_is_deterministic_and_complete():
    flags = np.zeros((N_POINTS_EXPECTED, 3), dtype=bool)
    flags[:506, 1] = True
    flags[1516:, 0] = True
    flags[::3, 2] = True

    first = make_split(flags)
    second = make_split(flags)
    train_ids, holdout_ids, strata = first

    assert len(train_ids) == N_TRAIN_POINTS
    assert len(holdout_ids) == N_HOLDOUT_POINTS
    assert np.array_equal(first[0], second[0])
    assert np.array_equal(first[1], second[1])
    assert np.intersect1d(train_ids, holdout_ids).size == 0
    assert np.array_equal(
        np.sort(np.concatenate([train_ids, holdout_ids])),
        np.arange(N_POINTS_EXPECTED),
    )
    assert len(strata) == N_POINTS_EXPECTED
