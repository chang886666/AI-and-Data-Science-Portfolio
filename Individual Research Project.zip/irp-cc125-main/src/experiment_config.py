"""Compatibility imports for the numbered experiment scripts."""

from irp_cc125.config import *  # noqa: F401,F403
