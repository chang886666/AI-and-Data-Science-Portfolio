#!/usr/bin/env python3
"""Versioned leave-one-feature and feature-group ablation experiments."""

from __future__ import annotations

import json
import os
import time

os.environ.setdefault("JOBLIB_TEMP_FOLDER", "/dev/shm")

import numpy as np
import xgboost
from sklearn.ensemble import RandomForestRegressor

from experiment_config import ARRAY_PATHS, EXPERIMENT_DIR, EXPERIMENT_ID, FEATURE_NAMES


OUT_PATH = EXPERIMENT_DIR / "ablation_results.json"
MODEL_METADATA_PATH = EXPERIMENT_DIR / "model_metadata.json"
EVALUATION_PATH = EXPERIMENT_DIR / "evaluation_results.json"


def metrics(y_true: np.ndarray, prediction: np.ndarray) -> dict:
    error = prediction.astype(np.float64) - y_true.astype(np.float64)
    return {
        "rmse": float(np.sqrt(np.mean(error**2))),
        "mae": float(np.mean(np.abs(error))),
        "bias": float(np.mean(error)),
        "n": int(len(y_true)),
    }


def atomic_save(results: dict) -> None:
    temporary = OUT_PATH.with_suffix(".json.tmp")
    with temporary.open("w") as handle:
        json.dump(results, handle, indent=2)
    temporary.replace(OUT_PATH)


def main() -> None:
    with MODEL_METADATA_PATH.open() as handle:
        model_metadata = json.load(handle)
    with EVALUATION_PATH.open() as handle:
        evaluation = json.load(handle)
    if model_metadata.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("Model metadata belongs to another experiment.")
    if model_metadata.get("feature_names") != FEATURE_NAMES:
        raise ValueError("Ablation and model feature schemas differ.")

    x_train = np.asarray(np.load(ARRAY_PATHS["X_train"]), dtype=np.float32)
    y_train = np.asarray(np.load(ARRAY_PATHS["y_train"]), dtype=np.float32)
    x_test = np.asarray(np.load(ARRAY_PATHS["X_test"]), dtype=np.float32)
    y_test = np.asarray(np.load(ARRAY_PATHS["y_test"]), dtype=np.float32)
    meta_test = np.load(ARRAY_PATHS["test_metadata"], mmap_mode="r")

    subsets = {
        "Overall": np.ones(len(y_test), dtype=bool),
        "Complex": meta_test[:, 6].astype(bool),
        "Flat": meta_test[:, 7].astype(bool),
        "Coastal": meta_test[:, 8].astype(bool),
    }
    variants = {
        f"drop_{name}": [index]
        for index, name in enumerate(FEATURE_NAMES)
    }
    variants["drop_all_terrain"] = list(range(1, 7))
    variants["drop_both_season_terms"] = [7, 8]

    results = {
        "experiment_id": EXPERIMENT_ID,
        "feature_names": FEATURE_NAMES,
        "interpretation": (
            "Each variant is refit from scratch with selected columns removed; "
            "positive RMSE delta means the removed information was useful."
        ),
        "baseline": {
            model: evaluation["subsets"]["Overall"][model]
            for model in ("RandomForest", "XGBoost")
        },
        "variants": {},
    }
    if OUT_PATH.exists():
        with OUT_PATH.open() as handle:
            existing = json.load(handle)
        if existing.get("experiment_id") != EXPERIMENT_ID:
            raise ValueError("Ablation cache belongs to another experiment.")
        results = existing

    model_specs = {
        "RandomForest": (
            RandomForestRegressor,
            model_metadata["random_forest"]["params"],
        ),
        "XGBoost": (
            xgboost.XGBRegressor,
            model_metadata["xgboost"]["params"],
        ),
    }

    for variant_number, (variant_name, dropped_indices) in enumerate(
        variants.items(), start=1
    ):
        if variant_name in results["variants"]:
            print(f"Skipping completed {variant_name}")
            continue
        kept_indices = [
            index for index in range(len(FEATURE_NAMES))
            if index not in dropped_indices
        ]
        kept_features = [FEATURE_NAMES[index] for index in kept_indices]
        dropped_features = [FEATURE_NAMES[index] for index in dropped_indices]
        print(
            f"\n=== Ablation {variant_number}/{len(variants)}: {variant_name} ==="
        )
        print(f"Dropped: {dropped_features}")
        x_variant_train = np.ascontiguousarray(x_train[:, kept_indices])
        x_variant_test = np.ascontiguousarray(x_test[:, kept_indices])
        variant_result = {
            "dropped_features": dropped_features,
            "kept_features": kept_features,
            "models": {},
        }
        for model_name, (model_class, params) in model_specs.items():
            start = time.time()
            model = model_class(**params)
            model.fit(x_variant_train, y_train)
            prediction = model.predict(x_variant_test)
            model_result = {
                "elapsed_seconds": time.time() - start,
                "subsets": {
                    subset_name: metrics(y_test[mask], prediction[mask])
                    for subset_name, mask in subsets.items()
                },
            }
            baseline_rmse = results["baseline"][model_name]["rmse"]
            model_result["overall_rmse_delta"] = (
                model_result["subsets"]["Overall"]["rmse"] - baseline_rmse
            )
            variant_result["models"][model_name] = model_result
            print(
                f"  {model_name}: RMSE="
                f"{model_result['subsets']['Overall']['rmse']:.4f}, delta="
                f"{model_result['overall_rmse_delta']:+.4f}, "
                f"time={model_result['elapsed_seconds']:.1f}s"
            )
            del model, prediction

        results["variants"][variant_name] = variant_result
        atomic_save(results)
        del x_variant_train, x_variant_test
        print(f"Saved progress to {OUT_PATH}")

    print("\n=== Ablation complete ===")
    for variant_name in variants:
        entry = results["variants"][variant_name]
        print(
            f"{variant_name:28s} "
            f"RF={entry['models']['RandomForest']['overall_rmse_delta']:+.4f} "
            f"XGB={entry['models']['XGBoost']['overall_rmse_delta']:+.4f}"
        )


if __name__ == "__main__":
    main()
