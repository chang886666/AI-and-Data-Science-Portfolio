#!/usr/bin/env python3
"""Evaluate versioned models on the untouched 2019-2020 test period."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import joblib
import numpy as np

from experiment_config import (
    ARRAY_PATHS,
    EXPERIMENT_DIR,
    EXPERIMENT_ID,
    FEATURE_NAMES,
    TEST_YEARS,
)


MODEL_METADATA_PATH = EXPERIMENT_DIR / "model_metadata.json"
LINEAR_METADATA_PATH = EXPERIMENT_DIR / "linear_baseline_metadata.json"
RESULTS_PATH = EXPERIMENT_DIR / "evaluation_results.json"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_save_npy(path: Path, array: np.ndarray) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("wb") as handle:
        np.save(handle, array)
    temporary.replace(path)


def predict_linear_baseline(
    x: np.ndarray, archive, model_name: str, chunk_size: int = 250_000
) -> np.ndarray:
    prefix = model_name.lower()
    indices = archive[f"{prefix}_indices"]
    mean = archive[f"{prefix}_mean"]
    scale = archive[f"{prefix}_scale"]
    intercept = float(archive[f"{prefix}_intercept"][0])
    coefficients = archive[f"{prefix}_coefficients_standardized"]
    prediction = np.empty(len(x), dtype=np.float32)
    for start in range(0, len(x), chunk_size):
        stop = min(start + chunk_size, len(x))
        values = np.asarray(x[start:stop, indices], dtype=np.float64)
        prediction[start:stop] = (
            intercept + ((values - mean) / scale) @ coefficients
        ).astype(np.float32)
    return prediction


def compute_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    difference = np.asarray(y_pred, dtype=np.float64) - np.asarray(
        y_true, dtype=np.float64
    )
    squared_error = difference**2
    centered = np.asarray(y_true, dtype=np.float64) - float(np.mean(y_true))
    denominator = float(np.sum(centered**2))
    return {
        "rmse": float(np.sqrt(np.mean(squared_error))),
        "mae": float(np.mean(np.abs(difference))),
        "bias": float(np.mean(difference)),
        "r": float(np.corrcoef(y_true, y_pred)[0, 1]),
        "r2": float(1.0 - np.sum(squared_error) / denominator),
        "n": int(len(y_true)),
    }


def fit_quantile_mapping_per_point_month(
    era5_train: np.ndarray,
    cerra_train: np.ndarray,
    month_train: np.ndarray,
    n_points: int,
    n_quantiles: int = 20,
) -> dict:
    levels = np.linspace(0, 100, n_quantiles + 1)
    mappers = {}
    for month in range(1, 13):
        mask = month_train == month
        if int(mask.sum()) % n_points:
            raise ValueError(f"Month {month} training block is not point-aligned.")
        era5_month = era5_train[mask].reshape(-1, n_points)
        cerra_month = cerra_train[mask].reshape(-1, n_points)
        mappers[month] = (
            np.percentile(era5_month, levels, axis=0),
            np.percentile(cerra_month, levels, axis=0),
        )
    return mappers


def apply_quantile_mapping_per_point_month(
    mappers: dict,
    era5_test: np.ndarray,
    month_test: np.ndarray,
    n_points: int,
) -> np.ndarray:
    corrected = np.empty_like(era5_test, dtype=np.float32)
    for month in range(1, 13):
        mask = month_test == month
        if int(mask.sum()) % n_points:
            raise ValueError(f"Month {month} test block is not point-aligned.")
        era5_month = era5_test[mask].reshape(-1, n_points)
        output = np.empty_like(era5_month, dtype=np.float32)
        era5_quantiles, cerra_quantiles = mappers[month]
        for point in range(n_points):
            output[:, point] = np.interp(
                era5_month[:, point],
                era5_quantiles[:, point],
                cerra_quantiles[:, point],
            )
        corrected[mask] = output.ravel()
    return corrected


def main() -> None:
    if not MODEL_METADATA_PATH.is_file() or not LINEAR_METADATA_PATH.is_file():
        raise FileNotFoundError(
            "Run 03c_train_final_models.py and 03d_train_linear_baselines.py first."
        )
    with MODEL_METADATA_PATH.open() as handle:
        model_metadata = json.load(handle)
    if model_metadata.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("Model metadata belongs to another experiment.")
    if model_metadata.get("feature_names") != FEATURE_NAMES:
        raise ValueError("Model feature schema does not match evaluation schema.")
    with LINEAR_METADATA_PATH.open() as handle:
        linear_metadata = json.load(handle)
    if linear_metadata.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("Linear baselines belong to another experiment.")
    linear_path = EXPERIMENT_DIR / linear_metadata["model_file"]
    if sha256_file(linear_path) != linear_metadata["model_sha256"]:
        raise ValueError("Linear baseline model fingerprint mismatch.")

    rf_path = EXPERIMENT_DIR / model_metadata["random_forest"]["model_file"]
    xgb_path = EXPERIMENT_DIR / model_metadata["xgboost"]["model_file"]
    if sha256_file(rf_path) != model_metadata["random_forest"]["model_sha256"]:
        raise ValueError("RandomForest model fingerprint mismatch.")
    if sha256_file(xgb_path) != model_metadata["xgboost"]["model_sha256"]:
        raise ValueError("XGBoost model fingerprint mismatch.")

    x_train = np.load(ARRAY_PATHS["X_train"], mmap_mode="r")
    y_train = np.load(ARRAY_PATHS["y_train"], mmap_mode="r")
    meta_train = np.load(ARRAY_PATHS["train_metadata"], mmap_mode="r")
    x_test = np.load(ARRAY_PATHS["X_test"], mmap_mode="r")
    y_test = np.load(ARRAY_PATHS["y_test"], mmap_mode="r")
    meta_test = np.load(ARRAY_PATHS["test_metadata"], mmap_mode="r")
    bilinear = np.load(ARRAY_PATHS["bilinear_test"], mmap_mode="r")
    if x_test.shape[1] != len(FEATURE_NAMES):
        raise ValueError("Test feature schema changed after model training.")

    rf_model = joblib.load(rf_path)
    xgb_model = joblib.load(xgb_path)
    linear_archive = np.load(linear_path)
    n_points = len(np.load("data/processed/land_lats.npy", mmap_mode="r"))

    print("Fitting per-point, per-month quantile mapping on 2016-2018 only...")
    mappers = fit_quantile_mapping_per_point_month(
        x_train[:, 0], y_train, meta_train[:, 3].astype(int), n_points
    )
    prediction_qm = apply_quantile_mapping_per_point_month(
        mappers, x_test[:, 0], meta_test[:, 3].astype(int), n_points
    )
    print("Predicting versioned linear baselines...")
    prediction_linear_era5 = predict_linear_baseline(
        x_test, linear_archive, "LinearERA5Seasonal"
    )
    prediction_linear_full = predict_linear_baseline(
        x_test, linear_archive, "LinearFullFeatures"
    )
    print("Predicting held-out 2019-2020 test rows...")
    x_test_float32 = np.asarray(x_test, dtype=np.float32)
    prediction_rf = rf_model.predict(x_test_float32)
    prediction_xgb = xgb_model.predict(x_test_float32)

    predictions = {
        "Bilinear": np.asarray(bilinear),
        "LinearERA5Seasonal": prediction_linear_era5,
        "QuantileMapping": prediction_qm,
        "LinearFullFeatures": prediction_linear_full,
        "RandomForest": prediction_rf,
        "XGBoost": prediction_xgb,
    }
    for name, values in predictions.items():
        if values.shape != y_test.shape or not np.isfinite(values).all():
            raise ValueError(f"Invalid {name} predictions: {values.shape}")
        atomic_save_npy(
            EXPERIMENT_DIR / f"prediction_{name.lower()}.npy", values
        )

    years = meta_test[:, 2].astype(int)
    subsets = {
        "Overall": np.ones(len(y_test), dtype=bool),
        "Complex": meta_test[:, 6].astype(bool),
        "Flat": meta_test[:, 7].astype(bool),
        "Coastal": meta_test[:, 8].astype(bool),
        **{f"Year_{year}": years == year for year in TEST_YEARS},
    }
    results = {
        "experiment_id": EXPERIMENT_ID,
        "feature_names": FEATURE_NAMES,
        "test_years": TEST_YEARS,
        "baseline_definitions": {
            "Bilinear": "ERA5 bilinearly interpolated to fixed CERRA points",
            "LinearERA5Seasonal": "OLS using ERA5 wind and cyclic month terms",
            "QuantileMapping": (
                "20-quantile empirical mapping fitted per point and calendar "
                "month on training years; out-of-range values use endpoint clipping"
            ),
            "LinearFullFeatures": "OLS using the same nine predictors as RF/XGBoost",
        },
        "subsets": {},
    }
    for subset_name, mask in subsets.items():
        results["subsets"][subset_name] = {
            model_name: compute_metrics(y_test[mask], values[mask])
            for model_name, values in predictions.items()
        }

    temporary = RESULTS_PATH.with_suffix(".json.tmp")
    with temporary.open("w") as handle:
        json.dump(results, handle, indent=2)
    temporary.replace(RESULTS_PATH)

    print("\n=== Held-out test results ===")
    for subset_name, subset_results in results["subsets"].items():
        print(f"\n{subset_name}")
        for model_name, values in subset_results.items():
            print(
                f"  {model_name:16s} RMSE={values['rmse']:.4f} "
                f"MAE={values['mae']:.4f} bias={values['bias']:+.4f} "
                f"R2={values['r2']:.4f}"
            )
    print(f"Saved versioned predictions and results to {EXPERIMENT_DIR}")


if __name__ == "__main__":
    main()
