#!/usr/bin/env python3
"""Run the versioned unseen-point generalisation experiment."""

from irp_cc125.spatial_holdout.workflow import main


if __name__ == "__main__":
    main()
