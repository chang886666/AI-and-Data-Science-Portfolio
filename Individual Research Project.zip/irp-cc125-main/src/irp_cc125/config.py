"""Single source of truth for the projected-terrain Scotland experiment."""

from __future__ import annotations

from pathlib import Path


EXPERIMENT_ID = "projected_ons_bgc_v1"
DATA_DIR = Path("data")
PROCESSED_DIR = DATA_DIR / "processed"
EXPERIMENT_DIR = PROCESSED_DIR / "experiments" / EXPERIMENT_ID

FEATURE_NAMES = [
    "era5_wind",
    "elevation",
    "slope",
    "hilliness",
    "tpi_5km",
    "tpi_75km",
    "dist_coast",
    "sin_month",
    "cos_month",
]

TRAIN_YEARS = [2016, 2017, 2018]
TEST_YEARS = [2019, 2020]

# Forward-chaining folds match the intended use: earlier years predict a
# later, unseen year. The final 2019-2020 test period remains untouched.
FORWARD_FOLDS = [
    {"name": "forward_2017", "train": [2016], "val": [2017]},
    {"name": "forward_2018", "train": [2016, 2017], "val": [2018]},
]

ARRAY_PATHS = {
    "X_train": PROCESSED_DIR / "X_train.npy",
    "y_train": PROCESSED_DIR / "y_train.npy",
    "train_metadata": PROCESSED_DIR / "train_metadata.npy",
    "X_test": PROCESSED_DIR / "X_test.npy",
    "y_test": PROCESSED_DIR / "y_test.npy",
    "test_metadata": PROCESSED_DIR / "test_metadata.npy",
    "bilinear_test": PROCESSED_DIR / "bilinear_test.npy",
    "land_terrain_features": PROCESSED_DIR / "land_terrain_features.npy",
}

TERRAIN_METADATA_PATH = PROCESSED_DIR / "land_terrain_features_metadata.json"
