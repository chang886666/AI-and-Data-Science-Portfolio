"""ERA5-to-CERRA statistical downscaling research package."""

__version__ = "0.1.0"
