"""Input validation and deterministic point splitting for spatial holdout."""

from __future__ import annotations

import csv
import json
import platform

import joblib
import numpy as np
import sklearn
import xgboost
from sklearn.model_selection import train_test_split

from irp_cc125.config import (
    ARRAY_PATHS, EXPERIMENT_ID, FEATURE_NAMES, FORWARD_FOLDS,
    TERRAIN_METADATA_PATH, TEST_YEARS, TRAIN_YEARS,
)
from irp_cc125.spatial_holdout.config import (
    DESIGN_PATH, N_HOLDOUT_POINTS, N_POINTS_EXPECTED, N_TRAIN_POINTS,
    OUT_DIR, POINT_TABLE_PATH, RANDOM_STATE, RF_GRID, ROW_CHUNK_SIZE,
    SOURCE_MANIFEST_PATH, SPLIT_PATH, XGB_GRID, rf_fixed, xgb_fixed,
)
from irp_cc125.spatial_holdout.utils import (
    atomic_json_dump, atomic_npz_save, sha256_arrays, sha256_file, utc_now,
)


def validate_source_manifest() -> tuple[dict, str, dict[str, str]]:
    if not SOURCE_MANIFEST_PATH.is_file():
        raise FileNotFoundError(
            f"Run 03a_validate_experiment.py first: {SOURCE_MANIFEST_PATH}"
        )
    with SOURCE_MANIFEST_PATH.open() as handle:
        manifest = json.load(handle)
    if manifest.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("Source manifest belongs to another experiment.")
    if manifest.get("feature_names") != FEATURE_NAMES:
        raise ValueError("Source manifest feature schema has changed.")
    if manifest.get("train_years") != TRAIN_YEARS:
        raise ValueError("Source manifest training years have changed.")
    if manifest.get("test_years") != TEST_YEARS:
        raise ValueError("Source manifest test years have changed.")

    expected_hashes = manifest.get("sha256", {})
    paths = {**ARRAY_PATHS, "terrain_metadata": TERRAIN_METADATA_PATH}
    missing = [str(path) for path in paths.values() if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"Missing validated input files: {missing}")

    print("Verifying current inputs against the main experiment manifest...")
    actual_hashes = {}
    for name, path in paths.items():
        expected = expected_hashes.get(name)
        if expected is None:
            raise ValueError(f"Source manifest has no SHA-256 for {name}.")
        actual = sha256_file(path)
        actual_hashes[name] = actual
        if actual != expected:
            raise ValueError(
                f"Validated input changed for {name}: {actual} != {expected}. "
                "Create a new experiment ID rather than mixing versions."
            )
    return manifest, sha256_file(SOURCE_MANIFEST_PATH), actual_hashes

def validate_layout_and_get_points() -> dict:
    x_train = np.load(ARRAY_PATHS["X_train"], mmap_mode="r")
    y_train = np.load(ARRAY_PATHS["y_train"], mmap_mode="r")
    meta_train = np.load(ARRAY_PATHS["train_metadata"], mmap_mode="r")
    x_test = np.load(ARRAY_PATHS["X_test"], mmap_mode="r")
    y_test = np.load(ARRAY_PATHS["y_test"], mmap_mode="r")
    meta_test = np.load(ARRAY_PATHS["test_metadata"], mmap_mode="r")
    bilinear_test = np.load(ARRAY_PATHS["bilinear_test"], mmap_mode="r")
    terrain = np.load(ARRAY_PATHS["land_terrain_features"], mmap_mode="r")

    if x_train.shape != (len(y_train), len(FEATURE_NAMES)):
        raise ValueError(f"Unexpected training arrays: X={x_train.shape}, y={y_train.shape}")
    if x_test.shape != (len(y_test), len(FEATURE_NAMES)):
        raise ValueError(f"Unexpected test arrays: X={x_test.shape}, y={y_test.shape}")
    if meta_train.shape != (len(y_train), 9) or meta_test.shape != (len(y_test), 9):
        raise ValueError("Metadata must have one nine-column row per target row.")
    if bilinear_test.shape != y_test.shape:
        raise ValueError("Bilinear test predictions have an incompatible shape.")
    if terrain.shape != (N_POINTS_EXPECTED, 6):
        raise ValueError(f"Unexpected terrain shape: {terrain.shape}")
    if len(y_train) % N_POINTS_EXPECTED or len(y_test) % N_POINTS_EXPECTED:
        raise ValueError("Rows do not form complete 2,022-point timestamp blocks.")

    n_train_times = len(y_train) // N_POINTS_EXPECTED
    n_test_times = len(y_test) // N_POINTS_EXPECTED
    train_first = np.asarray(meta_train[:N_POINTS_EXPECTED])
    test_first = np.asarray(meta_test[:N_POINTS_EXPECTED])
    coordinates = train_first[:, :2].astype(np.float64)
    flags = train_first[:, 6:9].astype(bool)

    if len(np.unique(coordinates, axis=0)) != N_POINTS_EXPECTED:
        raise ValueError("The first training block does not contain 2,022 unique points.")
    if not np.array_equal(test_first[:, :2], coordinates):
        raise ValueError("Train and test point membership/order differ.")
    if not np.array_equal(test_first[:, 6:9].astype(bool), flags):
        raise ValueError("Train and test point terrain flags differ.")

    land_lats_path = ARRAY_PATHS["X_train"].parent / "land_lats.npy"
    land_lons_path = ARRAY_PATHS["X_train"].parent / "land_lons.npy"
    land_flags_path = ARRAY_PATHS["X_train"].parent / "land_terrain_flags.npy"
    for path in (land_lats_path, land_lons_path, land_flags_path):
        if not path.is_file():
            raise FileNotFoundError(f"Missing fixed-point input: {path}")
    land_lats = np.load(land_lats_path, mmap_mode="r")
    land_lons = np.load(land_lons_path, mmap_mode="r")
    land_flags = np.load(land_flags_path, mmap_mode="r")
    if not (
        np.array_equal(coordinates[:, 0], land_lats)
        and np.array_equal(coordinates[:, 1], land_lons)
        and np.array_equal(flags, land_flags)
    ):
        raise ValueError("Metadata point order does not match the saved fixed-point arrays.")

    hilliness = np.asarray(terrain[:, 2], dtype=float)
    distance_to_coast = np.asarray(terrain[:, 5], dtype=float)
    expected_flags = np.column_stack(
        [
            hilliness > np.percentile(hilliness, 75),
            hilliness < np.percentile(hilliness, 25),
            distance_to_coast < 20.0,
        ]
    )
    if not np.array_equal(flags, expected_flags):
        raise ValueError("Stored point flags do not match current terrain features.")

    # Exact chunked checks establish that row_index % 2022 is a valid point ID
    # throughout both periods.  This avoids coordinate matching during fitting.
    for label, features, metadata in (
        ("train", x_train, meta_train),
        ("test", x_test, meta_test),
    ):
        for start in range(0, len(metadata), ROW_CHUNK_SIZE):
            stop = min(start + ROW_CHUNK_SIZE, len(metadata))
            row_ids = np.arange(start, stop)
            point_ids = row_ids % N_POINTS_EXPECTED
            block = np.asarray(metadata[start:stop])
            if not np.array_equal(block[:, :2], coordinates[point_ids]):
                raise ValueError(f"{label} point order changes at row {start:,}.")
            if not np.array_equal(block[:, 6:9].astype(bool), flags[point_ids]):
                raise ValueError(f"{label} point flags change at row {start:,}.")
            time_block_start = (row_ids // N_POINTS_EXPECTED) * N_POINTS_EXPECTED
            if not np.array_equal(
                block[:, 2:6], np.asarray(metadata[time_block_start, 2:6])
            ):
                raise ValueError(
                    f"{label} timestamp fields change inside a point block "
                    f"near row {start:,}."
                )
            feature_block = np.asarray(features[start:stop])
            if not np.allclose(
                feature_block[:, 1:7],
                np.asarray(terrain[point_ids]),
                rtol=0.0,
                atol=1e-10,
            ):
                raise ValueError(
                    f"{label} terrain features change for a fixed point "
                    f"near row {start:,}."
                )

    train_years_by_time = np.asarray(
        meta_train[::N_POINTS_EXPECTED, 2], dtype=int
    )
    test_years_by_time = np.asarray(meta_test[::N_POINTS_EXPECTED, 2], dtype=int)
    if sorted(np.unique(train_years_by_time).tolist()) != TRAIN_YEARS:
        raise ValueError("Unexpected training years in timestamp blocks.")
    if sorted(np.unique(test_years_by_time).tolist()) != TEST_YEARS:
        raise ValueError("Unexpected test years in timestamp blocks.")
    train_hours = np.asarray(meta_train[::N_POINTS_EXPECTED, 5], dtype=int)
    test_hours = np.asarray(meta_test[::N_POINTS_EXPECTED, 5], dtype=int)
    if not (
        set(np.unique(train_hours).tolist()) == {0, 12}
        and set(np.unique(test_hours).tolist()) == {0, 12}
    ):
        raise ValueError("Expected only 00:00 and 12:00 UTC timestamp blocks.")

    # The bilinear reference should be exactly the first model feature, apart
    # from harmless dtype representation differences.
    for start in range(0, len(y_test), ROW_CHUNK_SIZE):
        stop = min(start + ROW_CHUNK_SIZE, len(y_test))
        if not np.allclose(
            bilinear_test[start:stop], x_test[start:stop, 0], rtol=0.0, atol=1e-7
        ):
            raise ValueError("bilinear_test is not the ERA5-wind predictor.")

    return {
        "coordinates": coordinates,
        "flags": flags,
        "train_years_by_time": train_years_by_time,
        "test_years_by_time": test_years_by_time,
        "n_train_times": n_train_times,
        "n_test_times": n_test_times,
        "fixed_point_hashes": {
            "land_lats": sha256_file(land_lats_path),
            "land_lons": sha256_file(land_lons_path),
            "land_terrain_flags": sha256_file(land_flags_path),
        },
    }

def make_split(flags: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    # Six strata retain the Scotland-relative flat/middle/complex composition
    # separately for coastal and non-coastal points.
    if np.any(flags[:, 0] & flags[:, 1]):
        raise ValueError("A point cannot be both complex and flat.")
    terrain_class = np.where(flags[:, 1], 0, np.where(flags[:, 0], 2, 1))
    strata = terrain_class.astype(np.int8) * 2 + flags[:, 2].astype(np.int8)
    point_ids = np.arange(N_POINTS_EXPECTED, dtype=np.int64)
    train_ids, holdout_ids = train_test_split(
        point_ids,
        test_size=N_HOLDOUT_POINTS,
        random_state=RANDOM_STATE,
        stratify=strata,
    )
    train_ids = np.sort(train_ids)
    holdout_ids = np.sort(holdout_ids)
    if len(train_ids) != N_TRAIN_POINTS or len(holdout_ids) != N_HOLDOUT_POINTS:
        raise RuntimeError("Unexpected point split sizes.")
    if np.intersect1d(train_ids, holdout_ids).size:
        raise RuntimeError("Point split overlaps.")
    if not np.array_equal(np.sort(np.concatenate([train_ids, holdout_ids])), point_ids):
        raise RuntimeError("Point split does not cover all points exactly once.")
    return train_ids, holdout_ids, strata

def stratum_counts(strata: np.ndarray, ids: np.ndarray) -> dict[str, int]:
    return {str(value): int(np.count_nonzero(strata[ids] == value)) for value in range(6)}

def write_point_table(
    coordinates: np.ndarray,
    flags: np.ndarray,
    strata: np.ndarray,
    train_ids: np.ndarray,
    holdout_ids: np.ndarray,
) -> None:
    assignment = np.full(N_POINTS_EXPECTED, "train_eligible", dtype="U14")
    assignment[holdout_ids] = "holdout"
    temporary = POINT_TABLE_PATH.with_suffix(".csv.tmp")
    with temporary.open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "point_id",
                "latitude",
                "longitude",
                "split",
                "is_complex",
                "is_flat",
                "is_coastal",
                "stratum_terrain_class_x_coastal",
            ]
        )
        for point_id in range(N_POINTS_EXPECTED):
            writer.writerow(
                [
                    point_id,
                    f"{coordinates[point_id, 0]:.10f}",
                    f"{coordinates[point_id, 1]:.10f}",
                    assignment[point_id],
                    int(flags[point_id, 0]),
                    int(flags[point_id, 1]),
                    int(flags[point_id, 2]),
                    int(strata[point_id]),
                ]
            )
    temporary.replace(POINT_TABLE_PATH)

def materialise_design(
    source_manifest_hash: str,
    input_hashes: dict[str, str],
    layout: dict,
    train_ids: np.ndarray,
    holdout_ids: np.ndarray,
    strata: np.ndarray,
    n_jobs: int,
) -> tuple[dict, str]:
    coordinates = layout["coordinates"]
    flags = layout["flags"]
    split_content_hash = sha256_arrays(train_ids, holdout_ids, coordinates, flags)

    if SPLIT_PATH.exists():
        with np.load(SPLIT_PATH) as stored:
            if not (
                np.array_equal(stored["train_point_ids"], train_ids)
                and np.array_equal(stored["holdout_point_ids"], holdout_ids)
                and np.array_equal(stored["coordinates"], coordinates)
                and np.array_equal(stored["terrain_flags"], flags)
                and np.array_equal(stored["strata"], strata)
            ):
                raise ValueError("Existing spatial point split is incompatible.")
    else:
        atomic_npz_save(
            SPLIT_PATH,
            train_point_ids=train_ids,
            holdout_point_ids=holdout_ids,
            coordinates=coordinates,
            terrain_flags=flags,
            strata=strata,
        )
    if not POINT_TABLE_PATH.exists():
        write_point_table(coordinates, flags, strata, train_ids, holdout_ids)

    design = {
        "spatial_experiment_id": f"{EXPERIMENT_ID}_spatial_holdout_v1",
        "parent_experiment_id": EXPERIMENT_ID,
        "source_manifest_sha256": source_manifest_hash,
        "validated_input_sha256": input_hashes,
        "fixed_point_input_sha256": layout["fixed_point_hashes"],
        "feature_names": FEATURE_NAMES,
        "train_years": TRAIN_YEARS,
        "test_years": TEST_YEARS,
        "forward_folds": FORWARD_FOLDS,
        "point_split": {
            "method": "sklearn train_test_split at point level",
            "random_state": RANDOM_STATE,
            "requested_holdout_fraction": 0.20,
            "n_points_total": N_POINTS_EXPECTED,
            "n_train_eligible_points": N_TRAIN_POINTS,
            "n_holdout_points": N_HOLDOUT_POINTS,
            "actual_holdout_fraction": N_HOLDOUT_POINTS / N_POINTS_EXPECTED,
            "stratified_by": "flat/middle/complex x coastal (six strata)",
            "stratum_encoding": (
                "2 * terrain_class + is_coastal, where flat=0, middle=1, "
                "complex=2"
            ),
            "stratum_counts_all": stratum_counts(strata, np.arange(N_POINTS_EXPECTED)),
            "stratum_counts_train": stratum_counts(strata, train_ids),
            "stratum_counts_holdout": stratum_counts(strata, holdout_ids),
            "split_content_sha256": split_content_hash,
            "holdout_point_ids_sha256": sha256_arrays(holdout_ids),
            "split_file": SPLIT_PATH.name,
            "split_file_sha256": sha256_file(SPLIT_PATH),
            "point_table_file": POINT_TABLE_PATH.name,
            "point_table_sha256": sha256_file(POINT_TABLE_PATH),
        },
        "row_layout": {
            "point_id_rule": "row_index modulo 2022 after exact layout validation",
            "n_train_timestamps": layout["n_train_times"],
            "n_test_timestamps": layout["n_test_times"],
            "n_fit_rows": layout["n_train_times"] * N_TRAIN_POINTS,
            "n_historical_unseen_rows": (
                layout["n_train_times"] * N_HOLDOUT_POINTS
            ),
            "n_future_unseen_rows": (
                layout["n_test_times"] * N_HOLDOUT_POINTS
            ),
            "n_future_seen_rows": layout["n_test_times"] * N_TRAIN_POINTS,
        },
        "evaluations": {
            "future_unseen": (
                "fit/tune using train-eligible points in 2016-2018; evaluate "
                "held-out points in 2019-2020"
            ),
            "future_seen": (
                "fit/tune using train-eligible points in 2016-2018; evaluate "
                "the same train-eligible points in 2019-2020"
            ),
            "historical_unseen": (
                "fit using train-eligible points in 2016-2018; evaluate "
                "held-out points in the same 2016-2018 timestamps"
            ),
        },
        "models": [
            "Bilinear",
            "LinearERA5Seasonal",
            "LinearFullFeatures",
            "RandomForest",
            "XGBoost",
        ],
        "quantile_mapping": {
            "included": False,
            "reason": (
                "Per-point quantile mapping requires historical paired ERA5-CERRA "
                "targets at the prediction point, which are unavailable by design "
                "for a genuinely unseen location."
            ),
        },
        "selection_metric": "lowest mean forward-chaining validation RMSE",
        "tuning_grids": {"RandomForest": RF_GRID, "XGBoost": XGB_GRID},
        "fixed_parameters": {
            "RandomForest": rf_fixed(n_jobs),
            "XGBoost": xgb_fixed(n_jobs),
        },
        "software": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "scikit_learn": sklearn.__version__,
            "xgboost": xgboost.__version__,
            "joblib": joblib.__version__,
        },
    }

    if DESIGN_PATH.exists():
        with DESIGN_PATH.open() as handle:
            stored = json.load(handle)
        if stored.get("design") != design:
            raise ValueError(
                "Existing spatial design differs from the requested design. "
                "Use a new spatial experiment version rather than mixing results."
            )
        document = stored
    else:
        document = {"created_utc": utc_now(), "design": design}
        atomic_json_dump(document, DESIGN_PATH)
    return document, sha256_file(DESIGN_PATH)
