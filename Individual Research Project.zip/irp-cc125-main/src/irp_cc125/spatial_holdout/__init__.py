"""Components for the versioned Scotland spatial-holdout experiment."""
