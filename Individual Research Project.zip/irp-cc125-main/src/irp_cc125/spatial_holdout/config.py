"""Constants and model grids for the spatial-holdout experiment."""

from __future__ import annotations

import itertools

from irp_cc125.config import EXPERIMENT_DIR, FEATURE_NAMES


RANDOM_STATE = 42
N_POINTS_EXPECTED = 2022
N_HOLDOUT_POINTS = 405
N_TRAIN_POINTS = N_POINTS_EXPECTED - N_HOLDOUT_POINTS
ROW_CHUNK_SIZE = 250_000
TIME_CHUNK_SIZE = 64

SOURCE_MANIFEST_PATH = EXPERIMENT_DIR / "experiment_manifest.json"
OUT_DIR = EXPERIMENT_DIR / "spatial_holdout_v1"
SPLIT_PATH = OUT_DIR / "point_split.npz"
POINT_TABLE_PATH = OUT_DIR / "point_split.csv"
DESIGN_PATH = OUT_DIR / "design.json"
TUNING_PATH = OUT_DIR / "tuning_results.json"
LINEAR_MODEL_PATH = OUT_DIR / "linear_models.npz"
LINEAR_METADATA_PATH = OUT_DIR / "linear_models_metadata.json"
EVALUATION_PATH = OUT_DIR / "evaluation_results.json"
RUN_SUMMARY_PATH = OUT_DIR / "run_summary.json"
PREDICTION_DIR = OUT_DIR / "predictions"

LINEAR_SPECS = {
    "LinearERA5Seasonal": ["era5_wind", "sin_month", "cos_month"],
    "LinearFullFeatures": FEATURE_NAMES,
}

XGB_GRID = [
    {"max_depth": depth, "learning_rate": rate}
    for depth, rate in itertools.product([4, 6, 8, 10], [0.03, 0.05, 0.10])
]
RF_GRID = [
    {"n_estimators": trees, "max_depth": depth}
    for trees, depth in itertools.product([200, 400], [15, 25, None])
]


def xgb_fixed(n_jobs: int) -> dict:
    return {
        "n_estimators": 300,
        "subsample": 0.8,
        "objective": "reg:squarederror",
        "eval_metric": "rmse",
        "tree_method": "hist",
        "random_state": RANDOM_STATE,
        "n_jobs": n_jobs,
    }


def rf_fixed(n_jobs: int) -> dict:
    return {
        "max_features": "sqrt",
        "max_samples": 0.1,
        "min_samples_leaf": 30,
        "random_state": RANDOM_STATE,
        "n_jobs": n_jobs,
    }
