"""Atomic file operations, fingerprints, and shared numerical helpers."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path: Path, chunk_size: int = 8 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_arrays(*arrays: np.ndarray) -> str:
    digest = hashlib.sha256()
    for array in arrays:
        contiguous = np.ascontiguousarray(array)
        digest.update(str(contiguous.dtype).encode())
        digest.update(str(contiguous.shape).encode())
        digest.update(contiguous.view(np.uint8))
    return digest.hexdigest()


def atomic_json_dump(value: dict, path: Path) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w") as handle:
        json.dump(value, handle, indent=2)
    temporary.replace(path)


def atomic_npy_save(array: np.ndarray, path: Path) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("wb") as handle:
        np.save(handle, array)
    temporary.replace(path)


def atomic_npz_save(path: Path, **arrays: np.ndarray) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("wb") as handle:
        np.savez_compressed(handle, **arrays)
    temporary.replace(path)


def atomic_joblib_dump(value, path: Path) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    joblib.dump(value, temporary)
    temporary.replace(path)


def combo_key(params: dict) -> str:
    return json.dumps(params, sort_keys=True)


def regression_metrics(
    y_true: np.ndarray, y_pred: np.ndarray
) -> dict[str, float | int]:
    truth = np.asarray(y_true, dtype=np.float64)
    prediction = np.asarray(y_pred, dtype=np.float64)
    if truth.shape != prediction.shape:
        raise ValueError(f"Metric shape mismatch: {truth.shape} != {prediction.shape}")
    if len(truth) == 0:
        raise ValueError("Cannot calculate metrics for an empty subset.")
    if not (np.isfinite(truth).all() and np.isfinite(prediction).all()):
        raise ValueError("Metric inputs contain non-finite values.")

    residual = prediction - truth
    sum_squared_error = float(np.dot(residual, residual))
    centred_truth = truth - truth.mean()
    total_sum_squares = float(np.dot(centred_truth, centred_truth))
    if np.std(truth) == 0 or np.std(prediction) == 0:
        correlation = float("nan")
    else:
        correlation = float(np.corrcoef(truth, prediction)[0, 1])
    r_squared = (
        float(1.0 - sum_squared_error / total_sum_squares)
        if total_sum_squares > 0
        else float("nan")
    )
    return {
        "n": int(len(truth)),
        "rmse": float(np.sqrt(sum_squared_error / len(truth))),
        "mae": float(np.mean(np.abs(residual))),
        "bias": float(np.mean(residual)),
        "r": correlation,
        "r2": r_squared,
    }
