"""Command-line orchestration for the spatial-holdout experiment."""

from __future__ import annotations

import argparse
import json
import os
import tempfile
import time

if "JOBLIB_TEMP_FOLDER" not in os.environ:
    shared_memory = "/dev/shm"
    os.environ["JOBLIB_TEMP_FOLDER"] = (
        shared_memory
        if os.path.isdir(shared_memory) and os.access(shared_memory, os.W_OK)
        else tempfile.gettempdir()
    )

from irp_cc125.config import EXPERIMENT_ID
from irp_cc125.spatial_holdout.config import (
    EVALUATION_PATH, OUT_DIR, PREDICTION_DIR, RUN_SUMMARY_PATH, TUNING_PATH,
)
from irp_cc125.spatial_holdout.modeling import (
    print_primary_summary, require_complete_tuning,
    run_final_fit_and_evaluation, run_tuning,
)
from irp_cc125.spatial_holdout.utils import atomic_json_dump, sha256_file, utc_now
from irp_cc125.spatial_holdout.validation import (
    make_split, materialise_design, validate_layout_and_get_points,
    validate_source_manifest,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Run a nested point-level spatial holdout for the versioned "
            "Scotland experiment."
        )
    )
    parser.add_argument(
        "--phase",
        choices=("all", "tune", "fit-evaluate"),
        default="all",
        help="Run all stages, tuning only, or final fitting/evaluation only.",
    )
    parser.add_argument(
        "--validate-only",
        action="store_true",
        help="Validate inputs and materialise the deterministic split, then exit.",
    )
    parser.add_argument("--n-jobs", type=int, default=8)
    return parser.parse_args()

def main() -> None:
    args = parse_args()
    if args.n_jobs < 1:
        raise ValueError("--n-jobs must be positive.")
    invocation_start = time.time()
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    PREDICTION_DIR.mkdir(parents=True, exist_ok=True)

    _, source_manifest_hash, input_hashes = validate_source_manifest()
    layout = validate_layout_and_get_points()
    train_ids, holdout_ids, strata = make_split(layout["flags"])
    _, design_hash = materialise_design(
        source_manifest_hash,
        input_hashes,
        layout,
        train_ids,
        holdout_ids,
        strata,
        args.n_jobs,
    )

    print(f"Parent experiment: {EXPERIMENT_ID}")
    print(f"Spatial output: {OUT_DIR}")
    print(
        f"Point split: {len(train_ids):,} train-eligible / "
        f"{len(holdout_ids):,} held out"
    )
    print(f"Design SHA-256: {design_hash}")
    if args.validate_only:
        print("Validation and deterministic point split completed; no models were run.")
        return

    tuning = None
    if args.phase in ("all", "tune"):
        tuning = run_tuning(
            design_hash,
            args.n_jobs,
            train_ids,
            holdout_ids,
            layout["train_years_by_time"],
        )
    if args.phase == "tune":
        require_complete_tuning(tuning)
        print(f"Completed tuning: {TUNING_PATH}")
    else:
        if tuning is None:
            if not TUNING_PATH.is_file():
                raise FileNotFoundError(f"Run --phase tune first: {TUNING_PATH}")
            with TUNING_PATH.open() as handle:
                tuning = json.load(handle)
            if tuning.get("design_sha256") != design_hash:
                raise ValueError("Tuning results do not match the spatial design.")
        evaluation = run_final_fit_and_evaluation(
            design_hash,
            tuning,
            train_ids,
            holdout_ids,
            layout["flags"],
            layout["train_years_by_time"],
            layout["test_years_by_time"],
        )
        print_primary_summary(evaluation)

    summary = {
        "updated_utc": utc_now(),
        "design_sha256": design_hash,
        "phase": args.phase,
        "invocation_elapsed_seconds": time.time() - invocation_start,
        "tuning_results": (
            {
                "file": TUNING_PATH.name,
                "sha256": sha256_file(TUNING_PATH),
            }
            if TUNING_PATH.is_file()
            else None
        ),
        "evaluation_results": (
            {
                "file": EVALUATION_PATH.name,
                "sha256": sha256_file(EVALUATION_PATH),
            }
            if EVALUATION_PATH.is_file()
            else None
        ),
    }
    atomic_json_dump(summary, RUN_SUMMARY_PATH)
    print(f"Saved spatial experiment outputs to {OUT_DIR}")
