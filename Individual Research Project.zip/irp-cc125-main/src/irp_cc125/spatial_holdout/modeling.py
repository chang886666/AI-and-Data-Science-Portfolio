"""Model tuning, fitting, prediction, and evaluation for spatial holdout."""

from __future__ import annotations

import gc
import json
import time

import joblib
import numpy as np
import xgboost
from sklearn.ensemble import RandomForestRegressor

from irp_cc125.config import ARRAY_PATHS, EXPERIMENT_ID, FEATURE_NAMES
from irp_cc125.spatial_holdout.config import (
    EVALUATION_PATH, LINEAR_METADATA_PATH, LINEAR_MODEL_PATH, LINEAR_SPECS,
    N_POINTS_EXPECTED, OUT_DIR, PREDICTION_DIR, RF_GRID, ROW_CHUNK_SIZE,
    TIME_CHUNK_SIZE, TUNING_PATH, XGB_GRID, rf_fixed, xgb_fixed,
)
from irp_cc125.spatial_holdout.utils import (
    atomic_joblib_dump, atomic_json_dump, atomic_npy_save, atomic_npz_save,
    combo_key, regression_metrics, sha256_file, utc_now,
)


def extract_xy(
    x_3d: np.ndarray,
    y_2d: np.ndarray,
    time_ids: np.ndarray,
    point_ids: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    n_rows = len(time_ids) * len(point_ids)
    selected_x = np.empty((n_rows, len(FEATURE_NAMES)), dtype=np.float32)
    selected_y = np.empty(n_rows, dtype=np.float32)
    cursor = 0
    for start in range(0, len(time_ids), TIME_CHUNK_SIZE):
        batch_times = time_ids[start : start + TIME_CHUNK_SIZE]
        batch_rows = len(batch_times) * len(point_ids)
        selected_x[cursor : cursor + batch_rows] = x_3d[
            batch_times[:, None], point_ids[None, :], :
        ].reshape(batch_rows, len(FEATURE_NAMES))
        selected_y[cursor : cursor + batch_rows] = y_2d[
            batch_times[:, None], point_ids[None, :]
        ].reshape(batch_rows)
        cursor += batch_rows
    return selected_x, selected_y

def extract_vector(
    values_2d: np.ndarray, time_ids: np.ndarray, point_ids: np.ndarray
) -> np.ndarray:
    output = np.empty(len(time_ids) * len(point_ids), dtype=np.float32)
    cursor = 0
    for start in range(0, len(time_ids), TIME_CHUNK_SIZE):
        batch_times = time_ids[start : start + TIME_CHUNK_SIZE]
        batch_rows = len(batch_times) * len(point_ids)
        output[cursor : cursor + batch_rows] = values_2d[
            batch_times[:, None], point_ids[None, :]
        ].reshape(batch_rows)
        cursor += batch_rows
    return output

def initialise_or_load_tuning(
    design_hash: str, n_jobs: int, holdout_point_ids: np.ndarray
) -> dict:
    holdout_hash = sha256_arrays(holdout_point_ids)
    if TUNING_PATH.exists():
        with TUNING_PATH.open() as handle:
            results = json.load(handle)
        if results.get("design_sha256") != design_hash:
            raise ValueError("Tuning cache does not match the spatial design.")
        if results.get("holdout_point_ids_sha256") != holdout_hash:
            raise ValueError("Tuning cache does not match the held-out point IDs.")
        if results.get("fixed_parameters") != {
            "RandomForest": rf_fixed(n_jobs),
            "XGBoost": xgb_fixed(n_jobs),
        }:
            raise ValueError("Tuning cache was created with different fixed parameters.")
        return results
    return {
        "created_utc": utc_now(),
        "updated_utc": utc_now(),
        "design_sha256": design_hash,
        "holdout_point_ids_sha256": holdout_hash,
        "selection_metric": "lowest mean forward-chaining RMSE",
        "fixed_parameters": {
            "RandomForest": rf_fixed(n_jobs),
            "XGBoost": xgb_fixed(n_jobs),
        },
        "models": {"XGBoost": {}, "RandomForest": {}},
    }

def tune_model_grid(
    model_name: str,
    grid: list[dict],
    fixed_params: dict,
    model_class,
    results: dict,
    x_3d: np.ndarray,
    y_2d: np.ndarray,
    train_years_by_time: np.ndarray,
    train_point_ids: np.ndarray,
) -> None:
    for combination_number, varying_params in enumerate(grid, start=1):
        key = combo_key(varying_params)
        if key in results["models"][model_name]:
            print(f"Skipping completed {model_name} {varying_params}")
            continue

        print(f"\n=== {model_name} {combination_number}/{len(grid)}: {varying_params} ===")
        combination_start = time.time()
        fold_results = []
        for fold in FORWARD_FOLDS:
            fold_start = time.time()
            fit_times = np.flatnonzero(np.isin(train_years_by_time, fold["train"]))
            validation_times = np.flatnonzero(
                np.isin(train_years_by_time, fold["val"])
            )
            x_fit, y_fit = extract_xy(
                x_3d, y_2d, fit_times, train_point_ids
            )
            x_validation, y_validation = extract_xy(
                x_3d, y_2d, validation_times, train_point_ids
            )
            model = model_class(**fixed_params, **varying_params)
            model.fit(x_fit, y_fit)
            prediction = np.asarray(model.predict(x_validation), dtype=np.float32)
            fold_result = {
                "fold": fold["name"],
                "train_years": fold["train"],
                "validation_years": fold["val"],
                "n_train_points": int(len(train_point_ids)),
                "n_train_rows": int(len(y_fit)),
                "n_validation_rows": int(len(y_validation)),
                "elapsed_seconds": time.time() - fold_start,
                **regression_metrics(y_validation, prediction),
            }
            fold_results.append(fold_result)
            print(
                f"  {fold['name']}: RMSE={fold_result['rmse']:.4f}, "
                f"MAE={fold_result['mae']:.4f}, bias={fold_result['bias']:+.4f}"
            )
            del model, prediction, x_fit, y_fit, x_validation, y_validation
            gc.collect()

        entry = {
            "varying_params": varying_params,
            "params": {**fixed_params, **varying_params},
            "folds": fold_results,
            "mean_rmse": float(np.mean([item["rmse"] for item in fold_results])),
            "std_rmse": float(np.std([item["rmse"] for item in fold_results])),
            "mean_mae": float(np.mean([item["mae"] for item in fold_results])),
            "mean_bias": float(np.mean([item["bias"] for item in fold_results])),
            "elapsed_seconds": time.time() - combination_start,
        }
        results["models"][model_name][key] = entry
        results["updated_utc"] = utc_now()
        atomic_json_dump(results, TUNING_PATH)
        print(f"  mean forward RMSE={entry['mean_rmse']:.4f}; saved {TUNING_PATH}")

def run_tuning(
    design_hash: str,
    n_jobs: int,
    train_point_ids: np.ndarray,
    holdout_point_ids: np.ndarray,
    train_years_by_time: np.ndarray,
) -> dict:
    x = np.load(ARRAY_PATHS["X_train"], mmap_mode="r")
    y = np.load(ARRAY_PATHS["y_train"], mmap_mode="r")
    x_3d = x.reshape(-1, N_POINTS_EXPECTED, len(FEATURE_NAMES))
    y_2d = y.reshape(-1, N_POINTS_EXPECTED)
    results = initialise_or_load_tuning(
        design_hash, n_jobs, holdout_point_ids
    )

    tune_model_grid(
        "XGBoost",
        XGB_GRID,
        xgb_fixed(n_jobs),
        xgboost.XGBRegressor,
        results,
        x_3d,
        y_2d,
        train_years_by_time,
        train_point_ids,
    )
    tune_model_grid(
        "RandomForest",
        RF_GRID,
        rf_fixed(n_jobs),
        RandomForestRegressor,
        results,
        x_3d,
        y_2d,
        train_years_by_time,
        train_point_ids,
    )
    return results

def select_best(entries: dict) -> dict:
    if not entries:
        raise ValueError("No completed tuning entries are available.")
    return min(
        entries.values(),
        key=lambda item: (
            item["mean_rmse"],
            item["std_rmse"],
            combo_key(item["varying_params"]),
        ),
    )

def require_complete_tuning(results: dict) -> tuple[dict, dict]:
    if len(results["models"]["XGBoost"]) != len(XGB_GRID):
        raise ValueError("XGBoost tuning grid is incomplete.")
    if len(results["models"]["RandomForest"]) != len(RF_GRID):
        raise ValueError("RandomForest tuning grid is incomplete.")
    return (
        select_best(results["models"]["RandomForest"]),
        select_best(results["models"]["XGBoost"]),
    )

def fit_ols(x: np.ndarray, y: np.ndarray, indices: list[int]) -> dict[str, np.ndarray]:
    n = len(y)
    sums = np.zeros(len(indices), dtype=np.float64)
    sums_sq = np.zeros(len(indices), dtype=np.float64)
    for start in range(0, n, ROW_CHUNK_SIZE):
        stop = min(start + ROW_CHUNK_SIZE, n)
        values = np.asarray(x[start:stop, indices], dtype=np.float64)
        sums += values.sum(axis=0)
        sums_sq += np.square(values).sum(axis=0)
    mean = sums / n
    variance = np.maximum(sums_sq / n - mean**2, 0.0)
    scale = np.sqrt(variance)
    scale[scale == 0] = 1.0

    dimension = len(indices) + 1
    gram = np.zeros((dimension, dimension), dtype=np.float64)
    rhs = np.zeros(dimension, dtype=np.float64)
    for start in range(0, n, ROW_CHUNK_SIZE):
        stop = min(start + ROW_CHUNK_SIZE, n)
        values = np.asarray(x[start:stop, indices], dtype=np.float64)
        standardized = (values - mean) / scale
        design = np.empty((len(values), dimension), dtype=np.float64)
        design[:, 0] = 1.0
        design[:, 1:] = standardized
        target = np.asarray(y[start:stop], dtype=np.float64)
        gram += design.T @ design
        rhs += design.T @ target
    parameters = np.linalg.pinv(gram, rcond=1e-12) @ rhs
    return {
        "indices": np.asarray(indices, dtype=np.int64),
        "mean": mean,
        "scale": scale,
        "intercept": parameters[:1],
        "coefficients_standardized": parameters[1:],
    }

def predict_ols(x: np.ndarray, fitted: dict[str, np.ndarray]) -> np.ndarray:
    output = np.empty(len(x), dtype=np.float32)
    indices = fitted["indices"]
    for start in range(0, len(x), ROW_CHUNK_SIZE):
        stop = min(start + ROW_CHUNK_SIZE, len(x))
        values = np.asarray(x[start:stop, indices], dtype=np.float64)
        standardized = (values - fitted["mean"]) / fitted["scale"]
        output[start:stop] = (
            fitted["intercept"][0]
            + standardized @ fitted["coefficients_standardized"]
        )
    return output

def prediction_path(evaluation: str, model_name: str) -> Path:
    safe_name = model_name.lower().replace(" ", "_")
    return PREDICTION_DIR / f"{evaluation}_{safe_name}.npy"

def save_prediction(evaluation: str, model_name: str, values: np.ndarray) -> Path:
    path = prediction_path(evaluation, model_name)
    atomic_npy_save(np.asarray(values, dtype=np.float32), path)
    return path

def fit_linear_models(
    x_fit: np.ndarray,
    y_fit: np.ndarray,
    evaluation_inputs: dict[str, np.ndarray],
    design_hash: str,
) -> dict:
    fitted_models = {}
    stored_arrays = {}
    records = {}
    for model_name, names in LINEAR_SPECS.items():
        print(f"Fitting {model_name} on {len(y_fit):,} rows...")
        start = time.time()
        indices = [FEATURE_NAMES.index(name) for name in names]
        fitted = fit_ols(x_fit, y_fit, indices)
        fitted_models[model_name] = fitted
        for key, value in fitted.items():
            stored_arrays[f"{model_name.lower()}_{key}"] = value
        prediction_files = {}
        for evaluation, values in evaluation_inputs.items():
            prediction = predict_ols(values, fitted)
            path = save_prediction(evaluation, model_name, prediction)
            prediction_files[evaluation] = {
                "file": str(path.relative_to(OUT_DIR)),
                "sha256": sha256_file(path),
            }
        records[model_name] = {
            "feature_names": names,
            "feature_indices": indices,
            "fit_seconds": time.time() - start,
            "prediction_files": prediction_files,
        }
    atomic_npz_save(LINEAR_MODEL_PATH, **stored_arrays)
    metadata = {
        "created_utc": utc_now(),
        "design_sha256": design_hash,
        "fit_method": "chunked exact OLS on standardised predictors",
        "n_fit_rows": int(len(y_fit)),
        "model_file": LINEAR_MODEL_PATH.name,
        "model_sha256": sha256_file(LINEAR_MODEL_PATH),
        "models": records,
    }
    atomic_json_dump(metadata, LINEAR_METADATA_PATH)
    del fitted_models
    return metadata

def load_or_fit_tree(
    model_name: str,
    model_class,
    params: dict,
    x_fit: np.ndarray,
    y_fit: np.ndarray,
    design_hash: str,
    tuning_hash: str,
) -> tuple[object, dict]:
    stem = model_name.lower()
    model_path = OUT_DIR / f"{stem}_model.joblib"
    metadata_path = OUT_DIR / f"{stem}_model_metadata.json"
    if model_path.exists() and metadata_path.exists():
        with metadata_path.open() as handle:
            metadata = json.load(handle)
        valid = (
            metadata.get("design_sha256") == design_hash
            and metadata.get("tuning_results_sha256") == tuning_hash
            and metadata.get("params") == params
            and metadata.get("model_sha256") == sha256_file(model_path)
        )
        if not valid:
            raise ValueError(f"Existing {model_name} model has stale provenance.")
        print(f"Loading completed {model_name} model from {model_path}...")
        return joblib.load(model_path), metadata

    print(f"Fitting final {model_name} on {len(y_fit):,} rows...")
    start = time.time()
    model = model_class(**params)
    model.fit(x_fit, y_fit)
    fit_seconds = time.time() - start
    atomic_joblib_dump(model, model_path)
    metadata = {
        "created_utc": utc_now(),
        "design_sha256": design_hash,
        "tuning_results_sha256": tuning_hash,
        "params": params,
        "n_fit_rows": int(len(y_fit)),
        "fit_seconds": fit_seconds,
        "model_file": model_path.name,
        "model_sha256": sha256_file(model_path),
    }
    atomic_json_dump(metadata, metadata_path)
    return model, metadata

def predict_tree_evaluations(
    model_name: str,
    model,
    evaluation_inputs: dict[str, np.ndarray],
    model_metadata: dict,
) -> dict:
    prediction_files = {}
    prediction_seconds = {}
    for evaluation, values in evaluation_inputs.items():
        start = time.time()
        prediction = np.asarray(model.predict(values), dtype=np.float32)
        path = save_prediction(evaluation, model_name, prediction)
        prediction_seconds[evaluation] = time.time() - start
        prediction_files[evaluation] = {
            "file": str(path.relative_to(OUT_DIR)),
            "sha256": sha256_file(path),
        }
        del prediction
    model_metadata = {
        **model_metadata,
        "prediction_seconds": prediction_seconds,
        "prediction_files": prediction_files,
    }
    metadata_path = OUT_DIR / f"{model_name.lower()}_model_metadata.json"
    atomic_json_dump(model_metadata, metadata_path)
    return model_metadata

def calculate_evaluation(
    evaluation_name: str,
    truth: np.ndarray,
    years_by_time: np.ndarray,
    holdout_point_ids: np.ndarray,
    flags: np.ndarray,
    model_names: list[str],
) -> dict:
    n_times = len(years_by_time)
    n_points = len(holdout_point_ids)
    if len(truth) != n_times * n_points:
        raise ValueError(f"Unexpected target length for {evaluation_name}.")
    row_flags = np.tile(flags[holdout_point_ids], (n_times, 1))
    row_years = np.repeat(years_by_time, n_points)
    subset_masks = {
        "Overall": np.ones(len(truth), dtype=bool),
        "Complex": row_flags[:, 0],
        "Flat": row_flags[:, 1],
        "Coastal": row_flags[:, 2],
    }

    result = {
        "n_points": int(n_points),
        "n_rows": int(len(truth)),
        "years": sorted(np.unique(row_years).astype(int).tolist()),
        "subsets": {},
        "by_year": {},
        "rmse_improvement_over_bilinear_percent": {},
        "prediction_files": {},
    }
    predictions = {}
    for model_name in model_names:
        path = prediction_path(evaluation_name, model_name)
        prediction = np.load(path, mmap_mode="r")
        if prediction.shape != truth.shape or not np.isfinite(prediction).all():
            raise ValueError(f"Invalid prediction file: {path}")
        predictions[model_name] = prediction
        result["prediction_files"][model_name] = {
            "file": str(path.relative_to(OUT_DIR)),
            "sha256": sha256_file(path),
        }

    for subset_name, mask in subset_masks.items():
        result["subsets"][subset_name] = {
            model_name: regression_metrics(truth[mask], prediction[mask])
            for model_name, prediction in predictions.items()
        }
        bilinear_rmse = result["subsets"][subset_name]["Bilinear"]["rmse"]
        result["rmse_improvement_over_bilinear_percent"][subset_name] = {
            model_name: float(
                100.0
                * (bilinear_rmse - result["subsets"][subset_name][model_name]["rmse"])
                / bilinear_rmse
            )
            for model_name in model_names
            if model_name != "Bilinear"
        }

    for year in result["years"]:
        mask = row_years == year
        result["by_year"][str(year)] = {
            model_name: regression_metrics(truth[mask], prediction[mask])
            for model_name, prediction in predictions.items()
        }
    return result

def run_final_fit_and_evaluation(
    design_hash: str,
    tuning: dict,
    train_point_ids: np.ndarray,
    holdout_point_ids: np.ndarray,
    flags: np.ndarray,
    train_years_by_time: np.ndarray,
    test_years_by_time: np.ndarray,
) -> dict:
    best_rf, best_xgb = require_complete_tuning(tuning)
    tuning_hash = sha256_file(TUNING_PATH)
    x_train = np.load(ARRAY_PATHS["X_train"], mmap_mode="r")
    y_train = np.load(ARRAY_PATHS["y_train"], mmap_mode="r")
    x_test = np.load(ARRAY_PATHS["X_test"], mmap_mode="r")
    y_test = np.load(ARRAY_PATHS["y_test"], mmap_mode="r")
    bilinear_test = np.load(ARRAY_PATHS["bilinear_test"], mmap_mode="r")
    x_train_3d = x_train.reshape(-1, N_POINTS_EXPECTED, len(FEATURE_NAMES))
    y_train_2d = y_train.reshape(-1, N_POINTS_EXPECTED)
    x_test_3d = x_test.reshape(-1, N_POINTS_EXPECTED, len(FEATURE_NAMES))
    y_test_2d = y_test.reshape(-1, N_POINTS_EXPECTED)
    bilinear_test_2d = bilinear_test.reshape(-1, N_POINTS_EXPECTED)

    all_train_times = np.arange(len(train_years_by_time), dtype=np.int64)
    all_test_times = np.arange(len(test_years_by_time), dtype=np.int64)
    print("Materialising float32 rows for final fitting and held-out evaluation...")
    x_fit, y_fit = extract_xy(
        x_train_3d, y_train_2d, all_train_times, train_point_ids
    )
    x_historical_unseen, y_historical_unseen = extract_xy(
        x_train_3d, y_train_2d, all_train_times, holdout_point_ids
    )
    x_future_unseen, y_future_unseen = extract_xy(
        x_test_3d, y_test_2d, all_test_times, holdout_point_ids
    )
    x_future_seen, y_future_seen = extract_xy(
        x_test_3d, y_test_2d, all_test_times, train_point_ids
    )
    evaluation_inputs = {
        "future_unseen": x_future_unseen,
        "future_seen": x_future_seen,
        "historical_unseen": x_historical_unseen,
    }

    PREDICTION_DIR.mkdir(parents=True, exist_ok=True)
    # Bilinear is the first predictor for the historical diagnostic and the
    # validated standalone reference for the independent test period.
    save_prediction(
        "historical_unseen", "Bilinear", x_historical_unseen[:, 0]
    )
    future_unseen_bilinear = extract_vector(
        bilinear_test_2d, all_test_times, holdout_point_ids
    )
    future_seen_bilinear = extract_vector(
        bilinear_test_2d, all_test_times, train_point_ids
    )
    save_prediction("future_unseen", "Bilinear", future_unseen_bilinear)
    save_prediction("future_seen", "Bilinear", future_seen_bilinear)
    del future_unseen_bilinear, future_seen_bilinear

    linear_metadata = fit_linear_models(
        x_fit, y_fit, evaluation_inputs, design_hash
    )

    model_records = {"linear_models": linear_metadata}
    for model_name, model_class, selected in (
        ("RandomForest", RandomForestRegressor, best_rf),
        ("XGBoost", xgboost.XGBRegressor, best_xgb),
    ):
        model, model_metadata = load_or_fit_tree(
            model_name,
            model_class,
            selected["params"],
            x_fit,
            y_fit,
            design_hash,
            tuning_hash,
        )
        model_metadata = predict_tree_evaluations(
            model_name, model, evaluation_inputs, model_metadata
        )
        model_records[model_name] = model_metadata
        del model
        gc.collect()

    model_names = [
        "Bilinear",
        "LinearERA5Seasonal",
        "LinearFullFeatures",
        "RandomForest",
        "XGBoost",
    ]
    evaluation = {
        "created_utc": utc_now(),
        "spatial_experiment_id": f"{EXPERIMENT_ID}_spatial_holdout_v1",
        "parent_experiment_id": EXPERIMENT_ID,
        "design_sha256": design_hash,
        "tuning_results_sha256": tuning_hash,
        "primary_evaluation": "future_unseen",
        "quantile_mapping_included": False,
        "quantile_mapping_exclusion_reason": (
            "Per-point quantile mapping cannot predict a point with no historical "
            "paired CERRA targets."
        ),
        "selected_models": {
            "RandomForest": best_rf,
            "XGBoost": best_xgb,
        },
        "evaluations": {
            "future_unseen": calculate_evaluation(
                "future_unseen",
                y_future_unseen,
                test_years_by_time,
                holdout_point_ids,
                flags,
                model_names,
            ),
            "future_seen": calculate_evaluation(
                "future_seen",
                y_future_seen,
                test_years_by_time,
                train_point_ids,
                flags,
                model_names,
            ),
            "historical_unseen": calculate_evaluation(
                "historical_unseen",
                y_historical_unseen,
                train_years_by_time,
                holdout_point_ids,
                flags,
                model_names,
            ),
        },
        "model_records": model_records,
    }
    future_unseen = evaluation["evaluations"]["future_unseen"]["subsets"]
    future_seen = evaluation["evaluations"]["future_seen"]["subsets"]
    evaluation["future_seen_vs_unseen_gap"] = {}
    for subset_name in future_unseen:
        evaluation["future_seen_vs_unseen_gap"][subset_name] = {}
        for model_name in model_names:
            seen_rmse = future_seen[subset_name][model_name]["rmse"]
            unseen_rmse = future_unseen[subset_name][model_name]["rmse"]
            evaluation["future_seen_vs_unseen_gap"][subset_name][model_name] = {
                "rmse_unseen_minus_seen": float(unseen_rmse - seen_rmse),
                "rmse_relative_increase_percent": float(
                    100.0 * (unseen_rmse - seen_rmse) / seen_rmse
                ),
            }
    atomic_json_dump(evaluation, EVALUATION_PATH)

    del (
        x_fit,
        y_fit,
        x_historical_unseen,
        y_historical_unseen,
        x_future_unseen,
        y_future_unseen,
        x_future_seen,
        y_future_seen,
    )
    gc.collect()
    return evaluation

def print_primary_summary(evaluation: dict) -> None:
    overall = evaluation["evaluations"]["future_unseen"]["subsets"][
        "Overall"
    ]
    print("\n=== Primary unseen-point + unseen-time results ===")
    print(f"{'Model':24s} {'RMSE':>8s} {'MAE':>8s} {'Bias':>8s} {'r':>8s} {'R2':>8s}")
    for model_name, values in overall.items():
        print(
            f"{model_name:24s} {values['rmse']:8.4f} {values['mae']:8.4f} "
            f"{values['bias']:+8.4f} {values['r']:8.4f} {values['r2']:8.4f}"
        )
