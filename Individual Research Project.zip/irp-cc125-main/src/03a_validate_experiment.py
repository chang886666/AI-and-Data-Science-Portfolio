#!/usr/bin/env python3
"""Validate and fingerprint all inputs before tuning or model training."""

from __future__ import annotations

import hashlib
import json
import platform
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import sklearn
import xgboost

from experiment_config import (
    ARRAY_PATHS,
    EXPERIMENT_DIR,
    EXPERIMENT_ID,
    FEATURE_NAMES,
    FORWARD_FOLDS,
    TERRAIN_METADATA_PATH,
    TEST_YEARS,
    TRAIN_YEARS,
)


def sha256_file(path: Path, chunk_size: int = 8 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def require_finite(name: str, array: np.ndarray) -> None:
    if not np.isfinite(array).all():
        count = int((~np.isfinite(array)).sum())
        raise ValueError(f"{name} contains {count:,} non-finite values.")


def main() -> None:
    missing = [str(path) for path in ARRAY_PATHS.values() if not path.is_file()]
    if not TERRAIN_METADATA_PATH.is_file():
        missing.append(str(TERRAIN_METADATA_PATH))
    if missing:
        raise FileNotFoundError(f"Missing experiment inputs: {missing}")

    arrays = {
        name: np.load(path, mmap_mode="r") for name, path in ARRAY_PATHS.items()
    }
    x_train = arrays["X_train"]
    y_train = arrays["y_train"]
    meta_train = arrays["train_metadata"]
    x_test = arrays["X_test"]
    y_test = arrays["y_test"]
    meta_test = arrays["test_metadata"]

    if x_train.ndim != 2 or x_train.shape[1] != len(FEATURE_NAMES):
        raise ValueError(f"Unexpected X_train shape: {x_train.shape}")
    if x_test.ndim != 2 or x_test.shape[1] != len(FEATURE_NAMES):
        raise ValueError(f"Unexpected X_test shape: {x_test.shape}")
    if not (len(x_train) == len(y_train) == len(meta_train)):
        raise ValueError("Training arrays have inconsistent row counts.")
    if not (len(x_test) == len(y_test) == len(meta_test)):
        raise ValueError("Test arrays have inconsistent row counts.")
    if meta_train.shape[1] != 9 or meta_test.shape[1] != 9:
        raise ValueError("Metadata arrays must have nine columns.")

    for name, array in arrays.items():
        require_finite(name, array)

    train_years = sorted(np.unique(meta_train[:, 2].astype(int)).tolist())
    test_years = sorted(np.unique(meta_test[:, 2].astype(int)).tolist())
    if train_years != TRAIN_YEARS:
        raise ValueError(f"Training years {train_years} != expected {TRAIN_YEARS}")
    if test_years != TEST_YEARS:
        raise ValueError(f"Test years {test_years} != expected {TEST_YEARS}")
    if set(train_years) & set(test_years):
        raise ValueError("Train and test years overlap.")

    with TERRAIN_METADATA_PATH.open() as handle:
        terrain_metadata = json.load(handle)
    if terrain_metadata.get("feature_names") != FEATURE_NAMES[1:7]:
        raise ValueError(
            "Terrain feature schema does not match model feature schema: "
            f"{terrain_metadata.get('feature_names')}"
        )

    # Verify that the first time block carries the exact saved terrain rows.
    terrain = arrays["land_terrain_features"]
    n_points = len(terrain)
    if terrain.shape != (2022, 6):
        raise ValueError(f"Unexpected terrain feature shape: {terrain.shape}")
    if not np.allclose(x_train[:n_points, 1:7], terrain, rtol=0.0, atol=1e-10):
        raise ValueError("X_train terrain columns/order do not match saved terrain data.")

    for fold in FORWARD_FOLDS:
        if max(fold["train"]) >= min(fold["val"]):
            raise ValueError(f"Fold is not forward-chaining: {fold}")

    print("Computing SHA-256 fingerprints (this reads each input once)...")
    fingerprints = {
        name: sha256_file(path) for name, path in ARRAY_PATHS.items()
    }
    fingerprints["terrain_metadata"] = sha256_file(TERRAIN_METADATA_PATH)

    manifest = {
        "experiment_id": EXPERIMENT_ID,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "feature_names": FEATURE_NAMES,
        "train_years": TRAIN_YEARS,
        "test_years": TEST_YEARS,
        "forward_folds": FORWARD_FOLDS,
        "array_schema": {
            name: {"shape": list(array.shape), "dtype": str(array.dtype)}
            for name, array in arrays.items()
        },
        "sha256": fingerprints,
        "software": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "scikit_learn": sklearn.__version__,
            "xgboost": xgboost.__version__,
        },
    }

    EXPERIMENT_DIR.mkdir(parents=True, exist_ok=True)
    manifest_path = EXPERIMENT_DIR / "experiment_manifest.json"
    with manifest_path.open("w") as handle:
        json.dump(manifest, handle, indent=2)

    print(f"Experiment: {EXPERIMENT_ID}")
    print(f"Features: {FEATURE_NAMES}")
    print(f"Train: {x_train.shape}, years={train_years}")
    print(f"Test:  {x_test.shape}, years={test_years}")
    print(f"Forward folds: {FORWARD_FOLDS}")
    print(f"Validated manifest: {manifest_path}")


if __name__ == "__main__":
    main()
