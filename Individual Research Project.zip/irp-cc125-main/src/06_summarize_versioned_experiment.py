#!/usr/bin/env python3
"""Create a concise Markdown summary from versioned experiment artefacts."""

from __future__ import annotations

import json

from experiment_config import EXPERIMENT_DIR, EXPERIMENT_ID


EVALUATION_PATH = EXPERIMENT_DIR / "evaluation_results.json"
PERMUTATION_PATH = EXPERIMENT_DIR / "block_permutation_importance.json"
ABLATION_PATH = EXPERIMENT_DIR / "ablation_results.json"
SPATIAL_HOLDOUT_PATH = (
    EXPERIMENT_DIR / "spatial_holdout_v1" / "evaluation_results.json"
)
OUT_PATH = EXPERIMENT_DIR / "experiment_summary.md"


def load(path):
    if not path.is_file():
        raise FileNotFoundError(f"Required result is missing: {path}")
    with path.open() as handle:
        result = json.load(handle)
    if result.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError(f"Result belongs to another experiment: {path}")
    return result


def main() -> None:
    evaluation = load(EVALUATION_PATH)
    permutation = load(PERMUTATION_PATH)
    ablation = load(ABLATION_PATH)
    spatial_holdout = None
    if SPATIAL_HOLDOUT_PATH.is_file():
        with SPATIAL_HOLDOUT_PATH.open() as handle:
            spatial_holdout = json.load(handle)
        if spatial_holdout.get("parent_experiment_id") != EXPERIMENT_ID:
            raise ValueError(
                f"Spatial result belongs to another experiment: "
                f"{SPATIAL_HOLDOUT_PATH}"
            )

    lines = [
        f"# Experiment summary: `{EXPERIMENT_ID}`",
        "",
        "## Untouched 2019–2020 test set",
        "",
        "| Method | RMSE | MAE | Bias | R² |",
        "|---|---:|---:|---:|---:|",
    ]
    for model, values in evaluation["subsets"]["Overall"].items():
        lines.append(
            f"| {model} | {values['rmse']:.4f} | {values['mae']:.4f} | "
            f"{values['bias']:+.4f} | {values['r2']:.4f} |"
        )

    lines.extend(
        [
            "",
            "## Baseline ladder",
            "",
            "- `Bilinear`: uncorrected spatial interpolation of ERA5.",
            "- `LinearERA5Seasonal`: global linear correction using ERA5 wind and cyclic month terms.",
            "- `LinearFullFeatures`: the same nine predictors as RF/XGBoost in a linear model.",
            "- `QuantileMapping`: per-point, per-month historical calibration with 20 quantile intervals and endpoint clipping outside the training range.",
            "- Per-point quantile mapping implicitly contains location-specific historical information; its comparison with XGBoost is not a terrain-only causal contrast.",
        ]
    )

    if spatial_holdout is not None:
        future_unseen = spatial_holdout["evaluations"]["future_unseen"]
        future_seen = spatial_holdout["evaluations"]["future_seen"]
        lines.extend(
            [
                "",
                "## Within-domain transfer to randomly held-out points",
                "",
                (
                    f"The primary spatial robustness set contains "
                    f"{future_unseen['n_points']:,} points and "
                    f"{future_unseen['n_rows']:,} observations from 2019–2020."
                ),
                "",
                "| Method | Unseen-point RMSE | Seen-point RMSE | Unseen-point MAE | Unseen-point Bias |",
                "|---|---:|---:|---:|---:|",
            ]
        )
        for model_name, unseen_values in future_unseen["subsets"]["Overall"].items():
            seen_values = future_seen["subsets"]["Overall"][model_name]
            lines.append(
                f"| {model_name} | {unseen_values['rmse']:.4f} | "
                f"{seen_values['rmse']:.4f} | {unseen_values['mae']:.4f} | "
                f"{unseen_values['bias']:+.4f} |"
            )
        lines.extend(
            [
                "",
                "This is a random point-holdout robustness analysis within the Scotland domain, not spatially blocked extrapolation to an unseen region.",
                "Per-point quantile mapping is excluded because it requires historical paired targets at each prediction point.",
            ]
        )

    lines.extend(["", "## Refit ablation (overall RMSE delta)", ""])
    lines.extend(
        [
            "Positive values mean performance became worse after removal.",
            "",
            "| Removed information | Random Forest | XGBoost |",
            "|---|---:|---:|",
        ]
    )
    for name, result in ablation["variants"].items():
        rf = result["models"]["RandomForest"]["overall_rmse_delta"]
        xgb = result["models"]["XGBoost"]["overall_rmse_delta"]
        lines.append(f"| {name} | {rf:+.4f} | {xgb:+.4f} |")

    lines.extend(["", "## Block permutation importance (RMSE increase)", ""])
    lines.extend(
        [
            "| Feature/block | Random Forest | XGBoost |",
            "|---|---:|---:|",
        ]
    )
    model_results = permutation["models"]
    feature_order = list(model_results["RandomForest"]["features"])
    for feature in feature_order:
        rf = model_results["RandomForest"]["features"][feature]["rmse_increase_mean"]
        xgb = model_results["XGBoost"]["features"][feature]["rmse_increase_mean"]
        lines.append(f"| {feature} | {rf:+.4f} | {xgb:+.4f} |")

    lines.extend(
        [
            "",
            "## Interpretation guardrails",
            "",
            "- Hyperparameters were selected using forward-chaining folds within 2016–2018.",
            "- The final metrics use the untouched 2019–2020 test period.",
            "- Correlated terrain features can substitute for one another; use group ablation for the overall terrain conclusion.",
            "- Permutation importance describes model dependence, not causal effects.",
            "",
        ]
    )
    OUT_PATH.write_text("\n".join(lines))
    print(f"Saved {OUT_PATH}")


if __name__ == "__main__":
    main()
