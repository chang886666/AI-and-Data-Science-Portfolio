"""
Step 0: Verify all data is present and readable before doing anything else.

"""
import os
import glob
import numpy as np
import xarray as xr

DATA_DIR = 'data'
YEARS = list(range(2016, 2021))
MONTHS = list(range(1, 13))

n_pass, n_fail = 0, 0


def report(passed, msg):
    global n_pass, n_fail
    if passed:
        n_pass += 1
        print(f'  [PASS] {msg}')
    else:
        n_fail += 1
        print(f'  [FAIL] {msg}')


def main():
    global n_pass, n_fail
    n_pass, n_fail = 0, 0

    # 1. File existence: CERRA and ERA5, 2016-2020, 60 files each

    print('=' * 60)
    print('1. FILE EXISTENCE CHECK (2016-2020, 12 months/year)')
    print('=' * 60)

    cerra_files, era5_files = {}, {}
    missing_cerra, missing_era5 = [], []

    for y in YEARS:
        for m in MONTHS:
            c = f'{DATA_DIR}/cerra/cerra_{y}_{m:02d}.nc'
            e = f'{DATA_DIR}/era5/era5_{y}_{m:02d}.nc'
            if os.path.exists(c):
                cerra_files[(y, m)] = c
            else:
                missing_cerra.append((y, m))
            if os.path.exists(e):
                era5_files[(y, m)] = e
            else:
                missing_era5.append((y, m))

    report(len(missing_cerra) == 0,
           f'CERRA: {len(cerra_files)}/60 files present'
           + ('' if not missing_cerra else f', missing: {missing_cerra}'))
    report(len(missing_era5) == 0,
           f'ERA5: {len(era5_files)}/60 files present'
           + ('' if not missing_era5 else f', missing: {missing_era5}'))


    # 2. Per-file inspection: shape, time range, variables

    print()
    print('=' * 60)
    print('2. PER-FILE INSPECTION (shape / time range / variables)')
    print('=' * 60)

    unreadable = []
    cerra_var_ok, cerra_var_bad = 0, []
    era5_var_ok, era5_var_bad = 0, []

    for (y, m), path in sorted(cerra_files.items()):
        try:
            ds = xr.open_dataset(path)
        except Exception as ex:
            unreadable.append((path, str(ex)))
            continue
        has_si10 = 'si10' in ds.data_vars
        if has_si10:
            cerra_var_ok += 1
        else:
            cerra_var_bad.append((y, m, list(ds.data_vars)))
        tdim = 'valid_time' if 'valid_time' in ds.dims else ('time' if 'time' in ds.dims else None)
        if y == YEARS[0] and m == 1:
            print(f'  CERRA sample {y}-{m:02d}: dims={dict(ds.sizes)}, vars={list(ds.data_vars)}')
            if tdim is not None:
                tv = ds[tdim].values
                print(f'    time range: {tv[0]} -> {tv[-1]}  (n={len(tv)})')
        ds.close()

    for (y, m), path in sorted(era5_files.items()):
        try:
            ds = xr.open_dataset(path)
        except Exception as ex:
            unreadable.append((path, str(ex)))
            continue
        has_uv = {'u10', 'v10'}.issubset(ds.data_vars)
        if has_uv:
            era5_var_ok += 1
        else:
            era5_var_bad.append((y, m, list(ds.data_vars)))
        if y == YEARS[0] and m == 1:
            print(f'  ERA5 sample {y}-{m:02d}: dims={dict(ds.sizes)}, vars={list(ds.data_vars)}')
            tdim = 'valid_time' if 'valid_time' in ds.dims else ('time' if 'time' in ds.dims else None)
            if tdim is not None:
                tv = ds[tdim].values
                print(f'    time range: {tv[0]} -> {tv[-1]}  (n={len(tv)})')
        ds.close()

    report(len(unreadable) == 0,
           f'All present files opened without error'
           + ('' if not unreadable else f', {len(unreadable)} unreadable: {unreadable}'))
    report(len(cerra_var_bad) == 0,
           f"CERRA 'si10' variable present in {cerra_var_ok}/{len(cerra_files)} files"
           + ('' if not cerra_var_bad else f', missing in: {cerra_var_bad[:5]}'))
    report(len(era5_var_bad) == 0,
           f"ERA5 'u10'+'v10' variables present in {era5_var_ok}/{len(era5_files)} files"
           + ('' if not era5_var_bad else f', missing in: {era5_var_bad[:5]}'))


    # 3. CERRA coordinate system check (rotated pole / 0-360 longitude)

    print()
    print('=' * 60)
    print('3. CERRA COORDINATE SYSTEM CHECK')
    print('=' * 60)

    ref_cerra_path = cerra_files.get((YEARS[0], 1))
    if ref_cerra_path:
        ds = xr.open_dataset(ref_cerra_path)
        lat_name = 'latitude' if 'latitude' in ds.coords else None
        lon_name = 'longitude' if 'longitude' in ds.coords else None
        report(lat_name is not None and lon_name is not None,
               f'latitude/longitude coordinate fields found: lat={lat_name}, lon={lon_name}')
        if lat_name and lon_name:
            lats = ds[lat_name].values
            lons = ds[lon_name].values
            print(f'  latitude field ndim={lats.ndim}, shape={lats.shape}')
            print(f'  longitude field ndim={lons.ndim}, shape={lons.shape}')
            is_2d = lats.ndim == 2
            report(is_2d, 'lat/lon are 2D fields over (y, x) -> consistent with rotated-pole/curvilinear grid'
                   if is_2d else 'lat/lon are 1D -> NOT a rotated-pole grid as expected, check source')
            lon_over_180 = (lons > 180).any()
            report(lon_over_180,
                   f'longitude range [{lons.min():.2f}, {lons.max():.2f}] '
                   + ('contains values > 180 (0-360 convention confirmed)' if lon_over_180
                      else 'does NOT exceed 180 -- longitude may already be in -180/180 convention, verify before converting'))
            lons_180 = np.where(lons > 180, lons - 360, lons)
            uk_mask = (lats >= 49) & (lats <= 61) & (lons_180 >= -9) & (lons_180 <= 3)
            print(f'  UK bbox (49-61N, 9W-3E) grid points: {uk_mask.sum():,} / {uk_mask.size:,}')
        ds.close()
    else:
        report(False, 'No reference CERRA file (2016-01) available for coordinate check')


    # 4. DEM tiles

    print()
    print('=' * 60)
    print('4. GLO-30 DEM TILES')
    print('=' * 60)

    tif_files = sorted(glob.glob(f'{DATA_DIR}/dem/*.tif'))
    report(len(tif_files) > 0, f'{len(tif_files)} .tif file(s) found in data/dem/')
    for f in tif_files:
        print(f'  - {os.path.basename(f)}')


    # 5. Lightweight boundary and fixed point sample

    print()
    print('=' * 60)
    print('5. TERRAIN BOUNDARY AND FIXED SCOTLAND SAMPLE')
    print('=' * 60)

    uk_land_path = f'{DATA_DIR}/boundaries/uk_land.gpkg'
    report(
        os.path.exists(uk_land_path),
        'Lightweight dissolved ONS UK land boundary present '
        f'({uk_land_path})',
    )

    point_files = [
        f'{DATA_DIR}/processed/land_lats.npy',
        f'{DATA_DIR}/processed/land_lons.npy',
        f'{DATA_DIR}/processed/land_indices.npy',
    ]
    point_files_present = all(os.path.exists(path) for path in point_files)
    report(point_files_present, 'Fixed Scotland point arrays present')
    if point_files_present:
        fixed_lats = np.load(point_files[0], mmap_mode='r')
        fixed_lons = np.load(point_files[1], mmap_mode='r')
        fixed_indices = np.load(point_files[2], mmap_mode='r')
        fixed_shapes_ok = (
            fixed_lats.shape == fixed_lons.shape == fixed_indices.shape == (2022,)
        )
        report(fixed_shapes_ok, f'Fixed point array shapes: {fixed_lats.shape}')


    # Summary

    print()
    print('=' * 60)
    print(f'SUMMARY: {n_pass} PASS, {n_fail} FAIL')
    print(f'CERRA files: {len(cerra_files)}, ERA5 files: {len(era5_files)}, DEM tiles: {len(tif_files)}')
    print('=' * 60)

    if n_fail:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
