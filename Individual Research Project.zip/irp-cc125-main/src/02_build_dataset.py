"""Build paired ERA5/CERRA train and test datasets for Scotland."""

import os

import numpy as np
import pandas as pd
import xarray as xr
from scipy.interpolate import RegularGridInterpolator
from scipy.spatial import cKDTree

DATA_DIR = 'data'
TRAIN_YEARS = [2016, 2017, 2018]
TEST_YEARS = [2019, 2020]

FEATURE_NAMES = ['era5_wind', 'elevation', 'slope', 'hilliness',
                  'tpi_5km', 'tpi_75km', 'dist_coast', 'sin_month', 'cos_month']


def process_month(year, month):
    cerra_path = f'{DATA_DIR}/cerra/cerra_{year}_{month:02d}.nc'
    era5_path = f'{DATA_DIR}/era5/era5_{year}_{month:02d}.nc'
    if not (os.path.exists(cerra_path) and os.path.exists(era5_path)):
        return None

    ds_c = xr.open_dataset(cerra_path)
    ds_e = xr.open_dataset(era5_path)

    times_c = pd.DatetimeIndex(ds_c['valid_time'].values)
    idx_c = np.where((times_c.hour == 0) | (times_c.hour == 12))[0]
    times_e = pd.DatetimeIndex(ds_e['valid_time'].values)
    idx_e = np.where((times_e.hour == 0) | (times_e.hour == 12))[0]

    times_c_selected = times_c[idx_c]
    times_e_selected = times_e[idx_e]
    if not times_c_selected.equals(times_e_selected):
        ds_c.close()
        ds_e.close()
        raise ValueError(
            f'ERA5/CERRA timestamps do not match for {year}-{month:02d}'
        )

    # Load only the two selected timesteps into memory.
    si10 = ds_c['si10'].isel(valid_time=idx_c).values  # (n_t, y, x)
    times_sel = times_c_selected
    n_t = si10.shape[0]

    # map land CERRA points to y,x indices in the CERRA 2D grid
    cerra_lats_2d = ds_c['latitude'].values
    cerra_lons_2d = ds_c['longitude'].values
    cerra_lons_180 = np.where(cerra_lons_2d > 180, cerra_lons_2d - 360, cerra_lons_2d)
    tree = cKDTree(np.column_stack([cerra_lats_2d.ravel(), cerra_lons_180.ravel()]))
    _, flat_idx = tree.query(np.column_stack([land_lats, land_lons]))
    y_idx, x_idx = np.unravel_index(flat_idx, cerra_lats_2d.shape)

    cerra_wind = si10[:, y_idx, x_idx]  # (n_t, n_land)

    # ERA5 wind speed, bilinearly interpolated to the land CERRA points
    era5_lats = ds_e['latitude'].values
    era5_lons = ds_e['longitude'].values
    u10 = ds_e['u10'].isel(valid_time=idx_e).values
    v10 = ds_e['v10'].isel(valid_time=idx_e).values
    era5_wind_grid = np.sqrt(u10 ** 2 + v10 ** 2)  # (n_t, lat, lon)

    lat_order = np.argsort(era5_lats)
    era5_lats_sorted = era5_lats[lat_order]

    era5_wind_land = np.zeros((n_t, n_land))
    for t in range(n_t):
        interp = RegularGridInterpolator(
            (era5_lats_sorted, era5_lons),
            era5_wind_grid[t][lat_order],
            method='linear', bounds_error=False, fill_value=None,
        )
        era5_wind_land[t] = interp(np.column_stack([land_lats, land_lons]))

    sin_m = np.sin(2 * np.pi * month / 12)
    cos_m = np.cos(2 * np.pi * month / 12)

    terrain_rep = np.tile(land_terrain, (n_t, 1))
    X = np.column_stack([
        era5_wind_land.flatten(),
        terrain_rep,
        np.full(n_t * n_land, sin_m),
        np.full(n_t * n_land, cos_m),
    ])
    y = cerra_wind.flatten()
    bilinear = era5_wind_land.flatten()  # baseline == ERA5 bilinearly interpolated to CERRA grid

    # metadata: lat, lon, year, month, day, hour, is_complex, is_flat, is_coastal
    lat_rep = np.tile(land_lats, n_t)
    lon_rep = np.tile(land_lons, n_t)
    year_rep = np.full(n_t * n_land, year)
    month_rep = np.full(n_t * n_land, month)
    day_rep = np.repeat(times_sel.day.values, n_land)
    hour_rep = np.repeat(times_sel.hour.values, n_land)
    flags_rep = np.tile(terrain_flags, (n_t, 1))
    meta = np.column_stack([lat_rep, lon_rep, year_rep, month_rep, day_rep, hour_rep, flags_rep])

    valid = ~(np.isnan(X).any(axis=1) | np.isnan(y))
    if not valid.all():
        ds_c.close()
        ds_e.close()
        raise ValueError(
            f'Non-finite rows would break the fixed 2,022-point layout for '
            f'{year}-{month:02d}'
        )
    ds_c.close()
    ds_e.close()
    return X[valid], y[valid], bilinear[valid], meta[valid]

def collect(years, label):
    all_X, all_y, all_bl, all_meta = [], [], [], []
    for year in years:
        for month in range(1, 13):
            result = process_month(year, month)
            if result is None:
                print(f'  {label} {year}-{month:02d}: MISSING FILE, skipped')
                continue
            X, y, bl, meta = result
            all_X.append(X)
            all_y.append(y)
            all_bl.append(bl)
            all_meta.append(meta)
            print(f'  {label} {year}-{month:02d}: {len(y):,} samples')
    return np.vstack(all_X), np.concatenate(all_y), np.concatenate(all_bl), np.vstack(all_meta)

def main():
    global land_lats, land_lons, land_idx, land_terrain, terrain_flags, n_land

    os.makedirs(f'{DATA_DIR}/processed', exist_ok=True)


    # 1. Fixed Scottish points + terrain class flags

    print('Step 1: loading fixed Scottish points and computing terrain class flags...')


    land_lats = np.load(f'{DATA_DIR}/processed/land_lats.npy')
    land_lons = np.load(f'{DATA_DIR}/processed/land_lons.npy')
    land_idx = np.load(f'{DATA_DIR}/processed/land_indices.npy')
    land_terrain = np.load(f'{DATA_DIR}/processed/land_terrain_features.npy')

    if land_lats.ndim != 1 or land_lons.shape != land_lats.shape:
        raise ValueError('land_lats and land_lons must be matching 1-D arrays')
    if land_idx.shape != land_lats.shape:
        raise ValueError('land_indices and fixed point coordinates have different shapes')
    if land_terrain.shape != (len(land_lats), 6):
        raise ValueError(
            f'Expected land terrain shape ({len(land_lats)}, 6), '
            f'got {land_terrain.shape}'
        )
    if len(land_lats) != 2022:
        raise ValueError(f'Expected 2,022 fixed Scottish points, got {len(land_lats):,}')
    if not np.isfinite(land_terrain).all():
        raise ValueError('land_terrain_features.npy contains non-finite values')

    # columns: elevation, slope, hilliness, tpi_5km, tpi_75km, dist_coast
    land_hilliness = land_terrain[:, 2]
    land_dist_coast = land_terrain[:, 5]

    p25 = np.percentile(land_hilliness, 25)
    p75 = np.percentile(land_hilliness, 75)

    is_complex = land_hilliness > p75
    is_flat = land_hilliness < p25
    is_coastal = land_dist_coast < 20

    terrain_flags = np.column_stack([is_complex, is_flat, is_coastal]).astype(bool)

    n_land = len(land_idx)
    print(f'  fixed Scottish land points: {n_land:,}')
    print(f'  land hilliness: p25={p25:.1f}, p75={p75:.1f}')
    print(f'  complex={is_complex.sum():,}  flat={is_flat.sum():,}  coastal={is_coastal.sum():,}')

    np.save(f'{DATA_DIR}/processed/land_indices.npy', land_idx)
    np.save(f'{DATA_DIR}/processed/land_lats.npy', land_lats)
    np.save(f'{DATA_DIR}/processed/land_lons.npy', land_lons)
    np.save(f'{DATA_DIR}/processed/land_terrain_features.npy', land_terrain)
    np.save(f'{DATA_DIR}/processed/land_terrain_flags.npy', terrain_flags)
    print('  saved land_indices/land_lats/land_lons/land_terrain_features/land_terrain_flags.npy')

    print('\nStep 2: building training set (2016-2018)...')
    X_train, y_train, bl_train, meta_train = collect(TRAIN_YEARS, 'train')
    print(f'  X_train: {X_train.shape}')

    print('\nStep 3: building test set (2019-2020)...')
    X_test, y_test, bl_test, meta_test = collect(TEST_YEARS, 'test')
    print(f'  X_test: {X_test.shape}')

    np.save(f'{DATA_DIR}/processed/X_train.npy', X_train)
    np.save(f'{DATA_DIR}/processed/y_train.npy', y_train)
    np.save(f'{DATA_DIR}/processed/X_test.npy', X_test)
    np.save(f'{DATA_DIR}/processed/y_test.npy', y_test)
    np.save(f'{DATA_DIR}/processed/bilinear_test.npy', bl_test)
    np.save(f'{DATA_DIR}/processed/test_metadata.npy', meta_test)
    np.save(f'{DATA_DIR}/processed/train_metadata.npy', meta_train)
    print('\nSaved X_train, y_train, X_test, y_test, bilinear_test, test_metadata, train_metadata')


    # Summary

    print('\n=== Dataset summary ===')
    print(f'Features (9): {FEATURE_NAMES}')
    print(f'X_train: {X_train.shape}, y_train: {y_train.shape}')
    print(f'X_test:  {X_test.shape}, y_test:  {y_test.shape}')
    print('test_metadata columns: [lat, lon, year, month, day, hour, is_complex, is_flat, is_coastal]')
    print(f'Test terrain class counts (row-level, overlapping): '
          f'complex={meta_test[:, 6].sum():.0f}  flat={meta_test[:, 7].sum():.0f}  coastal={meta_test[:, 8].sum():.0f}')


if __name__ == "__main__":
    main()
