#!/usr/bin/env python3
"""Run the versioned projected-terrain Scotland experiment in order."""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
STEPS = [
    "00_check_data.py",
    "01_process_terrain_scotland.py",
    "02_build_dataset.py",
    "03a_validate_experiment.py",
    "03b_tune_models.py",
    "03c_train_final_models.py",
    "03d_train_linear_baselines.py",
    "04_evaluate_versioned.py",
    "05a_block_permutation_importance.py",
    "05b_versioned_ablation.py",
    "05c_spatial_holdout_versioned.py",
    "06_summarize_versioned_experiment.py",
    "07_visualize_versioned_results.py",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Show or run the complete projected_ons_bgc_v1 experiment. "
            "Execution is opt-in because model tuning and ablation are expensive."
        )
    )
    parser.add_argument(
        "--run",
        action="store_true",
        help="Actually execute the listed steps; without this flag only show them.",
    )
    parser.add_argument(
        "--start-at",
        choices=STEPS,
        default=STEPS[0],
        help="Start at this stage (inclusive).",
    )
    parser.add_argument(
        "--stop-after",
        choices=STEPS,
        default=STEPS[-1],
        help="Stop after this stage (inclusive).",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    start = STEPS.index(args.start_at)
    stop = STEPS.index(args.stop_after)
    if start > stop:
        raise ValueError("--start-at must not come after --stop-after")
    selected = STEPS[start : stop + 1]

    print("Experiment: projected_ons_bgc_v1")
    print("Python:", sys.executable)
    print("Stages:")
    for number, script in enumerate(selected, start=1):
        print(f"  {number:2d}. src/{script}")
    if not args.run:
        print("\nDry run only. Add --run to execute these stages.")
        return

    for number, script in enumerate(selected, start=1):
        print(f"\n=== Stage {number}/{len(selected)}: {script} ===", flush=True)
        subprocess.run(
            [sys.executable, str(ROOT / "src" / script)],
            cwd=ROOT,
            check=True,
        )


if __name__ == "__main__":
    main()
