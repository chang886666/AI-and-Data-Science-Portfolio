#!/usr/bin/env python3
"""Generate final figures/tables using only versioned experiment artefacts."""

from __future__ import annotations

import csv
import json
import os
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/irp_cc125_matplotlib")

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from experiment_config import ARRAY_PATHS, EXPERIMENT_DIR, EXPERIMENT_ID


FIGURE_DIR = EXPERIMENT_DIR / "figures"
TABLE_DIR = EXPERIMENT_DIR / "tables"
MODEL_NAMES = [
    "Bilinear",
    "LinearERA5Seasonal",
    "QuantileMapping",
    "LinearFullFeatures",
    "RandomForest",
    "XGBoost",
]
COLORS = {
    "Bilinear": "#7f7f7f",
    "LinearERA5Seasonal": "#b279a2",
    "QuantileMapping": "#4c78a8",
    "LinearFullFeatures": "#eeca3b",
    "RandomForest": "#f58518",
    "XGBoost": "#54a24b",
}


def load_json(name: str) -> dict:
    path = EXPERIMENT_DIR / name
    if not path.is_file():
        raise FileNotFoundError(f"Missing versioned result: {path}")
    with path.open() as handle:
        result = json.load(handle)
    if result.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError(f"Wrong experiment ID in {path}")
    return result


def save_figure(fig: plt.Figure, stem: str) -> None:
    fig.savefig(FIGURE_DIR / f"{stem}.png", dpi=300, bbox_inches="tight")
    fig.savefig(FIGURE_DIR / f"{stem}.pdf", bbox_inches="tight")
    plt.close(fig)


def metric_row(y: np.ndarray, prediction: np.ndarray) -> dict[str, float]:
    residual = prediction.astype(np.float64) - y.astype(np.float64)
    return {
        "n": int(len(y)),
        "rmse": float(np.sqrt(np.mean(residual**2))),
        "mae": float(np.mean(np.abs(residual))),
        "bias": float(np.mean(residual)),
    }


def write_rows(path: Path, rows: list[dict]) -> None:
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def grouped_metric_plot(
    evaluation: dict, subsets: list[str], labels: list[str], stem: str, title: str
) -> None:
    x = np.arange(len(subsets))
    width = 0.8 / len(MODEL_NAMES)
    fig, ax = plt.subplots(figsize=(10, 5.5))
    for index, model in enumerate(MODEL_NAMES):
        values = [evaluation["subsets"][subset][model]["rmse"] for subset in subsets]
        ax.bar(
            x + (index - (len(MODEL_NAMES) - 1) / 2) * width,
            values,
            width,
            label=model,
            color=COLORS[model],
        )
    ax.set_xticks(x, labels)
    ax.set_ylabel("RMSE (m s$^{-1}$)")
    ax.set_title(title)
    ax.legend(frameon=False, ncol=2)
    ax.grid(axis="y", alpha=0.25)
    save_figure(fig, stem)


def main() -> None:
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    TABLE_DIR.mkdir(parents=True, exist_ok=True)
    evaluation = load_json("evaluation_results.json")
    permutation = load_json("block_permutation_importance.json")
    ablation = load_json("ablation_results.json")

    y = np.load(ARRAY_PATHS["y_test"], mmap_mode="r")
    metadata = np.load(ARRAY_PATHS["test_metadata"], mmap_mode="r")
    lats = np.load("data/processed/land_lats.npy", mmap_mode="r")
    lons = np.load("data/processed/land_lons.npy", mmap_mode="r")
    n_points = len(lats)
    if len(y) != len(metadata) or len(y) % n_points:
        raise ValueError("Test rows are not complete, point-aligned time blocks.")
    if n_points != 2022:
        raise ValueError(f"Expected 2,022 fixed points, found {n_points:,}.")

    predictions = {
        model: np.load(
            EXPERIMENT_DIR / f"prediction_{model.lower()}.npy", mmap_mode="r"
        )
        for model in MODEL_NAMES
    }
    for model, prediction in predictions.items():
        if prediction.shape != y.shape or not np.isfinite(prediction).all():
            raise ValueError(f"Invalid versioned prediction for {model}")

    # 1-2. Year and terrain subset comparisons.
    grouped_metric_plot(
        evaluation,
        ["Year_2019", "Year_2020"],
        ["2019", "2020"],
        "01_rmse_by_year",
        "Held-out performance by year",
    )
    grouped_metric_plot(
        evaluation,
        ["Complex", "Flat", "Coastal"],
        ["Complex terrain", "Flat terrain", "Coastal"],
        "02_rmse_by_terrain",
        "Held-out performance by terrain subset",
    )

    # 3. Refit ablation, including the all-terrain group.
    variants = list(ablation["variants"])
    labels = [name.removeprefix("drop_").replace("_", " ") for name in variants]
    y_pos = np.arange(len(variants))
    fig, ax = plt.subplots(figsize=(10, 7))
    width = 0.36
    for offset, model in [(-width / 2, "RandomForest"), (width / 2, "XGBoost")]:
        values = [
            ablation["variants"][name]["models"][model]["overall_rmse_delta"]
            for name in variants
        ]
        ax.barh(y_pos + offset, values, height=width, label=model)
    ax.axvline(0, color="black", linewidth=0.8)
    ax.set_yticks(y_pos, labels)
    ax.invert_yaxis()
    ax.set_xlabel("Change in held-out RMSE after removal (m s$^{-1}$)")
    ax.set_title("Refit feature ablation")
    ax.legend(frameon=False)
    ax.grid(axis="x", alpha=0.25)
    save_figure(fig, "03_refit_ablation")

    # 4. Structure-preserving permutation importance.
    features = list(permutation["models"]["RandomForest"]["features"])
    x = np.arange(len(features))
    fig, ax = plt.subplots(figsize=(11, 5.5))
    for offset, model in [(-0.19, "RandomForest"), (0.19, "XGBoost")]:
        means = [
            permutation["models"][model]["features"][feature]["rmse_increase_mean"]
            for feature in features
        ]
        stds = [
            permutation["models"][model]["features"][feature]["rmse_increase_std"]
            for feature in features
        ]
        ax.bar(x + offset, means, 0.38, yerr=stds, capsize=2, label=model)
    ax.set_xticks(x, features, rotation=35, ha="right")
    ax.set_ylabel("RMSE increase (m s$^{-1}$)")
    ax.set_title("Structure-preserving block permutation importance")
    ax.legend(frameon=False)
    ax.grid(axis="y", alpha=0.25)
    save_figure(fig, "04_block_permutation_importance")

    # 5. Observation-prediction density plots (deterministic complete-row sample).
    rng = np.random.default_rng(42)
    sample = np.sort(rng.choice(len(y), size=min(250_000, len(y)), replace=False))
    lo = float(min(np.min(y[sample]), *(np.min(p[sample]) for p in predictions.values())))
    hi = float(max(np.max(y[sample]), *(np.max(p[sample]) for p in predictions.values())))
    fig, axes = plt.subplots(2, 3, figsize=(15, 10), sharex=True, sharey=True)
    for ax, (model, prediction) in zip(axes.flat, predictions.items()):
        image = ax.hexbin(y[sample], prediction[sample], gridsize=100, bins="log", mincnt=1)
        ax.plot([lo, hi], [lo, hi], "r--", linewidth=1)
        ax.set_title(f"{model} (RMSE={evaluation['subsets']['Overall'][model]['rmse']:.3f})")
        ax.set_xlabel("Observed CERRA wind speed (m s$^{-1}$)")
        ax.set_ylabel("Predicted wind speed (m s$^{-1}$)")
        ax.set_xlim(lo, hi)
        ax.set_ylim(lo, hi)
    fig.colorbar(image, ax=axes, label="log10 count", shrink=0.82)
    fig.suptitle("Observed versus predicted wind speed (fixed random sample)")
    save_figure(fig, "05_observed_vs_predicted")

    # 6. Residual distributions.
    fig, ax = plt.subplots(figsize=(10, 5.5))
    residual_limit = 5.0
    bins = np.linspace(-residual_limit, residual_limit, 151)
    for model, prediction in predictions.items():
        residual = prediction[sample] - y[sample]
        ax.hist(
            residual,
            bins=bins,
            density=True,
            histtype="step",
            linewidth=1.5,
            label=model,
            color=COLORS[model],
        )
    ax.axvline(0, color="black", linewidth=0.8)
    ax.set_xlabel("Residual: prediction − observation (m s$^{-1}$)")
    ax.set_ylabel("Density")
    ax.set_title("Held-out residual distributions (fixed random sample)")
    ax.legend(frameon=False)
    ax.grid(alpha=0.2)
    save_figure(fig, "06_residual_distributions")

    # 7. Per-point spatial errors. Row order is complete timestamp × point.
    n_times = len(y) // n_points
    y_grid = np.asarray(y).reshape(n_times, n_points)
    spatial_rows = []
    spatial_metrics = {}
    for model, prediction in predictions.items():
        residual = np.asarray(prediction).reshape(n_times, n_points) - y_grid
        spatial_metrics[model] = {
            "rmse": np.sqrt(np.mean(residual.astype(np.float64) ** 2, axis=0)),
            "bias": np.mean(residual.astype(np.float64), axis=0),
        }
    for point in range(n_points):
        row = {"point": point, "latitude": float(lats[point]), "longitude": float(lons[point])}
        for model in MODEL_NAMES:
            row[f"{model}_rmse"] = float(spatial_metrics[model]["rmse"][point])
            row[f"{model}_bias"] = float(spatial_metrics[model]["bias"][point])
        spatial_rows.append(row)
    write_rows(TABLE_DIR / "spatial_point_metrics.csv", spatial_rows)

    xgb_rmse = spatial_metrics["XGBoost"]["rmse"]
    xgb_bias = spatial_metrics["XGBoost"]["bias"]
    improvement = spatial_metrics["Bilinear"]["rmse"] - xgb_rmse
    fig, axes = plt.subplots(1, 3, figsize=(16, 6), constrained_layout=True)
    panels = [
        (xgb_rmse, "viridis", "XGBoost RMSE", None),
        (xgb_bias, "RdBu_r", "XGBoost bias", float(np.max(np.abs(xgb_bias)))),
        (improvement, "RdBu", "RMSE improvement vs bilinear", float(np.max(np.abs(improvement)))),
    ]
    for ax, (values, cmap, title, symmetric) in zip(axes, panels):
        kwargs = {"vmin": -symmetric, "vmax": symmetric} if symmetric else {}
        scatter = ax.scatter(lons, lats, c=values, s=11, cmap=cmap, linewidths=0, **kwargs)
        ax.set_title(title)
        ax.set_xlabel("Longitude")
        ax.set_ylabel("Latitude")
        ax.set_aspect("equal", adjustable="box")
        fig.colorbar(scatter, ax=ax, shrink=0.78, label="m s$^{-1}$")
    save_figure(fig, "07_spatial_error_maps")

    # 8. Absolute wind-speed bins and test-derived high-wind percentiles.
    edges = np.array([0, 2, 4, 6, 8, 10, 12, np.inf], dtype=float)
    bin_rows = []
    bin_labels = []
    for left, right in zip(edges[:-1], edges[1:]):
        mask = (y >= left) & (y < right)
        label = f"{left:g}–{right:g}" if np.isfinite(right) else f"≥{left:g}"
        bin_labels.append(label)
        for model, prediction in predictions.items():
            bin_rows.append({"group": label, "model": model, **metric_row(y[mask], prediction[mask])})
    thresholds = np.percentile(y, [90, 95, 99])
    high_rows = []
    for percentile, threshold in zip([90, 95, 99], thresholds):
        mask = y >= threshold
        for model, prediction in predictions.items():
            high_rows.append(
                {
                    "threshold": f"P{percentile}",
                    "observed_cutoff_m_s": float(threshold),
                    "model": model,
                    **metric_row(y[mask], prediction[mask]),
                }
            )
    write_rows(TABLE_DIR / "wind_speed_bin_metrics.csv", bin_rows)
    write_rows(TABLE_DIR / "high_wind_metrics.csv", high_rows)

    fig, ax = plt.subplots(figsize=(11, 5.5))
    x = np.arange(len(bin_labels))
    width = 0.8 / len(MODEL_NAMES)
    for index, model in enumerate(MODEL_NAMES):
        rows = [row for row in bin_rows if row["model"] == model]
        ax.bar(
            x + (index - (len(MODEL_NAMES) - 1) / 2) * width,
            [row["rmse"] for row in rows],
            width,
            label=model,
            color=COLORS[model],
        )
    ax.set_xticks(x, bin_labels)
    ax.set_xlabel("Observed CERRA wind-speed bin (m s$^{-1}$)")
    ax.set_ylabel("RMSE (m s$^{-1}$)")
    ax.set_title("Error by observed wind-speed range")
    ax.legend(frameon=False, ncol=2)
    ax.grid(axis="y", alpha=0.25)
    save_figure(fig, "08_error_by_wind_speed")

    provenance = {
        "experiment_id": EXPERIMENT_ID,
        "source_directory": str(EXPERIMENT_DIR),
        "figures": sorted(path.name for path in FIGURE_DIR.glob("*.png")),
        "tables": sorted(path.name for path in TABLE_DIR.glob("*.csv")),
        "scatter_and_residual_sample_seed": 42,
        "scatter_and_residual_sample_size": int(len(sample)),
        "high_wind_percentiles": {
            f"P{p}": float(value) for p, value in zip([90, 95, 99], thresholds)
        },
    }
    with (EXPERIMENT_DIR / "analysis_provenance.json").open("w") as handle:
        json.dump(provenance, handle, indent=2)
    print(f"Saved final figures to {FIGURE_DIR}")
    print(f"Saved final tables to {TABLE_DIR}")


if __name__ == "__main__":
    main()
