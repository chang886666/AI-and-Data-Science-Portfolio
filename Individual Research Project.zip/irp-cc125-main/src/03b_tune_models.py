#!/usr/bin/env python3
"""Tune RF and XGBoost with forward-chaining temporal validation."""

from __future__ import annotations

import itertools
import json
import os
import tempfile
import time
from pathlib import Path

if "JOBLIB_TEMP_FOLDER" not in os.environ:
    shared_memory = "/dev/shm"
    os.environ["JOBLIB_TEMP_FOLDER"] = (
        shared_memory
        if os.path.isdir(shared_memory) and os.access(shared_memory, os.W_OK)
        else tempfile.gettempdir()
    )

import numpy as np
import xgboost as xgb
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error

from experiment_config import (
    ARRAY_PATHS,
    EXPERIMENT_DIR,
    EXPERIMENT_ID,
    FORWARD_FOLDS,
)


MANIFEST_PATH = EXPERIMENT_DIR / "experiment_manifest.json"
OUT_PATH = EXPERIMENT_DIR / "tuning_results.json"

XGB_GRID = [
    {"max_depth": depth, "learning_rate": rate}
    for depth, rate in itertools.product([4, 6, 8, 10], [0.03, 0.05, 0.1])
]
RF_GRID = [
    {"n_estimators": trees, "max_depth": depth}
    for trees, depth in itertools.product([200, 400], [15, 25, None])
]

XGB_FIXED = {
    "n_estimators": 300,
    "subsample": 0.8,
    "objective": "reg:squarederror",
    "eval_metric": "rmse",
    "tree_method": "hist",
    "random_state": 42,
    "n_jobs": 8,
}
RF_FIXED = {
    "max_features": "sqrt",
    "max_samples": 0.1,
    "min_samples_leaf": 30,
    "random_state": 42,
    "n_jobs": 8,
}


def file_sha256(path: Path) -> str:
    import hashlib

    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, float]:
    error = y_pred - y_true
    return {
        "rmse": float(np.sqrt(mean_squared_error(y_true, y_pred))),
        "mae": float(mean_absolute_error(y_true, y_pred)),
        "bias": float(np.mean(error)),
    }


def combo_key(params: dict) -> str:
    return json.dumps(params, sort_keys=True)


def save_results(results: dict) -> None:
    temporary = OUT_PATH.with_suffix(".json.tmp")
    with temporary.open("w") as handle:
        json.dump(results, handle, indent=2)
    temporary.replace(OUT_PATH)


def run_grid(
    model_name: str,
    grid: list[dict],
    fixed_params: dict,
    model_class,
    results: dict,
    x_train: np.ndarray,
    y_train: np.ndarray,
    years: np.ndarray,
) -> None:
    for combination_number, params in enumerate(grid, start=1):
        key = combo_key(params)
        if key in results["models"][model_name]:
            print(f"Skipping completed {model_name} {params}")
            continue

        print(
            f"\n=== {model_name} {combination_number}/{len(grid)}: {params} ==="
        )
        fold_results = []
        start = time.time()
        for fold in FORWARD_FOLDS:
            train_mask = np.isin(years, fold["train"])
            validation_mask = np.isin(years, fold["val"])
            x_fold_train = np.asarray(x_train[train_mask], dtype=np.float32)
            y_fold_train = np.asarray(y_train[train_mask], dtype=np.float32)
            x_fold_validation = np.asarray(
                x_train[validation_mask], dtype=np.float32
            )
            y_fold_validation = np.asarray(
                y_train[validation_mask], dtype=np.float32
            )

            model = model_class(**fixed_params, **params)
            fold_start = time.time()
            model.fit(x_fold_train, y_fold_train)
            prediction = model.predict(x_fold_validation)
            result = {
                "fold": fold["name"],
                "train_years": fold["train"],
                "validation_years": fold["val"],
                "n_train": int(len(y_fold_train)),
                "n_validation": int(len(y_fold_validation)),
                "elapsed_seconds": time.time() - fold_start,
                **metrics(y_fold_validation, prediction),
            }
            fold_results.append(result)
            print(
                f"  {fold['name']}: RMSE={result['rmse']:.4f}, "
                f"MAE={result['mae']:.4f}, bias={result['bias']:+.4f}"
            )
            del (
                model,
                prediction,
                x_fold_train,
                y_fold_train,
                x_fold_validation,
                y_fold_validation,
            )

        entry = {
            "params": {**fixed_params, **params},
            "folds": fold_results,
            "mean_rmse": float(np.mean([item["rmse"] for item in fold_results])),
            "std_rmse": float(np.std([item["rmse"] for item in fold_results])),
            "mean_mae": float(np.mean([item["mae"] for item in fold_results])),
            "mean_bias": float(np.mean([item["bias"] for item in fold_results])),
            "elapsed_seconds": time.time() - start,
        }
        results["models"][model_name][key] = entry
        save_results(results)
        print(
            f"  mean forward RMSE={entry['mean_rmse']:.4f}; "
            f"saved {OUT_PATH}"
        )


def main() -> None:
    if not MANIFEST_PATH.is_file():
        raise FileNotFoundError(
            f"Run 03a_validate_experiment.py first: {MANIFEST_PATH}"
        )
    manifest_hash = file_sha256(MANIFEST_PATH)
    results = {
        "experiment_id": EXPERIMENT_ID,
        "manifest_sha256": manifest_hash,
        "selection_metric": "lowest mean forward-chaining RMSE",
        "models": {"XGBoost": {}, "RandomForest": {}},
    }
    if OUT_PATH.exists():
        with OUT_PATH.open() as handle:
            results = json.load(handle)
        if results.get("experiment_id") != EXPERIMENT_ID:
            raise ValueError("Tuning cache belongs to a different experiment.")
        if results.get("manifest_sha256") != manifest_hash:
            raise ValueError(
                "Experiment manifest changed; use a new experiment ID rather "
                "than resuming stale tuning results."
            )

    x_train = np.load(ARRAY_PATHS["X_train"], mmap_mode="r")
    y_train = np.load(ARRAY_PATHS["y_train"], mmap_mode="r")
    metadata = np.load(ARRAY_PATHS["train_metadata"], mmap_mode="r")
    years = metadata[:, 2].astype(int)

    print(f"Experiment: {EXPERIMENT_ID}")
    print(f"Forward folds: {FORWARD_FOLDS}")
    run_grid(
        "XGBoost", XGB_GRID, XGB_FIXED, xgb.XGBRegressor,
        results, x_train, y_train, years,
    )
    run_grid(
        "RandomForest", RF_GRID, RF_FIXED, RandomForestRegressor,
        results, x_train, y_train, years,
    )

    print("\n=== Tuning complete ===")
    for model_name, model_results in results["models"].items():
        best_key = min(
            model_results,
            key=lambda key: model_results[key]["mean_rmse"],
        )
        best = model_results[best_key]
        print(
            f"{model_name}: {best['params']} -> "
            f"mean forward RMSE={best['mean_rmse']:.4f}"
        )


if __name__ == "__main__":
    main()
