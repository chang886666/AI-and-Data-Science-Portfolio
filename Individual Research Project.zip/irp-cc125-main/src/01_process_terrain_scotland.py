#!/usr/bin/env python3
"""
Step 1: Derive static terrain features for the 2,022 Scottish CERRA points.
"""

from __future__ import annotations

import argparse
import glob
import json
import math
from contextlib import ExitStack
from pathlib import Path

import geopandas as gpd
import matplotlib
import numpy as np
import rasterio
import xarray as xr
from pyproj import CRS
from rasterio.enums import Resampling
from rasterio.features import geometry_mask
from rasterio.merge import merge
from rasterio.transform import rowcol
from rasterio.vrt import WarpedVRT
from scipy.interpolate import RegularGridInterpolator
from scipy.ndimage import distance_transform_edt
from shapely.geometry import LineString, MultiPolygon, Polygon, mapping
from shapely.ops import unary_union

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402


FEATURE_NAMES = [
    "elevation",
    "slope",
    "hilliness",
    "tpi_5km",
    "tpi_75km",
    "dist_coast",
]

FEATURE_UNITS = {
    "elevation": "m",
    "hilliness": "m",
    "slope": "degree",
    "tpi_5km": "m",
    "tpi_75km": "m",
    "dist_coast": "km",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Create terrain features for the fixed Scottish CERRA points."
    )
    parser.add_argument("--dem-glob", default="data/dem/*.tif")
    parser.add_argument("--cerra-grid", default="data/cerra/cerra_2016_01.nc")
    parser.add_argument(
        "--land-vector", default="data/boundaries/uk_land.gpkg"
    )
    parser.add_argument(
        "--coastline-vector",
        default=None,
        help=(
            "Optional coastline line/polygon file. If omitted, exterior land "
            "polygon boundaries are used."
        ),
    )
    parser.add_argument("--processed-dir", default="data/processed")
    parser.add_argument("--results-dir", default="data/results")
    parser.add_argument("--point-lats", default="data/processed/land_lats.npy")
    parser.add_argument("--point-lons", default="data/processed/land_lons.npy")
    parser.add_argument("--point-indices", default="data/processed/land_indices.npy")
    parser.add_argument("--target-crs", default="EPSG:27700")
    parser.add_argument("--resolution-m", type=float, default=300.0)
    parser.add_argument(
        "--hilliness-radius-km",
        type=float,
        default=5.0,
        help="Default 5 km radius, equivalent to a 10 km-diameter neighbourhood.",
    )
    parser.add_argument("--tpi-small-radius-km", type=float, default=5.0)
    parser.add_argument("--tpi-large-radius-km", type=float, default=75.0)
    parser.add_argument(
        "--expected-points",
        type=int,
        default=2022,
        help="Set to 0 to disable the final point-count check.",
    )
    return parser.parse_args()


def require_file(path: str | Path, label: str) -> Path:
    resolved = Path(path)
    if not resolved.is_file():
        raise FileNotFoundError(f"{label} not found: {resolved}")
    return resolved


def union_geometries(geometries: gpd.GeoSeries):
    clean = geometries[~geometries.is_empty & geometries.notna()]
    if clean.empty:
        raise ValueError("Vector file contains no usable geometries.")
    if hasattr(clean, "union_all"):
        return clean.union_all()
    return clean.unary_union


def polygon_exteriors(geometry):
    """Return exterior polygon rings only, excluding lake/interior-hole rings."""
    if isinstance(geometry, Polygon):
        return LineString(geometry.exterior.coords)
    if isinstance(geometry, MultiPolygon):
        return unary_union([LineString(poly.exterior.coords) for poly in geometry.geoms])
    raise TypeError(
        "Land vector must dissolve to Polygon or MultiPolygon when no separate "
        "coastline vector is supplied."
    )


def read_vector_union(path: str | Path, target_crs: CRS, label: str):
    path = require_file(path, label)
    gdf = gpd.read_file(path)
    if gdf.crs is None:
        raise ValueError(f"{label} has no declared CRS: {path}")
    gdf = gdf.to_crs(target_crs)
    geometry = union_geometries(gdf.geometry)
    if geometry.is_empty:
        raise ValueError(f"{label} is empty after reprojection: {path}")
    return geometry


def inspect_dem_sources(paths: list[Path]) -> None:
    print("Checking DEM source metadata and validity masks...")
    for path in paths:
        with rasterio.open(path) as src:
            if src.crs is None:
                raise ValueError(f"DEM tile has no CRS: {path}")
            mask = src.read_masks(1)
            invalid = int(np.count_nonzero(mask == 0))
            print(
                f"  {path.name}: crs={src.crs}, shape={src.height}x{src.width}, "
                f"nodata={src.nodata}, invalid_mask_pixels={invalid:,}"
            )


def build_projected_dem(
    paths: list[Path], target_crs: CRS, resolution_m: float
) -> tuple[np.ndarray, rasterio.Affine]:
    """Warp all DEM tiles to one metric CRS and merge at a common resolution."""
    print(
        f"Reprojecting and merging {len(paths)} DEM tiles to "
        f"{target_crs.to_string()} at {resolution_m:g} m..."
    )

    with ExitStack() as stack:
        sources = [stack.enter_context(rasterio.open(path)) for path in paths]
        vrts = []
        for src in sources:
            vrt = stack.enter_context(
                WarpedVRT(
                    src,
                    crs=target_crs,
                    resampling=Resampling.average,
                    src_nodata=src.nodata,
                    nodata=np.nan,
                )
            )
            vrts.append(vrt)

        mosaic, transform = merge(
            vrts,
            res=(resolution_m, resolution_m),
            nodata=np.nan,
            dtype="float32",
            resampling=Resampling.average,
            method="first",
            target_aligned_pixels=True,
        )

    dem = mosaic[0].astype(np.float32, copy=False)
    if not np.isfinite(dem).any():
        raise ValueError("Projected DEM contains no finite pixels.")

    x_res = abs(float(transform.a))
    y_res = abs(float(transform.e))
    if not (np.isclose(x_res, resolution_m) and np.isclose(y_res, resolution_m)):
        raise ValueError(
            f"Unexpected output resolution: x={x_res}, y={y_res}, "
            f"expected={resolution_m} m"
        )

    print(
        f"  projected DEM shape={dem.shape}, resolution={x_res:g} x {y_res:g} m, "
        f"finite={np.isfinite(dem).sum():,}/{dem.size:,}"
    )
    return dem, transform


def save_projected_dem(
    path: Path,
    dem: np.ndarray,
    transform: rasterio.Affine,
    target_crs: CRS,
) -> None:
    profile = {
        "driver": "GTiff",
        "height": dem.shape[0],
        "width": dem.shape[1],
        "count": 1,
        "dtype": "float32",
        "crs": target_crs,
        "transform": transform,
        "nodata": np.nan,
        "compress": "deflate",
        "predictor": 3,
        "tiled": True,
        "BIGTIFF": "IF_SAFER",
    }
    with rasterio.open(path, "w", **profile) as dst:
        dst.write(dem.astype(np.float32), 1)


def make_land_mask(
    land_geometry,
    shape: tuple[int, int],
    transform: rasterio.Affine,
) -> np.ndarray:
    return geometry_mask(
        [mapping(land_geometry)],
        out_shape=shape,
        transform=transform,
        invert=True,
        all_touched=False,
    )


def nearest_valid_fill(array: np.ndarray, valid: np.ndarray) -> np.ndarray:
    """Fill invalid cells from the nearest valid cell for numerical derivatives."""
    if not valid.any():
        raise ValueError("Cannot fill an array with no valid cells.")
    indices = distance_transform_edt(
        ~valid,
        return_distances=False,
        return_indices=True,
    )
    return array[tuple(indices)]


def compute_slope(
    dem_land: np.ndarray,
    valid_land: np.ndarray,
    resolution_m: float,
) -> np.ndarray:
    """
    Compute slope in degrees on the metric grid.

    Invalid cells are nearest-filled only to make the numerical gradient stable
    at the land boundary. Results outside valid land are immediately masked.
    """
    filled = nearest_valid_fill(dem_land, valid_land)
    dz_dy, dz_dx = np.gradient(filled, resolution_m, resolution_m)
    slope = np.degrees(np.arctan(np.hypot(dz_dx, dz_dy))).astype(np.float32)
    slope[~valid_land] = np.nan
    return slope


def pixel_centres(
    transform: rasterio.Affine, height: int, width: int
) -> tuple[np.ndarray, np.ndarray]:
    x = transform.c + transform.a * (np.arange(width) + 0.5)
    y = transform.f + transform.e * (np.arange(height) + 0.5)
    return x.astype(float), y.astype(float)


def interpolate_with_nearest_fallback(
    array: np.ndarray,
    valid: np.ndarray,
    x_coords: np.ndarray,
    y_coords: np.ndarray,
    point_x: np.ndarray,
    point_y: np.ndarray,
    label: str,
) -> np.ndarray:
    """Bilinear interpolation, with a reported nearest-valid fallback at coasts."""
    points = np.column_stack([point_y, point_x])
    linear = RegularGridInterpolator(
        (y_coords[::-1], x_coords),
        array[::-1],
        method="linear",
        bounds_error=False,
        fill_value=np.nan,
    )
    values = linear(points)
    missing = ~np.isfinite(values)

    if missing.any():
        filled = nearest_valid_fill(array, valid)
        nearest = RegularGridInterpolator(
            (y_coords[::-1], x_coords),
            filled[::-1],
            method="nearest",
            bounds_error=False,
            fill_value=np.nan,
        )
        values[missing] = nearest(points[missing])
        print(
            f"  {label}: nearest-valid fallback used for "
            f"{missing.sum():,}/{len(values):,} coastal/edge points"
        )

    return np.asarray(values, dtype=float)


def neighbourhood_values_at_point(
    dem: np.ndarray,
    valid: np.ndarray,
    x_coords: np.ndarray,
    y_coords: np.ndarray,
    row: int,
    col: int,
    point_x: float,
    point_y: float,
    radius_m: float,
    resolution_m: float,
) -> np.ndarray:
    """Return valid pixels whose centres are within radius of the exact point."""
    radius_px = int(math.ceil(radius_m / resolution_m)) + 1
    r0 = max(0, row - radius_px)
    r1 = min(dem.shape[0], row + radius_px + 1)
    c0 = max(0, col - radius_px)
    c1 = min(dem.shape[1], col + radius_px + 1)

    local_dem = dem[r0:r1, c0:c1]
    local_valid = valid[r0:r1, c0:c1]
    dx2 = (x_coords[c0:c1] - point_x) ** 2
    dy2 = (y_coords[r0:r1] - point_y) ** 2
    inside_radius = dy2[:, None] + dx2[None, :] <= radius_m**2
    keep = inside_radius & local_valid & np.isfinite(local_dem)
    return local_dem[keep]


def compute_neighbourhood_features(
    dem_land: np.ndarray,
    valid_land: np.ndarray,
    transform: rasterio.Affine,
    x_coords: np.ndarray,
    y_coords: np.ndarray,
    point_x: np.ndarray,
    point_y: np.ndarray,
    point_elevation: np.ndarray,
    resolution_m: float,
    hilliness_radius_m: float,
    tpi_small_radius_m: float,
    tpi_large_radius_m: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    print("Computing exact point-centred circular neighbourhood metrics...")

    rows, cols = rowcol(transform, point_x, point_y)
    rows = np.asarray(rows, dtype=int)
    cols = np.asarray(cols, dtype=int)

    n = len(point_x)
    hilliness = np.full(n, np.nan, dtype=float)
    tpi_small = np.full(n, np.nan, dtype=float)
    tpi_large = np.full(n, np.nan, dtype=float)

    for i, (row, col) in enumerate(zip(rows, cols)):
        if row < 0 or row >= dem_land.shape[0] or col < 0 or col >= dem_land.shape[1]:
            continue

        common = (
            dem_land,
            valid_land,
            x_coords,
            y_coords,
            row,
            col,
            float(point_x[i]),
            float(point_y[i]),
        )
        hill_values = neighbourhood_values_at_point(
            *common, hilliness_radius_m, resolution_m
        )
        small_values = neighbourhood_values_at_point(
            *common, tpi_small_radius_m, resolution_m
        )
        large_values = neighbourhood_values_at_point(
            *common, tpi_large_radius_m, resolution_m
        )

        if hill_values.size:
            hilliness[i] = float(np.max(hill_values) - np.min(hill_values))
        if small_values.size:
            tpi_small[i] = float(point_elevation[i] - np.mean(small_values))
        if large_values.size:
            tpi_large[i] = float(point_elevation[i] - np.mean(large_values))

        if (i + 1) % 250 == 0 or i + 1 == n:
            print(f"  neighbourhoods: {i + 1:,}/{n:,} points")

    return hilliness, tpi_small, tpi_large


def load_fixed_cerra_points(
    cerra_path: Path,
    latitude_path: Path,
    longitude_path: Path,
    index_path: Path,
    target_crs: CRS,
) -> dict[str, np.ndarray]:
    """Load the original sample and verify its membership/order on the CERRA grid."""
    print("Loading and verifying the fixed Scottish CERRA point sample...")
    reference_lats = np.load(require_file(latitude_path, "Fixed point latitudes"))
    reference_lons = np.load(require_file(longitude_path, "Fixed point longitudes"))
    reference_indices = np.load(require_file(index_path, "Fixed point indices"))

    if reference_lats.ndim != 1 or reference_lons.shape != reference_lats.shape:
        raise ValueError(
            "Fixed latitude/longitude arrays must be matching one-dimensional arrays."
        )
    if reference_indices.shape != reference_lats.shape:
        raise ValueError("Fixed point indices and coordinates have different shapes.")
    if not (
        np.isfinite(reference_lats).all() and np.isfinite(reference_lons).all()
    ):
        raise ValueError("Fixed point coordinates contain non-finite values.")

    with xr.open_dataset(cerra_path) as ds:
        if "latitude" not in ds or "longitude" not in ds:
            raise KeyError("CERRA reference file must contain latitude and longitude.")
        lats = np.asarray(ds["latitude"].values)
        lons = np.asarray(ds["longitude"].values)

    if lats.shape != lons.shape or lats.ndim != 2:
        raise ValueError(
            f"Expected matching 2-D CERRA coordinates; got {lats.shape} and {lons.shape}."
        )

    lons_180 = np.where(lons > 180, lons - 360, lons)
    candidate = (
        np.isfinite(lats)
        & np.isfinite(lons_180)
        & (lats >= 49)
        & (lats <= 61)
        & (lons_180 >= -9)
        & (lons_180 <= 3)
    )
    candidate_rows, candidate_cols = np.where(candidate)
    candidate_lats = lats[candidate]
    candidate_lons = lons_180[candidate]

    reference_indices = np.asarray(reference_indices, dtype=int)
    if (reference_indices < 0).any() or (reference_indices >= len(candidate_lats)).any():
        raise ValueError("Fixed point indices fall outside the CERRA UK-box candidates.")

    selected_lats = candidate_lats[reference_indices]
    selected_lons = candidate_lons[reference_indices]
    if not np.allclose(selected_lats, reference_lats, rtol=0.0, atol=1e-10):
        raise ValueError("Fixed latitudes do not match the reference CERRA grid/order.")
    if not np.allclose(selected_lons, reference_lons, rtol=0.0, atol=1e-10):
        raise ValueError("Fixed longitudes do not match the reference CERRA grid/order.")

    points = gpd.GeoDataFrame(
        {
            "cerra_y_index": candidate_rows[reference_indices],
            "cerra_x_index": candidate_cols[reference_indices],
            "latitude": reference_lats,
            "longitude": reference_lons,
        },
        geometry=gpd.points_from_xy(reference_lons, reference_lats),
        crs="EPSG:4326",
    ).to_crs(target_crs)

    print(
        f"  CERRA UK-box candidates={len(candidate_lats):,}; "
        f"fixed points verified={len(points):,}"
    )
    return {
        "cerra_y_index": points["cerra_y_index"].to_numpy(dtype=int),
        "cerra_x_index": points["cerra_x_index"].to_numpy(dtype=int),
        "latitude": points["latitude"].to_numpy(dtype=float),
        "longitude": points["longitude"].to_numpy(dtype=float),
        "x": points.geometry.x.to_numpy(dtype=float),
        "y": points.geometry.y.to_numpy(dtype=float),
        "geometry": points.geometry,
    }


def save_feature_outputs(
    processed_dir: Path,
    point_data: dict[str, np.ndarray],
    terrain_features: np.ndarray,
    parameters: dict,
) -> None:
    # These land_* files describe only the fixed 2,022-point sample. UK-wide
    # cerra_lats/cerra_lons/terrain_features files are intentionally untouched.
    np.save(processed_dir / "land_lats.npy", point_data["latitude"])
    np.save(processed_dir / "land_lons.npy", point_data["longitude"])
    np.save(processed_dir / "land_cerra_y_indices.npy", point_data["cerra_y_index"])
    np.save(processed_dir / "land_cerra_x_indices.npy", point_data["cerra_x_index"])
    np.save(processed_dir / "land_terrain_features.npy", terrain_features)

    metadata = {
        "feature_names": FEATURE_NAMES,
        "feature_units": FEATURE_UNITS,
        **parameters,
    }
    with (processed_dir / "land_terrain_features_metadata.json").open("w") as handle:
        json.dump(metadata, handle, indent=2)

    data_vars = {}
    for idx, name in enumerate(FEATURE_NAMES):
        data_vars[name] = xr.DataArray(
            terrain_features[:, idx],
            dims=("point",),
            attrs={"units": FEATURE_UNITS[name]},
        )

    dataset = xr.Dataset(
        data_vars=data_vars,
        coords={
            "point": np.arange(len(terrain_features), dtype=int),
            "latitude": ("point", point_data["latitude"]),
            "longitude": ("point", point_data["longitude"]),
            "easting": ("point", point_data["x"]),
            "northing": ("point", point_data["y"]),
            "cerra_y_index": ("point", point_data["cerra_y_index"]),
            "cerra_x_index": ("point", point_data["cerra_x_index"]),
        },
        attrs={
            "title": "Static terrain features at Scottish CERRA land points",
            "target_crs": parameters["target_crs"],
            "horizontal_units": "metre",
            "method_note": (
                "Terrain statistics exclude NoData and sea pixels. TPI uses "
                "circular land-only neighbourhoods."
            ),
        },
    )
    dataset.to_netcdf(processed_dir / "land_terrain_features.nc")


def save_verification_figure(
    path: Path,
    lons: np.ndarray,
    lats: np.ndarray,
    terrain_features: np.ndarray,
) -> None:
    fig, axes = plt.subplots(2, 3, figsize=(18, 10), constrained_layout=True)
    for idx, (name, ax) in enumerate(zip(FEATURE_NAMES, axes.flat)):
        cmap = "terrain" if name in ("elevation", "hilliness") else "viridis"
        sc = ax.scatter(
            lons,
            lats,
            c=terrain_features[:, idx],
            s=4,
            cmap=cmap,
            linewidths=0,
        )
        ax.set_title(f"{name} ({FEATURE_UNITS[name]})")
        ax.set_xlabel("Longitude")
        ax.set_ylabel("Latitude")
        ax.set_aspect("equal", adjustable="box")
        fig.colorbar(sc, ax=ax, shrink=0.85)
    fig.savefig(path, dpi=300)
    plt.close(fig)


def main() -> None:
    args = parse_args()
    target_crs = CRS.from_user_input(args.target_crs)
    if not target_crs.is_projected:
        raise ValueError(f"Target CRS must be projected: {target_crs}")
    axis_units = {axis.unit_name.lower() for axis in target_crs.axis_info}
    if not any("metre" in unit or "meter" in unit for unit in axis_units):
        raise ValueError(f"Target CRS axes must use metres: {target_crs}")

    processed_dir = Path(args.processed_dir)
    results_dir = Path(args.results_dir)
    processed_dir.mkdir(parents=True, exist_ok=True)
    results_dir.mkdir(parents=True, exist_ok=True)

    dem_paths = [Path(path) for path in sorted(glob.glob(args.dem_glob))]
    if not dem_paths:
        raise FileNotFoundError(f"No DEM tiles matched: {args.dem_glob}")
    cerra_path = require_file(args.cerra_grid, "CERRA reference grid")

    inspect_dem_sources(dem_paths)
    dem, transform = build_projected_dem(
        dem_paths, target_crs, args.resolution_m
    )
    save_projected_dem(
        processed_dir / "dem_300m_epsg27700.tif",
        dem,
        transform,
        target_crs,
    )

    print("Reading land and coastline geometries...")
    land_geometry = read_vector_union(
        args.land_vector, target_crs, "Land polygon vector"
    )
    if args.coastline_vector:
        coastline_geometry = read_vector_union(
            args.coastline_vector, target_crs, "Coastline vector"
        )
        if isinstance(coastline_geometry, (Polygon, MultiPolygon)):
            coastline_geometry = polygon_exteriors(coastline_geometry)
    else:
        coastline_geometry = polygon_exteriors(land_geometry)
        print("  no coastline vector supplied; using exterior land boundaries")

    land_mask = make_land_mask(land_geometry, dem.shape, transform)
    valid_dem = np.isfinite(dem)
    valid_land = valid_dem & land_mask
    if not valid_land.any():
        raise ValueError("Land polygon and projected DEM have no valid overlap.")
    dem_land = np.where(valid_land, dem, np.nan).astype(np.float32)
    print(
        f"  valid land pixels={valid_land.sum():,}/{valid_land.size:,}; "
        f"NoData pixels={(~valid_dem).sum():,}"
    )

    slope_grid = compute_slope(dem_land, valid_land, args.resolution_m)

    point_data = load_fixed_cerra_points(
        cerra_path,
        Path(args.point_lats),
        Path(args.point_lons),
        Path(args.point_indices),
        target_crs,
    )
    n_points = len(point_data["latitude"])
    if args.expected_points and n_points != args.expected_points:
        raise ValueError(
            f"Expected {args.expected_points:,} Scotland land points but selected "
            f"{n_points:,}. Check the boundary source and inclusion rule."
        )

    dem_x, dem_y = pixel_centres(transform, *dem.shape)
    elevation = interpolate_with_nearest_fallback(
        dem_land,
        valid_land,
        dem_x,
        dem_y,
        point_data["x"],
        point_data["y"],
        "elevation",
    )
    slope = interpolate_with_nearest_fallback(
        slope_grid,
        np.isfinite(slope_grid),
        dem_x,
        dem_y,
        point_data["x"],
        point_data["y"],
        "slope",
    )

    hilliness, tpi_5km, tpi_75km = compute_neighbourhood_features(
        dem_land,
        valid_land,
        transform,
        dem_x,
        dem_y,
        point_data["x"],
        point_data["y"],
        elevation,
        args.resolution_m,
        args.hilliness_radius_km * 1000.0,
        args.tpi_small_radius_km * 1000.0,
        args.tpi_large_radius_km * 1000.0,
    )

    print("Computing projected point-to-coast distances...")
    point_series = gpd.GeoSeries(point_data["geometry"], crs=target_crs)
    dist_coast = point_series.distance(coastline_geometry).to_numpy() / 1000.0

    terrain_features = np.column_stack(
        [elevation, slope, hilliness, tpi_5km, tpi_75km, dist_coast]
    )
    if terrain_features.shape != (n_points, len(FEATURE_NAMES)):
        raise RuntimeError(f"Unexpected feature shape: {terrain_features.shape}")
    if not np.isfinite(terrain_features).all():
        bad = {
            name: int((~np.isfinite(terrain_features[:, idx])).sum())
            for idx, name in enumerate(FEATURE_NAMES)
        }
        raise ValueError(f"Non-finite terrain features remain: {bad}")

    parameters = {
        "target_crs": target_crs.to_string(),
        "resolution_m": args.resolution_m,
        "hilliness_radius_km": args.hilliness_radius_km,
        "hilliness_diameter_km": args.hilliness_radius_km * 2,
        "tpi_small_radius_km": args.tpi_small_radius_km,
        "tpi_large_radius_km": args.tpi_large_radius_km,
        "dem_resampling": "average",
        "neighbourhood_shape": "circular",
        "neighbourhood_centre": "exact projected CERRA point coordinates",
        "neighbourhood_validity": "valid land pixels only",
        "dem_files": [str(path) for path in dem_paths],
        "cerra_reference": str(cerra_path),
        "point_lats": str(args.point_lats),
        "point_lons": str(args.point_lons),
        "point_indices": str(args.point_indices),
        "land_vector": str(args.land_vector),
        "coastline_vector": str(args.coastline_vector) if args.coastline_vector else None,
    }
    save_feature_outputs(processed_dir, point_data, terrain_features, parameters)
    save_verification_figure(
        results_dir / "land_terrain_features_map.png",
        point_data["longitude"],
        point_data["latitude"],
        terrain_features,
    )

    print("\n=== projected terrain processing complete ===")
    print(f"terrain_features shape: {terrain_features.shape}")
    for idx, name in enumerate(FEATURE_NAMES):
        values = terrain_features[:, idx]
        print(
            f"  {name:12s}: min={values.min():.3f}, "
            f"max={values.max():.3f}, mean={values.mean():.3f}, "
            f"NaN={np.isnan(values).sum()}"
        )
    print(f"Saved outputs to {processed_dir} and {results_dir}")


if __name__ == "__main__":
    main()
