#!/usr/bin/env python3
"""Structure-preserving permutation importance on complete test timestamps."""

from __future__ import annotations

import json

import joblib
import numpy as np

from experiment_config import ARRAY_PATHS, EXPERIMENT_DIR, EXPERIMENT_ID, FEATURE_NAMES


N_TIME_BLOCKS = 120
N_REPEATS = 5
SEED = 42
STATIC_FEATURE_INDICES = set(range(1, 7))
TEMPORAL_FEATURE_INDICES = {7, 8}


def rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(
        np.sqrt(
            np.mean(
                (np.asarray(y_pred, dtype=np.float64) - y_true.astype(np.float64))
                ** 2
            )
        )
    )


def main() -> None:
    metadata_path = EXPERIMENT_DIR / "model_metadata.json"
    if not metadata_path.is_file():
        raise FileNotFoundError("Run versioned training before importance analysis.")
    with metadata_path.open() as handle:
        model_metadata = json.load(handle)
    if model_metadata.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("Model metadata belongs to another experiment.")
    if model_metadata.get("feature_names") != FEATURE_NAMES:
        raise ValueError("Model and importance feature schemas differ.")

    x_test = np.load(ARRAY_PATHS["X_test"], mmap_mode="r")
    y_test = np.load(ARRAY_PATHS["y_test"], mmap_mode="r")
    meta_test = np.load(ARRAY_PATHS["test_metadata"], mmap_mode="r")
    n_points = len(np.load("data/processed/land_lats.npy", mmap_mode="r"))
    if len(x_test) % n_points:
        raise ValueError("Test rows are not divisible into complete point blocks.")
    n_blocks = len(x_test) // n_points

    block_metadata = np.asarray(meta_test[::n_points, 2:6], dtype=int)
    if len(block_metadata) != n_blocks or len(np.unique(block_metadata, axis=0)) != n_blocks:
        raise ValueError("Test timestamp blocks are not unique and point-aligned.")

    rng = np.random.default_rng(SEED)
    selected_blocks = np.sort(
        rng.choice(n_blocks, size=min(N_TIME_BLOCKS, n_blocks), replace=False)
    )
    row_indices = (
        selected_blocks[:, None] * n_points + np.arange(n_points)[None, :]
    ).ravel()
    x_blocks = np.asarray(x_test[row_indices], dtype=np.float32).reshape(
        len(selected_blocks), n_points, len(FEATURE_NAMES)
    )
    y_blocks = np.asarray(y_test[row_indices], dtype=np.float32).reshape(
        len(selected_blocks), n_points
    )

    models = {
        "RandomForest": joblib.load(EXPERIMENT_DIR / "rf_model.joblib"),
        "XGBoost": joblib.load(EXPERIMENT_DIR / "xgb_model.joblib"),
    }
    results = {
        "experiment_id": EXPERIMENT_ID,
        "method": (
            "Complete timestamps sampled. ERA5 and static features are permuted "
            "across points with one mapping shared across timestamps; month terms "
            "are permuted across timestamp blocks."
        ),
        "seed": SEED,
        "n_time_blocks": int(len(selected_blocks)),
        "n_points_per_block": int(n_points),
        "n_rows": int(len(row_indices)),
        "n_repeats": N_REPEATS,
        "models": {},
    }

    flat_y = y_blocks.ravel()
    for model_name, model in models.items():
        baseline = rmse(flat_y, model.predict(x_blocks.reshape(-1, len(FEATURE_NAMES))))
        print(f"\n{model_name}: block-sample baseline RMSE={baseline:.4f}")
        model_results = {"baseline_rmse": baseline, "features": {}}
        for feature_index, feature_name in enumerate(FEATURE_NAMES):
            increases = []
            for _ in range(N_REPEATS):
                permuted = x_blocks.copy()
                if feature_index in TEMPORAL_FEATURE_INDICES:
                    permutation = rng.permutation(len(selected_blocks))
                    permuted[:, :, feature_index] = x_blocks[
                        permutation, :, feature_index
                    ]
                else:
                    # A shared mapping retains the permuted point's time series
                    # while breaking its alignment with target location.
                    permutation = rng.permutation(n_points)
                    permuted[:, :, feature_index] = x_blocks[
                        :, permutation, feature_index
                    ]
                prediction = model.predict(
                    permuted.reshape(-1, len(FEATURE_NAMES))
                )
                increases.append(rmse(flat_y, prediction) - baseline)
            model_results["features"][feature_name] = {
                "rmse_increase_mean": float(np.mean(increases)),
                "rmse_increase_std": float(np.std(increases)),
                "repeats": increases,
            }
            print(
                f"  {feature_name:12s}: "
                f"{np.mean(increases):+.4f} +/- {np.std(increases):.4f}"
            )
        results["models"][model_name] = model_results

    output_path = EXPERIMENT_DIR / "block_permutation_importance.json"
    temporary = output_path.with_suffix(".json.tmp")
    with temporary.open("w") as handle:
        json.dump(results, handle, indent=2)
    temporary.replace(output_path)
    print(f"Saved {output_path}")


if __name__ == "__main__":
    main()
