#!/usr/bin/env python3
"""Fit two exact, chunked linear baselines for the versioned experiment."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone

import numpy as np

from experiment_config import (
    ARRAY_PATHS,
    EXPERIMENT_DIR,
    EXPERIMENT_ID,
    FEATURE_NAMES,
    TRAIN_YEARS,
)


MANIFEST_PATH = EXPERIMENT_DIR / "experiment_manifest.json"
MODEL_PATH = EXPERIMENT_DIR / "linear_baseline_models.npz"
METADATA_PATH = EXPERIMENT_DIR / "linear_baseline_metadata.json"
CHUNK_SIZE = 250_000
SPECS = {
    "LinearERA5Seasonal": ["era5_wind", "sin_month", "cos_month"],
    "LinearFullFeatures": FEATURE_NAMES,
}


def sha256_file(path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def chunks(n_rows: int):
    for start in range(0, n_rows, CHUNK_SIZE):
        yield slice(start, min(start + CHUNK_SIZE, n_rows))


def fit_chunked_ols(x, y, indices: list[int]) -> dict[str, np.ndarray]:
    """Fit standardized OLS via small sufficient-statistic matrices."""
    n = len(y)
    sums = np.zeros(len(indices), dtype=np.float64)
    sums_sq = np.zeros(len(indices), dtype=np.float64)
    for block in chunks(n):
        values = np.asarray(x[block, indices], dtype=np.float64)
        sums += values.sum(axis=0)
        sums_sq += np.square(values).sum(axis=0)
    mean = sums / n
    variance = np.maximum(sums_sq / n - mean**2, 0.0)
    scale = np.sqrt(variance)
    scale[scale == 0] = 1.0

    dimension = len(indices) + 1
    gram = np.zeros((dimension, dimension), dtype=np.float64)
    rhs = np.zeros(dimension, dtype=np.float64)
    for block in chunks(n):
        values = np.asarray(x[block, indices], dtype=np.float64)
        standardized = (values - mean) / scale
        design = np.empty((len(values), dimension), dtype=np.float64)
        design[:, 0] = 1.0
        design[:, 1:] = standardized
        target = np.asarray(y[block], dtype=np.float64)
        gram += design.T @ design
        rhs += design.T @ target
    parameters = np.linalg.pinv(gram, rcond=1e-12) @ rhs
    return {
        "indices": np.asarray(indices, dtype=np.int64),
        "mean": mean,
        "scale": scale,
        "intercept": parameters[:1],
        "coefficients_standardized": parameters[1:],
    }


def main() -> None:
    if not MANIFEST_PATH.is_file():
        raise FileNotFoundError("Run 03a_validate_experiment.py first.")
    with MANIFEST_PATH.open() as handle:
        manifest = json.load(handle)
    if manifest.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("Manifest belongs to another experiment.")
    if manifest.get("feature_names") != FEATURE_NAMES:
        raise ValueError("Manifest feature schema does not match linear baselines.")

    x = np.load(ARRAY_PATHS["X_train"], mmap_mode="r")
    y = np.load(ARRAY_PATHS["y_train"], mmap_mode="r")
    if x.shape != (len(y), len(FEATURE_NAMES)):
        raise ValueError(f"Unexpected training shapes: X={x.shape}, y={y.shape}")

    fitted = {}
    metadata_models = {}
    for model_name, names in SPECS.items():
        indices = [FEATURE_NAMES.index(name) for name in names]
        print(f"Fitting {model_name} with {names}...")
        result = fit_chunked_ols(x, y, indices)
        fitted[model_name] = result
        raw_coefficients = result["coefficients_standardized"] / result["scale"]
        raw_intercept = float(
            result["intercept"][0] - np.dot(raw_coefficients, result["mean"])
        )
        metadata_models[model_name] = {
            "feature_names": names,
            "feature_indices": indices,
            "intercept_raw_scale": raw_intercept,
            "coefficients_raw_scale": {
                name: float(value) for name, value in zip(names, raw_coefficients)
            },
        }

    arrays = {}
    for model_name, result in fitted.items():
        prefix = model_name.lower()
        for key, value in result.items():
            arrays[f"{prefix}_{key}"] = value
    temporary = MODEL_PATH.with_suffix(".npz.tmp")
    with temporary.open("wb") as handle:
        np.savez(handle, **arrays)
    temporary.replace(MODEL_PATH)

    metadata = {
        "experiment_id": EXPERIMENT_ID,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "manifest_sha256": sha256_file(MANIFEST_PATH),
        "train_years": TRAIN_YEARS,
        "n_train": int(len(y)),
        "estimator": "ordinary least squares on standardized predictors",
        "fit_method": "chunked sufficient statistics; no row subsampling",
        "chunk_size": CHUNK_SIZE,
        "model_file": MODEL_PATH.name,
        "model_sha256": sha256_file(MODEL_PATH),
        "models": metadata_models,
    }
    temporary_metadata = METADATA_PATH.with_suffix(".json.tmp")
    with temporary_metadata.open("w") as handle:
        json.dump(metadata, handle, indent=2)
    temporary_metadata.replace(METADATA_PATH)
    print(f"Saved {MODEL_PATH} and {METADATA_PATH}")


if __name__ == "__main__":
    main()
