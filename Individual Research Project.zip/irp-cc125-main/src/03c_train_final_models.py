#!/usr/bin/env python3
"""Fit final versioned models using parameters selected by 03b."""

from __future__ import annotations

import hashlib
import json
import os
import platform
import time
from datetime import datetime, timezone

os.environ.setdefault("JOBLIB_TEMP_FOLDER", "/dev/shm")

import joblib
import numpy as np
import sklearn
import xgboost
from sklearn.ensemble import RandomForestRegressor

from experiment_config import (
    ARRAY_PATHS,
    EXPERIMENT_DIR,
    EXPERIMENT_ID,
    FEATURE_NAMES,
    TRAIN_YEARS,
)


MANIFEST_PATH = EXPERIMENT_DIR / "experiment_manifest.json"
TUNING_PATH = EXPERIMENT_DIR / "tuning_results.json"


def sha256_file(path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def select_best(entries: dict) -> dict:
    best_key = min(entries, key=lambda key: entries[key]["mean_rmse"])
    return entries[best_key]


def atomic_joblib_dump(value, path) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    joblib.dump(value, temporary)
    temporary.replace(path)


def main() -> None:
    if not MANIFEST_PATH.is_file() or not TUNING_PATH.is_file():
        raise FileNotFoundError("Run 03a validation and 03b tuning first.")
    manifest_hash = sha256_file(MANIFEST_PATH)
    with TUNING_PATH.open() as handle:
        tuning = json.load(handle)
    if tuning.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("Tuning results belong to another experiment.")
    if tuning.get("manifest_sha256") != manifest_hash:
        raise ValueError("Tuning results do not match the validated input manifest.")

    best_xgb = select_best(tuning["models"]["XGBoost"])
    best_rf = select_best(tuning["models"]["RandomForest"])
    xgb_params = best_xgb["params"]
    rf_params = best_rf["params"]

    x_train = np.asarray(np.load(ARRAY_PATHS["X_train"]), dtype=np.float32)
    y_train = np.asarray(np.load(ARRAY_PATHS["y_train"]), dtype=np.float32)
    if x_train.shape[1] != len(FEATURE_NAMES) or len(x_train) != len(y_train):
        raise ValueError("Training arrays no longer match the validated schema.")
    if not (np.isfinite(x_train).all() and np.isfinite(y_train).all()):
        raise ValueError("Training arrays contain non-finite values.")

    print(f"Experiment: {EXPERIMENT_ID}")
    print(f"Training rows: {len(y_train):,}; features: {FEATURE_NAMES}")
    print(f"Selected RF: {rf_params}")
    print(f"Selected XGBoost: {xgb_params}")

    start = time.time()
    rf_model = RandomForestRegressor(**rf_params)
    rf_model.fit(x_train, y_train)
    rf_seconds = time.time() - start
    print(f"RandomForest final fit: {rf_seconds:.1f}s")

    start = time.time()
    xgb_model = xgboost.XGBRegressor(**xgb_params)
    xgb_model.fit(x_train, y_train)
    xgb_seconds = time.time() - start
    print(f"XGBoost final fit: {xgb_seconds:.1f}s")

    rf_path = EXPERIMENT_DIR / "rf_model.joblib"
    xgb_path = EXPERIMENT_DIR / "xgb_model.joblib"
    atomic_joblib_dump(rf_model, rf_path)
    atomic_joblib_dump(xgb_model, xgb_path)

    metadata = {
        "experiment_id": EXPERIMENT_ID,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "manifest_sha256": manifest_hash,
        "tuning_results_sha256": sha256_file(TUNING_PATH),
        "feature_names": FEATURE_NAMES,
        "train_years": TRAIN_YEARS,
        "n_train": int(len(y_train)),
        "input_dtype": str(x_train.dtype),
        "selection_rule": "lowest mean forward-chaining RMSE",
        "random_forest": {
            "params": rf_params,
            "mean_forward_rmse": best_rf["mean_rmse"],
            "fit_seconds": rf_seconds,
            "model_file": rf_path.name,
            "model_sha256": sha256_file(rf_path),
        },
        "xgboost": {
            "params": xgb_params,
            "mean_forward_rmse": best_xgb["mean_rmse"],
            "fit_seconds": xgb_seconds,
            "model_file": xgb_path.name,
            "model_sha256": sha256_file(xgb_path),
        },
        "software": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "scikit_learn": sklearn.__version__,
            "xgboost": xgboost.__version__,
            "joblib": joblib.__version__,
        },
    }
    metadata_path = EXPERIMENT_DIR / "model_metadata.json"
    temporary = metadata_path.with_suffix(".json.tmp")
    with temporary.open("w") as handle:
        json.dump(metadata, handle, indent=2)
    temporary.replace(metadata_path)
    print(f"Saved versioned models and metadata to {EXPERIMENT_DIR}")


if __name__ == "__main__":
    main()
