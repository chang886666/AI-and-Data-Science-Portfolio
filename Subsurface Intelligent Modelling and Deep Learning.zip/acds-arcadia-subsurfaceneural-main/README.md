# Arcadia project
## Applying Computational & Data Science: Mini Project 2

### Group Name: SubsurfaceNeural

## Project Overview
This project, titled "From Core to Computation", focuses on deep and machine learning strategies for geological data interpretation in the mythical Arcadia's Avalon Basin.

This project applies machine learning and deep learning techniques to geological subsurface data from the Avalon Basin (Quadrants 204–205) in the fictional Arcadia setting. The objective is to predict facies classes and horizontal permeability values by integrating heterogeneous data sources including:

- Wireline logs  
- Core images with their depth
- Core-plug permeability measurements  
- Facies classes for each well


### Geographical Context
The dataset focuses on Paleocene deep-marine strata and highlights the practical challenges of subsurface data science like:
- Sparse data  
- Depth misalignment between core and wireline logs
- Strongly skewed permeability distributions


## User Instructions
This instructions will guide you through setting up the permeability and facies prediction models on your local machine.

### Installation & Setup

### 1 Prerequisites
Ensure you have the following software installed:
- Python: Version 3.8 or higher is recommended
- Git: For cloning the repository

### 2 Clone the Repository
Open your terminal or command prompt and run the following commands to download the project files:

git clone https://github.com/ese-ada-lovelace-2025/acds-arcadia-subsurfaceneural.git

### 3 Set up a Virtual Environment
Using a virtual environment is strongly recommended to isolate project dependencies and avoid conflicts.

**Install the dependencies**
With the virtual environment active, install all required Python packages using pip. The project dependencies are: matplotlib, numpy, pandas, scikit-learn, seaborn, lasio, xgboost, optuna and pytorch. 

pip install matplotlib numpy pandas scikit-learn seaborn lasio xgboost torch

## User Input Data Requirements
To run the permeability prediction model, the model requires well log data (.las or .csv) as an input

To run the facies classification model, the model requires wirelog data (.las) and core segmented image (.npy) with the depth data (.npy)

The user doesn't have to preprocess the data, when the user feeds the data into the model, the model will preprocess the data and predicts the output.

The training data can be downloaded using the [link](https://imperiallondon-my.sharepoint.com/:f:/g/personal/vk825_ic_ac_uk/IgCEUsxGtgU9S7L1ZKLgPkyRAcvhfl8Kr0Sjn8UoWoxrdH4?e=BFh4bm)

## Testing
The software includes tests, which you can use to check its operation on your system. With pytest installed, these can be run with

python -m pytest


