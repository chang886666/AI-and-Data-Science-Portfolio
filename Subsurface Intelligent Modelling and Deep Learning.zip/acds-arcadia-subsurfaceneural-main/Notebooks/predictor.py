"""
Baseline permeability predictor.

Uses:
  - raw_data/labels/permeability/*.csv   (core sample depths + permeability)
  - raw_data/wirelineLog/*.las           (wireline logs)

Pipeline (per well):
  1. Find the permeabilty CSV for that well (by well id in filename).
  2. Load depth + permeability (horizontal Kair).
  3. Apply core->log depth shift rules.
  4. Find the LAS file for that well (by well id in filename).
  5. Load LAS, clean nulls (-999 / -999.25), keep selected curves.
  6. Interpolate curves onto shifted core sample depths.
  7. Stack all wells and train a RandomForestRegressor.

Outputs:
  - Prints per-well sample counts.
  - Prints train/test R² and MAE.
  - Saves model to models/baseline_perm_rf.joblib
"""

import warnings
warnings.filterwarnings("ignore")

from pathlib import Path
from typing import List, Dict, Tuple

import lasio # type: ignore
import numpy as np
import pandas as pd
import joblib

from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_absolute_error


# Paths

PROJECT_DIR = Path(__file__).resolve().parent

PERM_DIR = PROJECT_DIR / "raw_data" / "labels" / "permeability"

# LAS files
WIRELINE_DIR = PROJECT_DIR / "raw_data" / "wirelineLog"

# Where to save the trained model
MODEL_DIR = PROJECT_DIR / "models"
MODEL_DIR.mkdir(parents=True, exist_ok=True)

# Configuration

# Which LAS curves to use as features
FEATURE_CURVES: List[str] = [
    "GR",
    "DENS",
    "NEUT",
    "PEF",
    "RDEP",
]

# Wells we want to try to use
WELL_IDS: List[str] = [
    "204_19_7",
    "204_20_1",
    "204_20_1Z",
    "204_20_2",
    "204_20_3",
    "204_20_6A",
    "204_20a_7",
    "204_24a_6",
    "204_24a_7",
]

# Depth alignment rules: (min_depth, max_depth, shift_in_meters)
DEPTH_SHIFT_RULES: Dict[str, List[Tuple[float, float, float]]] = {
    "204_19_6": [],  # no shift

    "204_19_7": [
        (2131.00, 2157.68, +1.8),
        (2158.00, 2180.38, +1.6),
        (2540.00, 2544.89, +3.0),
    ],

    "204_20_1": [
        (1945.00, 2116.00, +3.0),
    ],

    "204_20_1Z": [
        (2673.00, 2686.46, +5.0),
    ],

    "204_20_2": [
        (1998.00, 2018.55, +2.0),
    ],

    "204_20_3": [
        (2401.00, 2425.75, -1.2),
        (2427.50, 2436.83, -2.7),
        (2658.00, 2685.79, +1.2),
        (2958.00, 2978.15, +1.6),
    ],

    "204_20_6A": [],  # no shift
    "204_20_7": [],   # no shift

    "204_24a_6": [
        (2211.00, 2230.70, +3.5),
        (2416.00, 2429.67, +2.0),
        (2429.67, 2438.96, +2.43),
        (2440.20, 2462.93, +0.8),
        (2463.00, 2485.60, 0.0),
        (2485.60, 2493.50, +0.4),
    ],

    "204_24a_7": [
        (2075.00, 2102.00, +2.2),
        (2102.00, 2127.85, +2.35),
        (2128.50, 2145.90, +2.0),
        (2146.00, 2162.60, +1.8),
        (2163.00, 2179.30, +1.2),
        (2180.00, 2188.56, +1.0),
        (2189.00, 2206.92, +0.85),
        (2208.50, 2240.65, +0.2),
    ],
}


# Helper functions – file lookup

def find_perm_csv_for_well(well_id: str) -> Path:
    """
    Find the best-matching permeability CSV for a given well_id.

    Priority:
        1) raw_data/labels/permeability/data_<well_id>.csv
        2) raw_data/labels/permeability/<well_id>.csv
        3) any file containing the well_id in its name (last resort)
    """
    # 1) Exact "data_<well_id>.csv"
    candidate1 = PERM_DIR / f"data_{well_id}.csv"
    if candidate1.exists():
        return candidate1

    # 2) Exact "<well_id>.csv"
    candidate2 = PERM_DIR / f"{well_id}.csv"
    if candidate2.exists():
        return candidate2

    # 3) Fallback: any CSV containing well_id in its name
    candidates = list(PERM_DIR.glob(f"*{well_id}*.csv"))
    if not candidates:
        raise FileNotFoundError(
            f"Permeability CSV not found for well {well_id} in {PERM_DIR}"
        )

    if len(candidates) > 1:
        print(
            f"  [WARN] Multiple permeability CSVs found for {well_id}, "
            f"using {candidates[0].name}"
        )

    return candidates[0]


def find_las_for_well(well_id: str) -> Path:
    """
    Auto-detect LAS file for a given well.

    Tries filenames that contain:
      - well_id (e.g. '204_19_7')
      - or well_id with '-' instead of '_' (e.g. '204-19-7')
    """
    if not WIRELINE_DIR.exists():
        raise FileNotFoundError(f"Wireline log directory does not exist: {WIRELINE_DIR}")

    candidates = []
    patterns = [
        well_id,
        well_id.replace("_", "-"),
    ]

    for pat in patterns:
        candidates.extend(WIRELINE_DIR.glob(f"*{pat}*.las"))

    candidates = list({c.resolve() for c in candidates})

    if not candidates:
        raise FileNotFoundError(
            f"LAS file not found for well {well_id} in {WIRELINE_DIR}"
        )

    if len(candidates) > 1:
        print(f"  [WARN] Multiple LAS files found for {well_id}, using {candidates[0].name}")

    return candidates[0]

# Helper functions – depth shifts, loading, feature building

def apply_depth_shift(well_id: str, depths: np.ndarray) -> np.ndarray:
    """Apply piecewise depth shift rules for a well."""
    rules = DEPTH_SHIFT_RULES.get(well_id, [])
    if not rules:
        return depths.copy()

    shifted = depths.astype(float).copy()
    for d_min, d_max, shift in rules:
        mask = (shifted >= d_min) & (shifted <= d_max)
        shifted[mask] += shift
    return shifted


def load_permeability_csv(well_id: str, csv_path: Path) -> Tuple[np.ndarray, np.ndarray]:
    """
    Load permeability CSV for a well.

    Returns
    -------
    depths_core : np.ndarray
        Core sample depths (as in CSV, before shift).
    perm : np.ndarray
        Horizontal permeability values (Kair) as target.
    """
    if not csv_path.exists():
        raise FileNotFoundError(f"Permeability CSV not found: {csv_path}")

    df = pd.read_csv(csv_path)

    print(f"  Using perm file: {csv_path.name}")
    print("  Perm CSV columns:", list(df.columns))

    # Find depth column (contains 'DEPTH' in the name)
    depth_col = None
    for c in df.columns:
        if "DEPTH" in str(c).upper():
            depth_col = c
            break
    if depth_col is None:
        raise ValueError(f"Could not find a depth column in {csv_path}")

    # Find HORIZONTAL permeability column
    perm_col = None
    for c in df.columns:
        cu = str(c).upper()
        if "PERMEAB" in cu and "HORIZ" in cu:
            perm_col = c
            break
    # If that fails, just pick any permeability-like column
    if perm_col is None:
        for c in df.columns:
            if "PERMEAB" in str(c).upper():
                perm_col = c
                break

    if perm_col is None:
        raise ValueError(f"No permeability column found in {csv_path}")

    # --- Convert text with commas, blanks, 'Core' etc. to numeric ---
    depth_series = (
        df[depth_col]
        .astype(str)
        .str.strip()
        .str.replace(",", ".", regex=False)
    )
    perm_series = (
        df[perm_col]
        .astype(str)
        .str.strip()
        .str.replace(",", ".", regex=False)
    )

    depths = pd.to_numeric(depth_series, errors="coerce").values
    perm = pd.to_numeric(perm_series, errors="coerce").values

    # Drop NaNs or non-positive permeability (optional)
    mask = np.isfinite(depths) & np.isfinite(perm)
    mask &= (perm > 0)
    depths = depths[mask]
    perm = perm[mask]

    return depths, perm


def load_logs_for_well(well_id: str) -> pd.DataFrame:
    """
    Load a LAS file for this well and return a cleaned dataframe of curves.

    Index: depth
    Columns: all curves
    """
    path = find_las_for_well(well_id)
    print(f"  Using LAS file: {path.name}")

    las = lasio.read(str(path))

    # Dataframe with depth index
    df_logs = las.df()

    # Replace common null markers with NaN
    df_logs = df_logs.replace(-999.0, np.nan)
    df_logs = df_logs.replace(-999.25, np.nan)

    return df_logs


def build_features_for_well(well_id: str) -> Tuple[np.ndarray, np.ndarray]:
    """
    For a single well:
      - load permeability CSV
      - apply depth shift
      - load logs
      - interpolate selected curves onto shifted depths

    Returns
    -------
    X : (n_samples, n_features)
    y : (n_samples,)
    """
    perm_path = find_perm_csv_for_well(well_id)
    depths_core, perm = load_permeability_csv(well_id, perm_path)
    depths_shifted = apply_depth_shift(well_id, depths_core)

    df_logs = load_logs_for_well(well_id)

    missing_curves = [c for c in FEATURE_CURVES if c not in df_logs.columns]
    if missing_curves:
        print(f"  [WARN] Well {well_id} missing curves {missing_curves}; skipping.")
        return None, None

    # Restrict to feature curves and clean nulls
    df_sel = df_logs[FEATURE_CURVES].copy()
    df_sel = df_sel.replace(-999.0, np.nan).replace(-999.25, np.nan)

    # Interpolate in depth and fill ends
    df_sel = df_sel.interpolate(method="index").bfill().ffill()

    # Reindex to the shifted core depths via union+interpolation trick
    core_index = pd.Index(depths_shifted, name=df_sel.index.name)
    df_union = df_sel.reindex(df_sel.index.union(core_index)).sort_index()
    df_union = df_union.interpolate(method="index").bfill().ffill()
    df_core = df_union.loc[core_index]

    X = df_core.values.astype(float)
    y = perm.astype(float)

    return X, y

# Training

def main():
    X_list = []
    y_list = []

    print("=== Baseline permeability regression ===")
    print("Project dir:", PROJECT_DIR)
    print("Permeability dir:", PERM_DIR)
    print("Wireline dir:", WIRELINE_DIR)
    print("Using curves:", FEATURE_CURVES)
    print()

    for well_id in WELL_IDS:
        print("Processing well:", well_id)
        try:
            X_well, y_well = build_features_for_well(well_id)
            if X_well is None:
                continue

            print("  Samples:", X_well.shape[0], " Features:", X_well.shape[1])
            X_list.append(X_well)
            y_list.append(y_well)
        except Exception as e:
            print(f"  [ERROR] Skipping well {well_id} because: {e}")

        print()

    if not X_list:
        print("No data collected – check PERM_DIR, LAS names, and depth-shift rules.")
        return

    X = np.vstack(X_list)
    y = np.concatenate(y_list)

    print("Total samples:", X.shape[0])
    print("Total features:", X.shape[1])

    if X.shape[0] != y.shape[0]:
        min_len = min(X.shape[0], y.shape[0])
        print(
            f"[WARN] X and y length mismatch (X={X.shape[0]}, y={y.shape[0]}). "
            f"Trimming both to {min_len} samples."
        )
        X = X[:min_len]
        y = y[:min_len]

    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    # Random Forest baseline
    model = RandomForestRegressor(
        n_estimators=200,
        max_depth=None,
        random_state=42,
        n_jobs=-1,
    )

    print("\nTraining RandomForestRegressor...")
    model.fit(X_train, y_train)

    # Evaluation
    y_pred_train = model.predict(X_train)
    y_pred_test = model.predict(X_test)

    r2_train = r2_score(y_train, y_pred_train)
    r2_test = r2_score(y_test, y_pred_test)
    mae_test = mean_absolute_error(y_test, y_pred_test)

    print("\n=== Results ===")
    print("Train R²: {:.3f}".format(r2_train))
    print("Test  R²: {:.3f}".format(r2_test))
    print("Test  MAE: {:.3f} (same units as permeability column)".format(mae_test))

    # Save model
    model_path = MODEL_DIR / "baseline_perm_rf.joblib"
    joblib.dump(
        {
            "model": model,
            "feature_curves": FEATURE_CURVES,
            "wells_used": WELL_IDS,
        },
        model_path,
    )

    print("\nSaved model to:", model_path)


if __name__ == "__main__":
    main()