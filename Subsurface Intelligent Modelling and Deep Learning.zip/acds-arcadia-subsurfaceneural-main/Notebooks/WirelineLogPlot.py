
import lasio
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator, LogLocator, AutoMinorLocator, FuncFormatter, LogFormatterMathtext
import numpy as np
import pandas as pd

from dataclasses import dataclass
from typing import Iterable
import os

@dataclass
class TrackLog:
    """
    Dataclass to define a TrackLog object, which stores plotting
    instructions for each log in the las. Used by plotting class
    to be called at each log. Allows for tracks to be considered
    independantly when plotting.
    """

    mnemonic: str  # identifier
    track: int = 0  # track to plot on
    units: str | None = None  # units
    label: str | None = None  # label
    xlim: tuple[float, float] | None = None  # x range to plot
    log_scale: bool = False
    invert_scale: bool = False  # invert x for certain logs
    color: str | None = None
    linestyle: str | None = None

    def __str__(self):
        """Define printing method for TrackLog object"""
        return (
            f"TrackLog("
            f"mnemonic= {self.mnemonic}, "
            f"track= {self.track}, "
            f"units= {self.units}, "
            f"label= {self.label}, "
            f"xim= {self.xlim}, "
            f"log_scale= {self.log_scale}, "
            f"invert_scale= {self.invert_scale}"
            f")"
        )


LASLike = str | lasio.LASFile


class WirelineLas:
    """
    Wireline log class to load and store log data as TrackLog objects
    for plotting in WirelineLogPlot. 
    
    Default dictionaries stored as immutable memeber variables which can be
    updated if given by the user then queried for each log. If not set by
    default and not given then handled by matplotlib and plotted sequentially
    by logs_to_plot sorting.

    """

    # define immutable default dictionaries
    default_track_dict = {'Zonations': 1}
    default_xlim_dict = {'GR': (0, 150), 'VShale': (0, 1), 'NEUT': (-0.15, 0.45), 'DENS': (1.95, 2.95), 'RDEP': (0.2, 20), 'PE': (0, 20)}
    default_log_scale_dict = {'RDEP': True}
    default_invert_scale_dict = {'NEUT': True}
    default_color_dict = {'GR': 'green', 'VShale': 'k', 'NEUT': 'yellow', 'DENS': 'k'}
    default_linestyle_dict = {'GR': '-', 'NEUT': '--', 'DENS': '-'}

    def __init__(
            self,
            las: LASLike,
            track_dict: dict[str, int] | None = None,
            xlim_dict: dict[str, tuple[float, float]] | None = None,
            log_scale_dict: dict[str, bool] | None = None,
            invert_scale_dict: dict[str, bool] | None = None,
            color_dict: dict[str, str] | None = None,
            linestyle_dict: dict[str, str] | None = None
            ):
        """
        Docstring for __init__
        
        :param self: WirelineLas object
        :param las: LASLike object passed from WirelineLogPlot
        :type las: LASLike
        :param track_dict: User input track dictionary to update default values
        :type track_dict: dict[str, int] | None
        :param xlim_dict: User input xlim dictionary to update default values
        :type xlim_dict: dict[str, tuple[float, float]] | None
        :param log_scale_dict: User input log scale dictionary to update
        default values
        :type log_scale_dict: dict[str, bool] | None
        :param invert_scale_dict: User input invert scale dictionary to update
        default values
        :type invert_scale_dict: dict[str, bool] | None
        :param color_dict: User input color dictionary to update default values
        :type color_dict: dict[str, str] | None
        :param linestyle_dict: User input linestyle dictionary to update
        default values
        :type linestyle_dict: dict[str, str] | None
        """

        # initialise las file as las type
        if isinstance(las, lasio.LASFile):
            self.las = las
            self.filename = None
        else:
            if not os.path.isfile(las):
                raise FileNotFoundError(las)

            self.filename = las
            self.las = lasio.read(str(self.filename))

        # initialise tracklog list for storing instructions as TrackLog objects
        self.tracklogs: list[TrackLog] = []

        # create and update dictionaries for plotting instructions if given by
        # the user
        self._track_dict = dict(self.default_track_dict)
        if track_dict:
            self._track_dict.update(track_dict)

        self._xlim_dict = dict(self.default_xlim_dict)
        if xlim_dict:
            self._xlim_dict.update(xlim_dict)

        self._log_scale_dict = dict(self.default_log_scale_dict)
        if log_scale_dict:
            self._log_scale_dict.update(log_scale_dict)

        self._invert_scale_dict = dict(self.default_invert_scale_dict)
        if invert_scale_dict:
            self._invert_scale_dict.update(invert_scale_dict)

        self._color_dict = dict(self.default_color_dict)
        if color_dict:
            self._color_dict.update(color_dict)

        self._linestyle_dict = dict(self.default_linestyle_dict)
        if linestyle_dict:
            self._linestyle_dict = dict(linestyle_dict)

        # helper function to change dictionaries if given

    def get_curve(self, mnemonic: str) -> np.ndarray:
        """For given mnemonic, return x data from las"""
        x = np.asarray(self.las[mnemonic], float)
        return x

    def depth(self) -> np.ndarray:
        """Return depth from las index"""
        return np.asarray(self.las.index, float)

    def create_tracklogs(self, mnemonics: list[str] | None = None):
        """
        Function to create a list of TrackLog objects which stores plotting
        instructions for each log, queried by mnemonic in las data. TrackLog
        list appended to self.tracklogs. Nothing is returned.

        :param self:
        :param mnemonics: list of log keys to query
        :type mnemonics: list[str] | None
        """
        for mnemonic in mnemonics:
            # retrieves lasio CurveItems by log key to define plotting
            # instructions by querying dictionaries.
            curve_item: lasio.CurveItem = self.las.curvesdict[mnemonic]

            # set up with default values - changed on plot if wanted
            # set up each tracklog
            self.tracklogs.append(
                TrackLog(
                    mnemonic=mnemonic,
                    track=self._track_dict.get(mnemonic, None),
                    units=curve_item.unit,
                    label=mnemonic,
                    xlim=self._xlim_dict.get(mnemonic, None),
                    log_scale=self._log_scale_dict.get(mnemonic, None),
                    invert_scale=self._invert_scale_dict.get(mnemonic, None),
                    color=self._color_dict.get(mnemonic, None),
                    linestyle=self._linestyle_dict.get(mnemonic, None)
                    )
                )


class WirelineLogPlot(WirelineLas):
    """
    WirelinePlot class to visualise wireline log data from las file types.

    Initialise with LASLike object containing the lasio.CurveItems, to
    create TrackLog objects to store instructions. Functions for specific
    plot types are given, including _plot_track() and _plot_zones(), which
    are called when plotting. Logs are considered independantly with a
    independant associated TrackLog object.

    Initialise with LASLike object and kwargs which are passed to WirelineLAS
    to update dictionaries.

    Bug: Currently calling _plot_track() to plot the log with the TrackLog
    object only works when each log is plotted on one track. Functionality
    implemented to share an axes however does not currenly work as intended.

    """

    def __init__(self, las: LASLike, **kwargs):
        """
        Initialise WirelineLogPlot with a LASLike file containing wireline data
        and **kwargs to initialise WirelineLas object, to update dictionaries.
        
        :param self:
        :param las: LASLike data format, to store wireline data with
        lasio.CurveItems
        :type las: LASLike
        :param kwargs: kwargs to initialise WirelineLas object to update
        dictionaries.
        """

        super().__init__(las, **kwargs)

        self.depth_index = self.depth()  # not used for las files

        # create tracklogs from the given las data
        self.tracks = self.create_tracklogs(self.las.curvesdict.keys())

        # store plot data, as track: [axes_num], for debugging and
        # subsequent plotting of additional points (perm points) on the
        # same axis, or additional curves (not currently working)
        self.track_plots = {}

    def _plot_track(self, ax: plt.Axes, tracklog: TrackLog):
        """
        _plot_track called to plot each TrackLog instruction on a given
        axis. tracklog.mnemonic used to query self.las CurveItem data.
        
        :param self:
        :param ax: Matplotlib axis object to plot log on
        :type ax: plt.Axes
        :param tracklog: TrackLog object storing plotting instruction and
        mnemonic to query data
        :type tracklog: TrackLog
        """
        # if VShale, calc curve, else, query data
        if tracklog.mnemonic == 'VShale':
            data_curve = self._calc_VShale()
        else:
            data_curve = self.las[tracklog.mnemonic]

        # set range if given, else set as default range by min, max
        if tracklog.xlim:
            ax.set_xlim(tracklog.xlim)
        else:
            ax.set_xlim(
                np.nanmin(self.las[tracklog.mnemonic]),
                np.nanmax(self.las[tracklog.mnemonic])
                )

        # invert if instructed to
        if tracklog.invert_scale:
            ax.invert_xaxis()

        # if log_scale, format accordingly, else standard formatting
        if tracklog.log_scale:
            ax.set_xscale('log')  # set to log scale

            # format major ticks by limits and log decades
            major_ticks = [ax.get_xlim()[0], 1, 10, ax.get_xlim()[1]]
            # sets ticks at the xlims, and 1, 10 for log ticks
            ax.set_xticks(major_ticks)  # set to be formatted

            # formats powers as log format and non-powers (xlim) as non-powers
            ax.xaxis.set_major_formatter(
                FuncFormatter(
                    lambda x, pos:
                    LogFormatterMathtext(base=10)(x)
                    if np.isclose(np.log10(x), round(np.log10(x)))
                    else f"{x:g}"
                )
            )

            ax.xaxis.set_minor_locator(LogLocator(base=10))  # minor ticks
            ax.minorticks_on()
        else:
            # auto minor ticks
            ax.xaxis.set_minor_locator(AutoMinorLocator(10))
            # only xlim major ticks labelled
            ax.set_xticks([ax.get_xlim()[0], ax.get_xlim()[1]])
            # format major tick labels as 3 sig. fig.
            ax.xaxis.set_major_formatter(
                FuncFormatter(lambda x, pos: f"{x:.3g}")
                )

        # set xlabel and position correctly above track    
        ax.set_xlabel(f'{tracklog.label} ({tracklog.units})', fontsize=16)
        ax.xaxis.set_label_position('top')
        ax.xaxis.tick_top()

        ax.grid(True, which='both', axis='both', alpha=0.2)

        # plot data curve with consistent depth
        ax.plot(data_curve, self.las['DEPTH'],
                label=tracklog.label,
                color=tracklog.color,
                linestyle=tracklog.linestyle
                )

    def _plot_zones(self, ax: plt.Axes, zonations: list[dict]):
        """
        _plot_zones function to plot the zonation intervals, currently
        set so given plt.Axes is a axes[0]. Zonations are plotted over
        the depth interval if given.

        Zonations expected as list of dictionaries with zone name, top, base
        and colour.

        Example zonations:
        ```zones = [
            {'name': 'SS', 'top': 1900, 'base': 2000, 'color': '#f8d48d'},
            {'name': 'Sh', 'top': 1850, 'base': 1900, 'color': '#928a7a'}
        ]
 
        :param self: Description
        :param ax: Description
        :type ax: plt.Axes
        :param zonations: List of dictionaries to store zone information
        :type zonations: list[dict]
        """
        ax.set_ylabel(
            f"DEPTH ({self.las.curves['DEPTH'].unit})",
            fontsize=12
            )

        ax.yaxis.set_major_locator(MultipleLocator(50))
        ax.yaxis.set_major_formatter('{x:.0f}')

        ax.yaxis.set_minor_locator(MultipleLocator(10))

        ax.set_xlabel('ZONES', fontsize=16)
        ax.xaxis.set_label_position('top')
        ax.xaxis.tick_top()

        # if no zonations, nothing is plotted
        if zonations is not None:
            # loop over all zones in zonations
            for zone in zonations:
                name = zone['name']
                top = zone['top']
                base = zone['base']
                color = zone['color']
                # plot zone
                ax.axhspan(
                    top, base, alpha=0.8,
                    facecolor=color,
                    edgecolor='k', lw=1, label=name
                            )

                # plot text, may not be needed if zones are small
                # checks if base and top are within range to prevent
                # text not in the depth range
                if self.depth_range is None:
                    plot_text = True
                else:
                    min_depth, max_depth = self.depth_range
                    plot_text = not (base < min_depth or top > max_depth)

                if plot_text:
                    ax.text(
                        0.4, 0.5 * (top + base), name,
                        transform=ax.get_yaxis_transform(),
                        va='center',
                        color='k',
                        fontsize=18
                    )

        # ticks not needed for zones
        ax.set_xticks([])
        ax.set_xticklabels([])

    def _plot_core_images(self, ax: plt.Axes, image_track: list[dict]):
        """
        _plot_Core_images function to plot images in a set track.

        Not currently implemented. Issue with image size and aspect over
        large depth intervals.

        :param self:
        :param ax: Matplotlib axes to plot images on
        :type ax: plt.Axes
        :param image_track: image to plot
        :type image_track: list[dict]
        """
        raise NotImplementedError('Image plotting not yet implemented')

    def _plot_perm_points(self, ax: plt.Axes, perm_points: pd.DataFrame):
        """
        _plot_perm_points function to plot permeability points on a given axes.
        Track retains the axes xlim values, therefore to plot, plot
        permeability measurements over the permability log.

        (Should be implemented to plot points on seperate track, this is
        currently sufficient for plotting measured values over the
        predicted permeability log).

        :param self:
        :param ax: matplotlib Axes to plot perm_points on.
        :type ax: plt.Axes
        :param perm_points: Permeability measurements as a pandas dataframe
        object. Expecting coloums ['DEPTH', 'PERM'].
        :type perm_points: pd.DataFrame
        """
        # plot points
        ax.scatter(
            np.asarray(perm_points['PERM']),
            np.asarray(perm_points['DEPTH']),
            color='k', label='Permeability (mD)'
            )

    def _calc_VShale(self):
        """
        Simple function to calculate VShale curve from GR
        using 5th percentile for clean sandstone and 95th
        percentile for shale.
        """
        clean = np.nanpercentile(self.las['GR'], 5)
        shale = np.nanpercentile(self.las['GR'], 95)

        VShale_curve = (
            (self.las['GR'] - clean) /
            (shale - clean)
        )

        return VShale_curve

    def plot(
            self,
            logs_to_plot: Iterable[str],
            perm_points: pd.DataFrame | None = None,
            depth_range: tuple[float, float] | None = None,
            zonations: list[dict] | None = None,
            title: str | None = None,
            fig_v_size: int | None = 45,
            plot_VShale: bool | None = False
    ):
        """
        Plot each track for each log in ``logs_to_plot``.

        Notes
        -----
        Currently, ``logs_to_plot=None`` does not plot all logs as intended.
        Specify the logs to plot. Include ``VShale`` if ``plot_VShale=True``.

        Example
        -------
        .. code-block:: python

            zones = [
                {'name': 'SS', 'top': 1900, 'base': 2000, 'color': '#f8d48d'},
                {'name': 'Sh', 'top': 1850, 'base': 1900, 'color': '#928a7a'}
            ]

            plot = WirelineLogPlot(
                las,
                track_dict={'GR': 3, 'VShale': 2, 'RDEP': 4, 'PERM': 4},
            )

            plot.plot(
                logs_to_plot=['GR', 'NPHI', 'RHOB', 'CALI', 'RDEP', 'VShale'],
                perm_points=perm_points,
                title='WELL 204-24a-6',
                depth_range=(2215, 2240),
                zonations=zones,
                plot_VShale=True,
            )

        :param logs_to_plot: List of log mnemonics to plot.
        :type logs_to_plot: Iterable[str]
        :param perm_points: Permeability values as a DataFrame with columns
            ``['DEPTH', 'PERM']``.
        :type perm_points: pd.DataFrame | None
        :param depth_range: Depth interval (top, base) to plot.
        :type depth_range: tuple[float, float] | None
        :param zonations: List of zonation dictionaries with keys ``name``, ``top``,
            ``base``, and ``color``.
        :type zonations: list[dict] | None
        :param title: Plot title.
        :type title: str | None
        :param fig_v_size: Vertical figure size.
        :type fig_v_size: int | None
        :param plot_VShale: If ``True``, calculate and plot VShale.
        :type plot_VShale: bool
        """
        # ChatGPT fixed formatting of docstring

        # optional to add VShale plot based on the GR
        if plot_VShale:
            mnemonic = 'VShale'
            self.tracklogs.append(
                TrackLog(
                    mnemonic=mnemonic,
                    track=self._track_dict.get(mnemonic, None),
                    units='v/v',
                    label=mnemonic,
                    xlim=self._xlim_dict.get(mnemonic, None),
                    log_scale=self._log_scale_dict.get(mnemonic, None),
                    invert_scale=self._invert_scale_dict.get(mnemonic, None),
                    color=self._color_dict.get(mnemonic, None),
                    linestyle=self._linestyle_dict.get(mnemonic, None)
                    )
            )

        # save depth range for text in zones
        self.depth_range = depth_range

        # optional, define logs to plot, otherwise plot all logs
        if logs_to_plot is None:
            self.logs_to_plot = self.las.curvesdict.keys()
        else:
            if not isinstance(logs_to_plot, Iterable):
                raise TypeError("logs_to_plot must be an iterable of strings")

            # define the available logs to query if any inputted are missing
            available = set(self.las.curvesdict.keys())
            available.add('VShale')
            missing = [log for log in logs_to_plot if log not in available]

            if missing:
                raise KeyError(f'{missing} logs are not found in las file')

            # assigns self.logs_to_plot if none missing
            self.logs_to_plot = logs_to_plot

        # determine the number of tracks for plotting
        if logs_to_plot is None:
            track_list = [tracklog.track for tracklog in self.tracklogs]
        else:
            track_list = [
                self._track_dict.get(log, None) for log in logs_to_plot
                ]

        # determine track num for the assigned int values and nans
        ints = [t for t in track_list if t is not None]
        n_nans = sum(t is None for t in track_list)
        n_tracks = max(ints) + n_nans

        # set ratios for fig formatting, 0.5 for zones track
        width_ratios = [0.5] + [1] * (n_tracks - 1)
        # define plot template based on size, number of tract
        fig, axes = plt.subplots(
            1, n_tracks, figsize=(3*n_tracks, fig_v_size),
            sharey=True,  # all axes share depth, causes issues with .twiny() 
            gridspec_kw={'width_ratios': width_ratios}
            )

        axes = np.asarray(axes).ravel()

        # first axes reserved for zonations - set as master y axis
        top = min(self.las['DEPTH'])
        base = max(self.las['DEPTH'])

        if depth_range:
            axes[0].set_ylim(depth_range)
        else:
            axes[0].set_ylim(base, top)

        # sort and have None values to the end and sorted int values at the
        # front, to plot after
        logs_to_plot = sorted(
            logs_to_plot,
            key=lambda log: (
                self._track_dict.get(log, None) is None,
                self._track_dict.get(log, float('inf'))
            )
        )

        # plot zones - implement in future for option to not plot zones cleanly
        # i.e. no empty track
        self._plot_zones(axes[0], zonations)
        axes[0].legend(
            loc='upper left',
            bbox_to_anchor=(0.0, 1.02),  # anchor above track
            frameon=False
            )

        # plot all logs on each track
        for ax_count, log in enumerate(logs_to_plot):

            # if not wanting to use zontations/facies - not implemented yet
            if True:
                ax_count = ax_count + 1  # shift as zonation given as axes[0]

            # query the tracklog plotting instructions
            tracklog = next(
                (tracklog for tracklog in self.tracklogs
                 if tracklog.mnemonic == log), None
                )

            # check, should not fail if working tracklog creation working
            if tracklog is None:
                raise ValueError(f'No TrackLog object assigned to {log}')

            # ax_count + 1 as what to reserve axes[0] for zonatations
            self._plot_track(axes[ax_count], tracklog)

            # check if track is assigned, else add new track
            # does not work as intended for plotting one log on another
            if tracklog.track is not None:
                # set default value to be [] to initialise
                self.track_plots.setdefault(
                    tracklog.track, []).append(ax_count)
                
                # check if already is an axes for that track
                if len(self.track_plots[tracklog.track]) > 1:
                    base_axis_num = self.track_plots[tracklog.track][0]
                    # issues with twinning and sharing track
                    axes[ax_count] = axes[base_axis_num].twiny()

            else:
                # add new key that is +1 the max key, i.e. new track if None
                add_track = (
                    (max(self.track_plots.keys()) + 1)
                    if self.track_plots else 1
                    )
                self.track_plots.setdefault(add_track, []).append(ax_count)

            # print(f'{tracklog.mnemonic}:{ax_count}')  # for debugging

        # plot permeability data
        if perm_points is not None:
            # determine which track to plot from
            track = self._track_dict['PERM']
            # determine which axes is already for that track
            ax_num = self.track_plots.get(track, None)
            if ax_num is not None:
                ax_num = self.track_plots[track][0]
            else:
                raise NotImplementedError('permeability not plotted')

            # debugging
            # print(self.track_plots)
            # print(ax_num)
            # print(axes[ax_num])

            # plot perm points on axes corresponding to given track
            self._plot_perm_points(perm_points=perm_points, ax=axes[ax_num])
            axes[ax_num].legend(
                loc='upper left',
                bbox_to_anchor=(0.0, 1.03),  # anchor above plot
                frameon=False
                )

        # format title
        if title:
            fig.suptitle(title, fontsize=20, y=0.98)
            fig.subplots_adjust(top=0.95)

    # fix plotting option to have more than one log on a track
    # add image tract - requires handling and ensuring aspect ratio issues