"""
Main entry point for the extras package.
Enables standalone execution: python -m extras <input_file>
"""

import sys
from .perm_preprocess import main as preprocess_main

if __name__ == "__main__":
    # Redirect execution to the main function defined in preprocess.py
    # This allows the teacher to run preprocessing as a module or a script.
    preprocess_main()