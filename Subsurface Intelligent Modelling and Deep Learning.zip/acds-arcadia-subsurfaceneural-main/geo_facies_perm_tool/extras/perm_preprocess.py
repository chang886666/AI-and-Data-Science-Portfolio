"""
Well Log Data Preprocessing & Petrophysical Feature Engineering Pipeline
------------------------------------------------------------------------
Purpose: 
This script implements a robust automated pipeline for cleaning and enhancing 
well log datasets. Key functionalities include:
1. Automated outlier handling and unit standardization.
2. Intelligent merging of multi-source acoustic logs (DTS/DTC).
3. Advanced feature engineering of key petrophysical indicators (Vshale, 
   Porosity differences, and Resistivity ratios).
4. Logarithmic transformation and IQR-based Winsorization to prepare data 
   for high-performance machine learning models like XGBoost.
5. Dynamic header reconstruction to maintain data integrity across wells 
   with varying available curves.
"""

import numpy as np
import pandas as pd
import argparse
import os
import sys
import lasio
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, FunctionTransformer
from sklearn.impute import SimpleImputer

# ==========================================
# 1. Custom Transformer Components
# ==========================================

class CleanValues(BaseEstimator, TransformerMixin):
    """Handle anomalies by converting null-proxy values (e.g., -999) to NaN"""
    def __init__(self, value=-999): self.value = value
    def fit(self, X, y=None): return self
    def transform(self, X):
        X = pd.DataFrame(X).copy()
        for col in X.columns:
            if X[col].dtype == 'object':
                # Clean string data: handle commas, less-than signs, and convert to numeric
                X[col] = pd.to_numeric(X[col].astype(str).str.replace(',', '.').str.replace('<', ''), errors='coerce')
        X.replace(self.value, np.nan, inplace=True)
        return X

class DTSSmartMerge(BaseEstimator, TransformerMixin):
    """Merge DTS curves: prioritizes primary DTS, fills gaps with average of DTS1/DTS2"""
    def fit(self, X, y=None): return self
    def transform(self, X):
        X = pd.DataFrame(X).copy()
        primary_dts = X.iloc[:, 0]
        # Expected input order: [DTS, DTS1, DTS2, DTC]
        secondary_avg = X.iloc[:, 1:3].mean(axis=1) if X.shape[1] > 2 else np.nan
        X['DTS_Final'] = primary_dts.fillna(secondary_avg)
        return X

class PetrophysicalFeatureEngineer(BaseEstimator, TransformerMixin):
    """
    Petrophysical Feature Engineering:
    Generates VSHALE, RES_RATIO, DTS_DTC_RATIO, AT_ratio, PEF_DENS_Ratio, Neut_Dens_Diff
    """
    def __init__(self, gr_col='GR', rdep_col='RDEP', rshal_col='RSHAL', 
                 dtc_col='DTC', dts_col='DTS_Final', at60_col='AT60', 
                 at20_col='AT20', pef_col='PEF', dens_col='DENS', neut_col='NEUT'):
        self.gr_col, self.rdep_col, self.rshal_col = gr_col, rdep_col, rshal_col
        self.dtc_col, self.dts_col = dtc_col, dts_col
        self.at60_col, self.at20_col = at60_col, at20_col
        self.pef_col, self.dens_col, self.neut_col = pef_col, dens_col, neut_col

    def fit(self, X, y=None):
        X_df = pd.DataFrame(X)
        if self.gr_col in X_df.columns:
            # Calculate clean sand and shale baselines for Vshale
            self.gr_clean_ = np.nanpercentile(X_df[self.gr_col], 5)
            self.gr_shale_ = np.nanpercentile(X_df[self.gr_col], 95)
        return self

    def transform(self, X):
        X = pd.DataFrame(X).copy()
        eps = 1e-6
        # 1. VSHALE calculation
        if self.gr_col in X.columns:
            vsh = (X[self.gr_col] - self.gr_clean_) / (self.gr_shale_ - self.gr_clean_ + eps)
            X['VSHALE'] = np.clip(vsh, 0, 1)
        # 2. RES_RATIO (Deep vs Shallow resistivity)
        if self.rdep_col in X.columns and self.rshal_col in X.columns:
            X['RES_RATIO'] = X[self.rdep_col] / (X[self.rshal_col] + eps)
        # 3. DTS_DTC_RATIO (Acoustic ratio for lithology/geomechanics)
        if self.dts_col in X.columns and self.dtc_col in X.columns:
            X['DTS_DTC_RATIO'] = X[self.dts_col] / (X[self.dtc_col] + eps)
        # 4. AT_ratio (Logarithmic resistivity invasion ratio)
        if self.at60_col in X.columns and self.at20_col in X.columns:
            X['AT_ratio'] = np.log10(np.abs(X[self.at60_col]) / (np.abs(X[self.at20_col]) + eps) + eps)
        # 5. PEF_DENS_Ratio
        if self.pef_col in X.columns and self.dens_col in X.columns:
            X['PEF_DENS_Ratio'] = X[self.pef_col] / (X[self.dens_col] + eps)
        # 6. Neut_Dens_Diff (Identify gas effects or lithology cross-over)
        if self.neut_col in X.columns and self.dens_col in X.columns:
            X['Neut_Dens_Diff'] = X[self.neut_col] - (2.71 - X[self.dens_col]) / (2.71 - 1.0)
        return X

class IQRWinsorise(BaseEstimator, TransformerMixin):
    """IQR Winsorization to cap extreme outliers"""
    def __init__(self, multiplier=2.0):
        self.multiplier = multiplier
        self.bounds_ = {}
    def fit(self, X, y=None):
        X_df = pd.DataFrame(X)
        for col in X_df.columns:
            if np.issubdtype(X_df[col].dtype, np.number):
                q1, q3 = X_df[col].quantile(0.25), X_df[col].quantile(0.75)
                iqr = q3 - q1
                self.bounds_[col] = (q1 - self.multiplier * iqr, q3 + self.multiplier * iqr)
        return self
    def transform(self, X):
        X = pd.DataFrame(X).copy()
        for col, (low, upp) in self.bounds_.items():
            if col in X.columns: X[col] = X[col].clip(lower=low, upper=upp)
        return X

# ==========================================
# 2. Pipeline Core Construction
# ==========================================

def get_preprocessor(existing_cols):
    """Builds dynamic ColumnTransformer based on available columns in the dataset"""
    def v(expected): return [c for c in expected if c in existing_cols]

    # Columns to be excluded from features
    to_drop = v(['LATI', 'LONG', 'RWS', 'WST', 'PROV', 'SRVC', 'Match_Key', 'Unnamed: 0'])
    
    # Feature groups
    fe_res_cols = v(['GR', 'RDEP', 'RSHAL'])
    fe_acoustic_cols = v(['DTS', 'DTS1', 'DTS2', 'DTC'])
    fe_at_cols = v(['AT20', 'AT60'])
    fe_porosity_cols = v(['NEUT', 'DENS', 'PEF'])
    log_cols = v(['RMIC', 'RT', 'AT20', 'AT60', 'PERMEABILITY (HORIZONTAL) Kair md', 'PERM'])
    cat_cols = v(['Facies_Class_Name'])

    # Sub-pipelines
    p_res = Pipeline([('cl', CleanValues()), ('fe', PetrophysicalFeatureEngineer(gr_col='GR', rdep_col='RDEP', rshal_col='RSHAL')), ('ws', IQRWinsorise())])
    p_ac = Pipeline([('cl', CleanValues()), ('mg', DTSSmartMerge()), ('fe', PetrophysicalFeatureEngineer(gr_col=None, dtc_col='DTC', dts_col='DTS_Final')), ('ws', IQRWinsorise())])
    p_at = Pipeline([('cl', CleanValues()), ('fe', PetrophysicalFeatureEngineer(gr_col=None, at60_col='AT60', at20_col='AT20')), ('ws', IQRWinsorise())])
    p_por = Pipeline([('cl', CleanValues()), ('fe', PetrophysicalFeatureEngineer(gr_col=None, pef_col='PEF', dens_col='DENS', neut_col='NEUT')), ('ws', IQRWinsorise())])
    p_log = Pipeline([('cl', CleanValues()), ('ws', IQRWinsorise()), ('lg', FunctionTransformer(lambda x: np.log10(np.abs(x) + 1e-6), validate=False))])
    # OneHotEncoder compatibility
    try:
        ohe = OneHotEncoder(sparse_output=False, handle_unknown="ignore")
    except TypeError:
        ohe = OneHotEncoder(sparse=False, handle_unknown="ignore")

    p_cat = Pipeline([
    ("im", SimpleImputer(strategy="most_frequent")),
    ("en", ohe),
     ])


    return ColumnTransformer([
        ('drop', 'drop', to_drop),
        ('res', p_res, fe_res_cols),
        ('acoustic', p_ac, fe_acoustic_cols),
        ('at', p_at, fe_at_cols),
        ('porosity', p_por, fe_porosity_cols),
        ('log', p_log, log_cols),
        ('cat', p_cat, cat_cols)
    ], remainder='passthrough')

# ==========================================
# 3. Main Execution Logic
# ==========================================

def load_data(file_path):
    """Loads data from CSV or LAS file formats"""
    ext = os.path.splitext(file_path)[1].lower()
    if ext == '.las': return lasio.read(file_path).df().reset_index()
    return pd.read_csv(file_path)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('input', type=str)
    parser.add_argument('--output', type=str, default='FINAL_PREPROCESSED.csv')
    args = parser.parse_args()

    # Load and standardize column names
    df = load_data(args.input)
    df.columns = df.columns.str.strip()
    df.rename(columns={'DTS_1':'DTS1', 'DTS_2':'DTS2', 'dts':'DTS', 'RHOB':'DENS', 'NPHI':'NEUT'}, inplace=True)
    
    orig_cols = df.columns.tolist()
    preprocessor = get_preprocessor(orig_cols)
    print(f"Status: Processing {len(orig_cols)} columns...")
    data_out = preprocessor.fit_transform(df)

    # --- Dynamic Header Reconstruction ---
    # Rebuild headers based on the exact order of ColumnTransformer outputs
    def get_h(expected): return [c for c in expected if c in orig_cols]
    
    h_res = get_h(['GR', 'RDEP', 'RSHAL'])
    res_names = h_res + (['VSHALE', 'RES_RATIO'] if len(h_res) >= 2 else [])
    
    h_ac = get_h(['DTS', 'DTS1', 'DTS2', 'DTC'])
    ac_names = h_ac + (['DTS_Final', 'DTS_DTC_RATIO'] if 'DTC' in h_ac else [])
    
    h_at = get_h(['AT20', 'AT60'])
    at_names = h_at + (['AT_ratio'] if len(h_at) == 2 else [])
    
    h_por = get_h(['NEUT', 'DENS', 'PEF'])
    por_names = h_por[:]
    if 'PEF' in h_por and 'DENS' in h_por: por_names.append('PEF_DENS_Ratio')
    if 'NEUT' in h_por and 'DENS' in h_por: por_names.append('Neut_Dens_Diff')

    h_log = [f"log10_{c}" for c in get_h(['RMIC', 'RT', 'AT20', 'AT60', 'PERMEABILITY (HORIZONTAL) Kair md', 'PERM'])]
    
    h_cat = []
    if 'Facies_Class_Name' in orig_cols:
        h_cat = list(preprocessor.named_transformers_['cat'].named_steps['en'].get_feature_names_out(['Facies_Class_Name']))
    
    # Identify remainder columns not caught by specific sub-pipelines
    dropped = get_h(['LATI', 'LONG', 'RWS', 'WST', 'PROV', 'SRVC', 'Match_Key', 'Unnamed: 0'])
    handled = h_res + h_ac + h_at + h_por + get_h(['RMIC', 'RT', 'AT20', 'AT60', 'PERMEABILITY (HORIZONTAL) Kair md', 'PERM', 'Facies_Class_Name']) + dropped
    rem_names = [c for c in orig_cols if c not in handled]

    # Combine all header groups
    final_headers = res_names + ac_names + at_names + por_names + h_log + h_cat + rem_names

    # Final validation and saving
    result_df = pd.DataFrame(data_out, columns=final_headers)
    result_df.to_csv(args.output, index=False)
    print(f"Success! Generated {len(final_headers)} columns, saved to {args.output}")