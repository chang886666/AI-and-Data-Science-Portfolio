# Subsurface Data Preprocessing Pipeline

This repository contains a suite of tools designed to process raw geological data into a standardized training format. The workflow follows a rigorous path: converting core images into digital depth arrays, synchronizing multiple data sources to a common reference depth, and merging them into a cleaned master dataset.

---

## Preprocessing Workflow



### 1. Core Image Segmentation and Assembly
* **Script:** `process_directory.py`
* **Action:** Iterates through directories of raw borehole photographs to identify and segment individual core columns using **Mask R-CNN**.
* **Logic:** The script detects up to 2 columns per image and handles significant depth gaps to ensure the continuity of the assembly.
* **Result:** Individual core runs are "stitched" together to form a continuous vertical image of the well, alongside an initial depth array (`..._depths.npy`).

<img src="core_preview.png" width="100">

---

### 2. Universal Depth Correction
* **Script:** `depth_correction.py`
* **Action:** Applies vertical shifts (add/subtract) to align data with the official borehole reference depth (Wireline Log depth).
* **New Feature:** Supports both **.npy** (binary arrays) and **.csv** (point/interval data) files. It automatically identifies columns like `DEPTH`, `START DEPTH`, or `END DEPTH`.
* **Usage:**
    ```bash
    python depth_correction.py <INPUT_FILE> --shifts <START> <END> <VALUE>
    ```
    *Example:* `python depth_correction.py permeability.csv --shifts 2100 2150 2.5`

---

### 3. Single-Well Data Integration
* **Script:** `well_merge_tools.py`
* **Action:** Performs a depth-based "join" operation at the single-well level.
* **Integration:** Combines the **LAS wireline logs**, the corrected **Permeability data**, and the corrected **Facies descriptions** into one unified tabular file per well.
* **Output:** Files are typically named `new_<Well_ID>_combined.csv`.
* **Usage:**
    ```bash
    a)
    python well_merge_tools.py --las "path/to/logs.las" --perm "path/to/perm_corrected.csv" --out "new_well_combined.csv"
    ```
    ```bash
    b)
    python well_merge_tools.py --las "path/to/logs.las" --facies "path/to/facies_corrected.csv" --out "new_well_combined.csv"
    ```
    ```bash
    c)
    python well_merge_tools.py --las "path/to/logs.las" --perm "perm.csv" --facies "facies.csv" --out "new_well_combined.csv"
     ```



---

### 4. Master Dataset Aggregation
* **Script:** `combine_wells.py` 
* **Action:** Automatically scans a specified directory and vertically concatenates all matching well CSVs into a single master dataset.
* **Logic:** Dynamically extracts Well IDs from filenames and adds them as a new feature column.
* **Usage:**
    ```bash
    python combine_wells.py <INPUT_FOLDER_PATH> --output master_training_data.csv
    ```
<img src="creat_raw_perm_training_data.png" width="700">
<img src="creat_raw_facies_training_data.png" width="700">
---

### 5. Data Cleaning and Standardization
* **Script:** `clean_training_data.py` 
* **Action:** Finalizes the dataset by normalizing columns and handling non-numeric artifacts for machine learning compatibility.
* **Key Operations:**
    * **Column Harmonization:** Merges variant names like `DTS_1` into standard `DTS1`.
    * **Numeric Sanitization:** Handles European-style commas (`,`), removes `<` symbols, and converts strings to floats.
    * **Null Handling:** Replaces industry-specific null markers (e.g., **-999**) with standard `NaN`.
* **Usage:**
    ```bash
    python clean_training_data.py master_training_data.csv -o FINAL_CLEANED_DATA.csv
    ```

---

## Project Structure Summary

| File Type | Description |
| :--- | :--- |
| **.py** | Standalone Python CLI scripts for batch processing and automation. |
| **.npy** | High-resolution binary depth arrays representing the vertical position of core pixels. |
| **.las** | Industry-standard wireline log data used as the "Golden" depth reference. |
| **.csv** | Tabular files used for labels (permeability, facies) and final training matrices. |

---

## Quick Start Example

To process a new batch of well data:
1.  **Segment Images:** Run `process_directory.py` to get initial depths.
2.  **Align Depth:** Use `depth_correction.py` to match core depths to LAS depths.
3.  **Merge Well:** Use `well_merge_tools.py` to create a single-well combined CSV.
4.  **Aggregate All:** `python combine_wells.py ./input_dir/` to create a master file.
5.  **Clean Final:** `python clean_training_data.py master_file.csv` to prepare for ML training.