"""
Master Training Data Aggregator
==============================
This script automates the merging of multiple CSV training data files.
It extracts Well IDs from filenames and creates a consolidated master dataset.

Usage:
    python combine_wells.py <INPUT_DIRECTORY> --output <OUTPUT_NAME>

Example:
    python combine_wells.py /home/mt125/acds-arcadia-subsurfaceneural/new_train_data
"""

import pandas as pd
import glob
import os
import argparse
import sys

def combine_csv_files(input_folder, output_filename):
    """
    Finds, processes, and merges all 'new_*_combined.csv' files in the target directory.
    """
    # 1. Validation of input directory
    if not os.path.isdir(input_folder):
        print(f"Error: The directory '{input_folder}' does not exist.")
        return

    # 2. Define search pattern
    file_pattern = os.path.join(input_folder, "new_*_combined.csv")
    all_files = glob.glob(file_pattern)

    print(f"Searching path: {input_folder}")
    print(f"Number of files found: {len(all_files)}")

    if len(all_files) == 0:
        print("Error: No matching files found! Filenames must follow 'new_*_combined.csv'.")
        # List files to help the user debug
        print("Actual files found in directory:", os.listdir(input_folder)[:5])
        return

    df_list = []
    
    # 3. Process each file
    for file in all_files:
        try:
            # A. Load and clean column names
            temp_df = pd.read_csv(file)
            temp_df = temp_df.loc[:, ~temp_df.columns.str.contains('^Unnamed')]
            
            # B. Extract Well_ID from filename
            # e.g., 'new_204_19_3a_combined.csv' -> '204_19_3a'
            base_name = os.path.basename(file)
            well_id = base_name.replace('new_', '').replace('_combined.csv', '')
            
            # C. Add metadata
            temp_df['Well_ID'] = well_id
            df_list.append(temp_df)
            print(f"Successfully loaded: {well_id}")
            
        except Exception as e:
            print(f"Warning: Failed to process {file}. Reason: {e}")

    # 4. Concatenation and Data Cleaning
    print("\nMerging data...")
    combined_df = pd.concat(df_list, axis=0, ignore_index=True, sort=False)
    
    # Ensure DEPTH is numeric for proper sorting
    if 'DEPTH' in combined_df.columns:
        combined_df['DEPTH'] = pd.to_numeric(combined_df['DEPTH'], errors='coerce')
        combined_df = combined_df.sort_values(by=['Well_ID', 'DEPTH'])
    else:
        print("Warning: 'DEPTH' column not found. Sorting by 'Well_ID' only.")
        combined_df = combined_df.sort_values(by=['Well_ID'])
    
    # 5. Export
    combined_df.to_csv(output_filename, index=False)
    
    print("-" * 50)
    print(f"Task completed successfully!")
    print(f"Total row count: {len(combined_df)}")
    print(f"Total wells merged: {len(combined_df['Well_ID'].unique())}")
    print(f"Saved to: {os.path.abspath(output_filename)}\n")

def main():
    parser = argparse.ArgumentParser(description="Merge well CSV files into a master dataset.")
    
    # Positional argument: Input directory
    parser.add_argument('input', type=str, help="Path to the directory containing new_*_combined.csv files")
    
    # Optional argument: Output filename
    parser.add_argument('-o', '--output', type=str, default="master_training_data_final.csv",
                        help="Name of the output CSV file (default: master_training_data_final.csv)")

    args = parser.parse_args()

    combine_csv_files(args.input, args.output)

if __name__ == "__main__":
    main()