"""
CoreColumn Assembly Tool (Batch Processing)
===========================================
This script automates the transformation of raw geological core photographs 
into integrated 'CoreColumn' objects. 

Key Features:
- Multi-column detection: Configured for images containing 1 or 2 core rows.
- Gap Tolerance: Uses high tolerance (default 1000m) to allow concatenation 
  despite significant depth gaps between physical core runs.
- Data Merging: Merges multiple CSV entries associated with the same image.
- Flexible Output: Supports saving as serialized Pickles or raw NumPy arrays.
"""

import os
import argparse
from glob import glob
import numpy as np
import pandas as pd
from collections import OrderedDict
from functools import reduce
from operator import add

from corebreakout import defaults
from corebreakout import CoreSegmenter, CoreColumn

# --- Global Model Configuration ---
model_config = defaults.DefaultConfig()
class_names = defaults.CLASSES

# Update layout parameters to allow the model to detect up to 2 columns per image
layout_params = defaults.LAYOUT_PARAMS.copy() 
layout_params['num_columns'] = [1, 2] 

def get_args():
    """
    Defines and parses command-line arguments for the segmentation tool.
    
    Returns:
        argparse.Namespace: Parsed command-line arguments.
    """
    parser = argparse.ArgumentParser(
        description='Convert image directories with Mask R-CNN into CoreColumns.'
    )
    # Required path argument
    parser.add_argument('path', type=str, 
                        help="Path to directory containing images and depth.csv")
    
    # Model configuration arguments
    parser.add_argument('--model_dir', type=str, default=defaults.MODEL_DIR,
                        help="Directory containing the Mask R-CNN model files")
    parser.add_argument('--weights_path', type=str, default=defaults.CB_MODEL_PATH,
                        help="Path to the pre-trained weights (.h5 file)")
    
    # Concatenation logic arguments
    parser.add_argument('--add_tol', type=float, default=1000.0, 
                        help="Gap tolerance in meters. High values allow merging across large gaps.")
    parser.add_argument('--add_mode', default='collapse', type=str, choices=['fill', 'collapse'],
                        help="Mode for handling gaps: 'fill' adds blank space, 'collapse' ignores gaps.")
    
    # Output and naming arguments
    parser.add_argument('--depth_csv', type=str, default='depth.csv',
                        help="Name of the CSV file containing depth metadata")
    parser.add_argument('--save_dir', type=str, default=None,
                        help="Directory to save the resulting CoreColumn")
    parser.add_argument('--save_name', default=None,
                        help="Base name for the output files")
    parser.add_argument('--save_mode', type=str, default='pickle', choices=['pickle', 'numpy', 'both'],
                        help="Storage format for the results")
    return parser.parse_args()

def main():
    """
    Executes the batch processing workflow: 
    1. Loads metadata 2. Initializes model 3. Segments images 4. Assembles column.
    """
    args = get_args()

    print("\n" + "="*45)
    print(f"Batch Core Segmentation Started (tol={args.add_tol}m)")
    print("="*45)

    # Validate input directory
    if not os.path.exists(args.path):
        print(f"Error: Path does not exist -> {args.path}")
        return

    # Gather image paths (case-insensitive JPEG matching)
    img_paths = sorted(glob(os.path.join(args.path, '*.[jJ][pP]*[gG]')))
    if len(img_paths) == 0:
        print("Error: No JPEG images found in the specified directory.")
        return
    
    # Create mapping of filename (no extension) to full path
    folder_mapping = {os.path.splitext(os.path.basename(p))[0]: p for p in img_paths}

    # Locate and process the depth metadata CSV
    csv_path = os.path.join(args.path, args.depth_csv)
    if not os.path.exists(csv_path):
        print(f"Error: Metadata CSV not found at -> {csv_path}")
        return
    
    try:
        # Read CSV and ensure indices are treated as strings
        depths_df = pd.read_csv(csv_path, index_col=0)
        depths_df.index = depths_df.index.map(str)
        
        # Merge depth intervals for images that appear in multiple CSV rows
        merged_depths = OrderedDict()
        for idx, row in depths_df.iterrows():
            idx_clean = str(idx).strip()
            if idx_clean in folder_mapping:
                f_path = folder_mapping[idx_clean]
                t, b = float(row['top']), float(row['bottom'])
                
                if f_path not in merged_depths:
                    merged_depths[f_path] = {'top': t, 'bottom': b}
                else:
                    # Update boundaries to cover the full range of the image
                    merged_depths[f_path]['top'] = min(merged_depths[f_path]['top'], t)
                    merged_depths[f_path]['bottom'] = max(merged_depths[f_path]['bottom'], b)
        
        # Sort files by depth to ensure sequential concatenation
        final_items = sorted([(f, d['top'], d['bottom']) for f, d in merged_depths.items()], 
                            key=lambda x: x[1])
        print(f"Metadata Loaded. Merged into {len(final_items)} unique core images.")

    except Exception as e:
        print(f"Error processing metadata CSV: {e}")
        return

    # Load the Mask R-CNN segmentation model
    print("\nInitializing Mask R-CNN model...")
    try:
        segmenter = CoreSegmenter(
            args.model_dir, args.weights_path,
            model_config=model_config,
            class_names=class_names,
            layout_params=layout_params
        )
    except Exception as e:
        print(f"Failed to load model: {e}")
        return

    # Process each image and generate CoreColumn segments
    print(f"Running segmentation (2-column mode enabled)...")
    cols = []
    for i, (f, t, b) in enumerate(final_items):
        file_name = os.path.basename(f)
        print(f"[{i+1}/{len(final_items)}] Processing {file_name} ({t}m - {b}m)...")
        try:
            # Perform instance segmentation and depth mapping
            col = segmenter.segment(f, [t, b], add_tol=args.add_tol, add_mode=args.add_mode)
            cols.append(col)
        except Exception as e:
            print(f"Error segmenting {file_name}: {e}")

    # Check if any segments were successfully generated
    if not cols:
        print("No valid core segments generated. Assembly aborted.")
        return

    # Assemble individual image segments into a single CoreColumn object
    print("\nConcatenating segments into full column...")
    try:
        full_column = reduce(add, cols)
        print(f"Column Assembled! Total depth range: {full_column.depth_range}m")
    except Exception as e:
        print(f"Concatenation failed: {e}")
        return

    # Determine save directory and output naming
    save_dir = args.save_dir or args.path
    out_name = args.save_name or f"CoreColumn_{full_column.top}_{full_column.base}"
    
    print(f"Saving results to: {save_dir}")
    
    # Save output according to the chosen mode
    if args.save_mode == 'pickle':
        full_column.save(save_dir, name=out_name, pickle=True)
    elif args.save_mode == 'numpy':
        full_column.save(save_dir, name=out_name, pickle=False, image=True, depths=True)
    else:
        # Default behavior: save serialized data and visualization
        full_column.save(save_dir, name=out_name, image=True, depths=True)

    print("\nBatch process finished.\n")

if __name__ == '__main__':
    main()