"""
Well Log and Lab Data Integration Tool
======================================
This script automates the merging of subsurface data from three different sources:
1. LAS Files: Continuous wireline log data.
2. Sample CSVs: Discrete lab measurements (e.g., Permeability, Porosity).
3. Facies CSVs: Interval-based geological descriptions (Start/End depth ranges).

Usage:
------
python well_merge_tools.py --las "well.las" --perm "p1.csv" "p2.csv" --facies "f.csv"
"""

import pandas as pd
import lasio
import missingno as msno
import matplotlib.pyplot as plt
import argparse
import os

def clean_numeric_column(df, column_name):
    """Handles European decimal commas and converts column to float."""
    if column_name in df.columns:
        if df[column_name].dtype == object:
            df[column_name] = df[column_name].str.replace(',', '.')
        df[column_name] = pd.to_numeric(df[column_name], errors='coerce')
    return df

def merge_well_data(las_path, perm_csv_list, facies_csv_path, output_name):
    well_title = os.path.splitext(os.path.basename(las_path))[0]
    print(f"--- Processing Well: {well_title} ---")
    
    # 1. Load LAS File
    try:
        las = lasio.read(las_path)
        df_final = las.df().reset_index()
        
        # Remove any existing unnamed index columns from the LAS dataframe
        df_final = df_final.loc[:, ~df_final.columns.str.contains('^Unnamed')]
        df_final = df_final.sort_values('DEPTH')
        
        print(f"LAS loaded. Range: {df_final['DEPTH'].min():.2f} - {df_final['DEPTH'].max():.2f}")
    except Exception as e:
        print(f"Failed to read LAS: {e}")
        return

    # 2. Merge Discrete Sample Data (e.g., Permeability, Porosity)
    if perm_csv_list:
        for file in perm_csv_list:
            if os.path.exists(file):
                df_new = pd.read_csv(file)
                
                # Drop unnamed columns to prevent index carry-over
                df_new = df_new.loc[:, ~df_new.columns.str.contains('^Unnamed')]
                
                # Standardize column names and clean depth values
                df_new.columns = df_new.columns.str.replace(r'\n', ' ', regex=True).str.strip()
                df_new = clean_numeric_column(df_new, 'DEPTH')
                df_new = df_new.dropna(subset=['DEPTH'])
                df_new = df_new.sort_values('DEPTH')
                
                # Perform nearest-neighbor merge within a 0.05m tolerance
                new_cols = [col for col in df_new.columns if col == 'DEPTH' or col not in df_final.columns]
                df_final = pd.merge_asof(df_final, df_new[new_cols], on='DEPTH', direction='nearest', tolerance=0.05)
                print(f"Merged sample data: {os.path.basename(file)}")

    # 3. Merge Interval Facies Data
    if facies_csv_path and os.path.exists(facies_csv_path):
        df_facies = pd.read_csv(facies_csv_path)
        
        # Drop unnamed columns from facies file
        df_facies = df_facies.loc[:, ~df_facies.columns.str.contains('^Unnamed')]
        
        # Clean interval depth columns
        df_facies.columns = df_facies.columns.str.strip()
        df_facies = clean_numeric_column(df_facies, 'Start Depth')
        df_facies = clean_numeric_column(df_facies, 'End Depth')
        df_facies = df_facies.dropna(subset=['Start Depth', 'End Depth']).sort_values('Start Depth')

        # Use backward merge to find the corresponding facies interval
        df_final = pd.merge_asof(df_final, df_facies[['Start Depth', 'End Depth', 'Facies Class Name']], 
                                left_on='DEPTH', right_on='Start Depth', direction='backward')

        # Validate if current depth falls within the defined [Start, End] range
        mask = (df_final['DEPTH'] >= df_final['Start Depth']) & (df_final['DEPTH'] <= df_final['End Depth'])
        df_final.loc[~mask, 'Facies Class Name'] = None
        
        # Drop temporary interval boundary columns
        df_final = df_final.drop(columns=['Start Depth', 'End Depth'])
        print(f"Merged facies data.")

    # 4. Visualization of Data Completeness
    all_cols = df_final.columns.tolist()
    plt.figure(figsize=(12, 8))
    ax = msno.matrix(df_final[all_cols])
    ax.set_title(f"Data Completeness: {well_title}", fontsize=20, pad=35)
    plt.subplots_adjust(top=0.85)
    
    img_name = f"{well_title}_matrix.png"
    plt.savefig(img_name, bbox_inches='tight')
    print(f"Distribution plot saved as: {img_name}")
    
    # Optional: Display plot if running in an interactive environment
    # plt.show() 

    # 5. Export Result
    # index=False prevents creation of new unnamed index columns in the output
    df_final.to_csv(output_name, index=False)
    print(f"Final cleaned data saved to: {output_name}")
    

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Automated Well Log Merger")
    parser.add_argument("--las", required=True, help="Path to the input LAS file")
    parser.add_argument("--perm", nargs='+', help="Path to one or more sample CSV files")
    parser.add_argument("--facies", help="Path to the facies interval CSV file")
    parser.add_argument("--out", default="merged_result.csv", help="Name of the output CSV file")
    
    args = parser.parse_args()
    merge_well_data(args.las, args.perm if args.perm else [], args.facies, args.out)