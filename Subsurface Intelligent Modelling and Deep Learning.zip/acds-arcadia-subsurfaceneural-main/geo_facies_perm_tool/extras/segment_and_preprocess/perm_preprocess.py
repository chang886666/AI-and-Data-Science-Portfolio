"""
Permeability Prediction Preprocessing Module
--------------------------------------------
This module provides classes and functions for petrophysical feature engineering 
and data cleaning, specifically designed for subsurface permeability 
prediction using well-log data.

Key Components:
- PetrophysicalFeatureEngineer: Calculates derived physical properties (Vshale, ratios, logs).
- IQRWinsorise: Robust outlier handling using the Interquartile Range method.
- get_preprocessor: Pipeline factory to orchestrate the transformation flow.
"""

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin

class PetrophysicalFeatureEngineer(BaseEstimator, TransformerMixin):
    """
    Transformer to compute petrophysical features from raw wireline logs.
    
    Attributes:
        gr_clean (float): Gamma Ray value for clean sand.
        gr_shale (float): Gamma Ray value for pure shale.
    """
    def __init__(self, gr_clean=20.0, gr_shale=120.0):
        self.gr_clean = gr_clean
        self.gr_shale = gr_shale

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        """
        Applies physical formulas to generate new features.
        
        Args:
            X (pd.DataFrame): Raw log data including GR, RDEP, DTC, etc.
            
        Returns:
            pd.DataFrame: Augmented dataset with derived features.
        """
        X = pd.DataFrame(X).copy()
        eps = 1e-6
        
        # 1. VSHALE - Steiber Non-linear Correction
        # Better for Miocene/Pliocene or younger rocks compared to linear IGR
        if 'GR' in X.columns:
            igr = (X['GR'] - self.gr_clean) / (self.gr_shale - self.gr_clean)
            igr = np.clip(igr, eps, 1.0)
            X['VSHALE'] = igr / (3.0 - 2.0 * igr)
            
        # 2. RES_RATIO - Resistivity Contrast
        if 'RDEP' in X.columns and 'RSHAL' in X.columns:
            X['RES_RATIO'] = X['RDEP'] / (X['RSHAL'] + eps)
            
        # 3. Sonic Velocity Ratios and Combinations
        if 'DTS' in X.columns and 'DTC' in X.columns:
            X['DTS_DTC_RATIO'] = X['DTS'] / (X['DTC'] + eps)
            X['DTS_Final'] = X['DTS']
            # Mobility proxy: Difference between shear and compressional slowness
            X['DT_DIFF'] = X['DTS'] - X['DTC']
            
        # 4. Array Resistivity Ratios (Invasion Proxy)
        if 'AT60' in X.columns and 'AT20' in X.columns:
            X['AT_ratio'] = np.log10(np.abs(X['AT60'] / (X['AT20'] + eps)) + eps)
            
        # 5. PEF/DENS Ratio - Mineralogy Indicator
        if 'PEF' in X.columns and 'DENS' in X.columns:
            X['PEF_DENS_Ratio'] = X['PEF'] / (X['DENS'] + eps)
            
        # 6. Neutron-Density Separation - Key porosity and lithology indicator
        if 'NEUT' in X.columns and 'DENS' in X.columns:
            X['Neut_Dens_Diff'] = X['NEUT'] - (2.71 - X['DENS'])
            
        # 7. Logarithmic Feature Augmentation
        # Permeability usually scales logarithmically with resistivity
        log_map = {
            'RMIC': 'log10_RMIC', 
            'RDEP': 'log10_RDEP', 
            'RT': 'log10_RT', 
            'AT20': 'log10_AT20', 
            'AT60': 'log10_AT60'
        }
        for orig, log_name in log_map.items():
            if orig in X.columns:
                X[log_name] = np.log10(X[orig].replace(0, eps).abs())
                
        return X

class IQRWinsorise(BaseEstimator, TransformerMixin):
    """
    Caps extreme values using the Interquartile Range (IQR) method.
    Prevents spikes/noise in logs from skewing the XGBoost model.
    """
    def __init__(self, multiplier=2.5):
        self.multiplier = multiplier
        self.bounds_ = {}

    def fit(self, X, y=None):
        """
        Calculates capping thresholds for each numeric column.
        """
        X_df = pd.DataFrame(X)
        for col in X_df.columns:
            if np.issubdtype(X_df[col].dtype, np.number):
                Q1 = X_df[col].quantile(0.25)
                Q3 = X_df[col].quantile(0.75)
                IQR = Q3 - Q1
                self.bounds_[col] = (Q1 - self.multiplier * IQR, Q3 + self.multiplier * IQR)
        return self

    def transform(self, X):
        """
        Clips data within the calculated IQR bounds.
        """
        X = pd.DataFrame(X).copy()
        for col, (low, high) in self.bounds_.items():
            if col in X.columns:
                X[col] = np.clip(X[col], low, high)
        return X

def get_preprocessor():
    """
    Factory function to initialize the full preprocessing pipeline.
    
    Returns:
        sklearn.pipeline.Pipeline: A sequential data processing object.
    """
    from sklearn.pipeline import Pipeline
    return Pipeline([
        ('engineer', PetrophysicalFeatureEngineer()),
        ('winsor', IQRWinsorise())
    ])