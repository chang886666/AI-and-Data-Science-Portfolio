"""
Universal Depth Correction Script
=================================
This script applies vertical shifts to depth data in .npy or .csv formats.

Supported Input Types:
1. .npy files: Processes a raw numerical array of depths.
2. .csv files (Interval Type): Automatically shifts 'Start Depth' and 'End Depth' columns.
3. .csv files (Point Type): Automatically shifts the 'DEPTH' column while preserving associated 
   data (e.g., Porosity, Permeability).

Usage:
    python depth_correction.py <INPUT_FILE> --shifts <START> <END> <VALUE> ...

Arguments:
    INPUT_FILE : Path to the .npy or .csv file.
    --shifts   : Triplets of (Start Depth, End Depth, Shift Value).
                 - Positive value (e.g., 2.0) ADDS depth.
                 - Negative value (e.g., -1.5) SUBTRACTS depth.

Example:
    python depth_correction.py data/well_core.csv --shifts 2100 2150 2.5 2150 2200 -1.2 --output final_result.csv
"""

import os
import argparse
import numpy as np
import pandas as pd

def apply_shifts(file_path, rules, output_path):
    """
    Applies vertical depth shifts to seismic or core data files (.npy or .csv).
    
    The function identifies depth-related columns in CSV files or processes 
    raw numerical arrays in NPY files, applying specified shift values 
    within defined depth intervals.
    """
    if not os.path.exists(file_path):
        print(f"Error: File not found -> {file_path}")
        return

    ext = os.path.splitext(file_path)[1].lower()
    
    try:
        if ext == '.npy':
            # Load binary numpy array
            data = np.load(file_path)
            corrected_data = data.copy()
            process_array(data, corrected_data, rules)
        
        elif ext == '.csv':
            # Load CSV and maintain original dataframe structure
            df = pd.read_csv(file_path)
            
            # Identify depth columns (e.g., 'DEPTH', 'START DEPTH', 'END DEPTH')
            depth_cols = [c for c in df.columns if any(key in c.upper() for key in ['DEPTH', 'START', 'END'])]
            
            if not depth_cols:
                print(f"Error: No depth-related columns found in {file_path}.")
                return
            
            print(f"Found depth columns to update: {depth_cols}")
            
            # Apply shifting rules to each identified depth column
            for col in depth_cols:
                original_values = df[col].values.astype(float)
                corrected_values = original_values.copy()
                
                for start, end, shift in rules:
                    # Create a boolean mask for values within the interval
                    mask = (original_values >= start) & (original_values <= end)
                    corrected_values[mask] += shift
                    
                df[col] = corrected_values
            
            corrected_data = df
        else:
            print(f"Error: Unsupported format {ext}. Only .npy and .csv are supported.")
            return

    except Exception as e:
        print(f"Error processing file: {e}")
        return

    # --- Save Output ---
    if ext == '.npy':
        np.save(output_path, corrected_data)
    else:
        # Save CSV while preserving all original columns and headers
        df.to_csv(output_path, index=False)
    
    print(f"Successfully processed and saved to: {output_path}")

def process_array(original, target, rules):
    """Internal logic for applying shifts to raw NumPy arrays."""
    for start, end, shift in rules:
        mask = (original >= start) & (original <= end)
        count = np.sum(mask)
        if count > 0:
            target[mask] += shift
            print(f"  Applied {shift}m shift to {count} points in range [{start}, {end}]")

def main():
    """Main entry point for the command-line interface."""
    parser = argparse.ArgumentParser(description='Universal Depth Shift Script for .npy and .csv datasets.')
    
    parser.add_argument('input', type=str, help="Path to the source .npy or .csv file")
    parser.add_argument('--shifts', nargs='+', type=float, required=True,
                        help="Depth intervals and shift values in groups of 3: <START> <END> <SHIFT>")
    parser.add_argument('--output', type=str, default=None, help="Custom output filename/path")

    args = parser.parse_args()

    if len(args.shifts) % 3 != 0:
        print("Error: Shifts must be provided in complete triplets (Start, End, Value).")
        return

    rules = [(args.shifts[i], args.shifts[i+1], args.shifts[i+2]) for i in range(0, len(args.shifts), 3)]
    
    base, ext = os.path.splitext(args.input)
    output_path = args.output if args.output else f"{base}_corrected{ext}"

    apply_shifts(args.input, rules, output_path)

if __name__ == '__main__':
    main()