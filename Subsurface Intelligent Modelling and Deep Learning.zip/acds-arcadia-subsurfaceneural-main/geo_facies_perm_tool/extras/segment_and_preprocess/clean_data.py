"""
Facies/Permeability Training Data Cleaning and Normalization Script
==================================================================
This script processes raw training data to ensure consistency across 
different logs and wells. 

Usage:
    python clean_training_data.py <INPUT_FILE> -o <OUTPUT_NAME>

Key Operations:
1. Column Harmonization: Merges 'DTS_1/2' variant names into 'DTS1/2'.
2. Numeric Sanitization: Removes non-numeric characters like commas and '<'.
3. Null Value Standardization: Replaces industry nulls (-999) with NaN.
4. Metadata Preservation: Cleans log columns while protecting labels/metadata.
"""

import pandas as pd
import numpy as np
import os
import argparse

def clean_numeric_values(value):
    """
    Cleans string representations of numbers by handling commas, 
    comparison operators, and whitespace.
    """
    if pd.isna(value): return np.nan
    s = str(value).strip()
    s = s.replace(',', '.') # Convert European-style decimals
    s = s.replace('<', '')  # Remove detection limit markers
    try:
        return float(s)
    except (ValueError, TypeError):
        return np.nan

def process_cleaning(input_path, output_path):
    # --- 1. Load Dataset ---
    if not os.path.exists(input_path):
        print(f"Error: File '{input_path}' not found.")
        return

    print(f"Processing: {os.path.basename(input_path)}")
    df = pd.read_csv(input_path)

    # Automatically determine the well identification column
    well_col = 'Well Name' if 'Well Name' in df.columns else 'Well_ID'
    print(f"Initial State: {len(df)} rows, Well column: '{well_col}'")

    # --- 2. Merge DTS Variant Columns ---
    # Standardize sonic log naming: Merge DTS_X into DTSX
    for i in ['1', '2']:
        target = f'DTS{i}'
        source = f'DTS_{i}'
        
        if source in df.columns:
            if target in df.columns:
                print(f"  -> Merging {source} into {target}...")
                df[target] = df[target].fillna(df[source])
                df = df.drop(columns=[source])
            else:
                print(f"  -> Renaming {source} to standard {target}...")
                df = df.rename(columns={source: target})

    # --- 3. Identify and Sanitize Log Columns ---
    # Protected columns that should not be subjected to string-to-float cleaning
    exclude_cols = [well_col, 'Facies Class Name', 'DEPTH', 'Match_Key']

    # Select columns that are stored as 'object' (strings) but should be numeric
    log_columns = df.select_dtypes(include=['object']).columns.tolist()
    log_columns = [c for c in log_columns if c not in exclude_cols]

    if log_columns:
        print(f"  -> Sanitizing numeric characters in: {log_columns}")
        for col in log_columns:
            df[col] = df[col].apply(clean_numeric_values)

    # --- 4. Standardize Null Values & Clean Structures ---
    # Replace common well-log null markers (-999) with NaN
    df = df.replace([-999, -999.0, -999.25], np.nan)

    # Remove redundant 'Unnamed' columns from CSV exports
    df = df.loc[:, ~df.columns.astype(str).str.contains('^Unnamed')]

    # --- 5. Sort by Well and Depth (Crucial for sequential modeling) ---
    depth_col = next((c for c in df.columns if 'DEPTH' in c.upper()), None)
    if depth_col and well_col in df.columns:
        print(f"  -> Sorting data by {well_col} and {depth_col}")
        df[depth_col] = pd.to_numeric(df[depth_col], errors='coerce')
        df = df.sort_values(by=[well_col, depth_col])

    # --- 6. Save Processed Data ---
    df.to_csv(output_path, index=False)
    
    print("-" * 50)
    print(f"Task Completed Successfully!")
    print(f"Final Row Count: {len(df)}")
    print(f"Cleaned dataset saved to: {output_path}")

def main():
    parser = argparse.ArgumentParser(description="Standardize and clean well log training data.")
    parser.add_argument('input', type=str, help="Path to the raw CSV training data")
    parser.add_argument('-o', '--output', type=str, default=None, 
                        help="Output filename (default: <input>_cleaned.csv)")

    args = parser.parse_args()

    # Define default output path if none provided
    if not args.output:
        base, ext = os.path.splitext(args.input)
        output_path = f"{base}_cleaned{ext}"
    else:
        output_path = args.output

    process_cleaning(args.input, output_path)

if __name__ == "__main__":
    main()