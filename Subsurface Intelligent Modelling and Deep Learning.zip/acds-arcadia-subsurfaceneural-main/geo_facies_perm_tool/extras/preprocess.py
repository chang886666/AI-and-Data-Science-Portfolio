import numpy as np
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.base import BaseEstimator, TransformerMixin


class CleanNumericObjects(BaseEstimator, TransformerMixin):
    """
    Cleans object-type columns that contain numeric values with unwanted
    characters and converts them into numeric datatype.

    The transformer:
    - Replaces comma decimal separators with dots
    - Removes letters and special characters
    - Converts cleaned values to numeric (float)
    - Invalid values are set to NaN

    Input
    ---------------------------------------------
    X : pandas.DataFrame
        DataFrame to be processed.

    Returns
    ----------------------------------------------
    pandas.DataFrame
        DataFrame where object columns containing numeric-like
        values are cleaned and converted to numeric datatype.
    """

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        df = X.copy()

        for col in df.columns:
            if df[col].dtype == "object":
                series = df[col].astype(str)
                series = series.str.replace(",", ".", regex=False)
                series = series.str.replace(r"[^0-9.]", "", regex=True)
                df[col] = pd.to_numeric(series)
        return df


def preprocess_data(data):
    pipeline = Pipeline(steps=[
        'clean_numeric_objects', CleanNumericObjects(),
    ])
    pass
