# extras/__init__.py

from .perm_preprocess import get_preprocessor

__all__ = ["get_preprocessor"]