import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from torchvision import transforms
from PIL import Image
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

from geo_facies_perm_tool.dl_facies_process import MultiModalSEResNet

"""
Facies Inference Pipeline for Blind Well Data
-----------------------------------------------------------

This script performs inference using a pre-trained multimodal deep learning
model that combines core image data (.npy) (with depth files [.npy] as well) 
and well line log measurements (.las) to predict
facies classes along depth for a blind well.

The model is trained at `dl_facies_process.py`. So in this script, it only loads a trained PyTorch model
(.pth file) and applies it to unseen (blind) well data.


Overall Workflow:

1. Load a trained multimodal neural network (image + wire line log inputs).
2. Read a blind well CSV file containing log measurements and facies labels.
3. Explicitly remove invalid depth intervals (NC / BS) based on facies_id.
4. For each valid depth sample:
   Ⅰ. Load the corresponding core image stored as a .npy file.
   Ⅱ. Apply image preprocessing (resize, normalization).
   Ⅲ. Extract raw log measurements (GR, RHOB, NPHI, DT).
   Ⅳ. Convert image and log data into PyTorch tensors.
   Ⅴ. Feed both inputs jointly into the trained model.
   Ⅵ. Predict the facies class by selecting the maximum output logit.
5. Collect predicted facies and compare them with provided facies_id labels.
6. Visualize predicted vs. true facies along depth.


Required Inputs:

1. Trained Model File
   - Format: PyTorch state_dict (.pth)
   - We have got it in relative path geo_facies_perm_tool/best_facies_model

2. Blind Well CSV File
   - Format: CSV
   - Must contain the following columns:

       Depth        : float, depth value (used for mapping with img and visualization)
       GR           : float, gamma ray log
       RHOB         : float, bulk density log
       NPHI         : float, neutron porosity log
       DT           : float, sonic log
       image_name   : string, depth of the corresponding core image file
       facies_id    : string, facies label

   - facies_id is expected to follow this encoding:
       0: 'ih', 1: 'is', 2: 'os', 3: 's', 4: 'sh'  -> valid facies classes
       other values  -> NC / BS (removed before inference)


3. Core Image Folder
   - Each depth sample must have a corresponding .npy image file.
   - File naming convention:
       <image_name>.npy
   - The .npy file should store a (H,W,C) NumPy array representing a core image.


Model Inputs:

For each depth sample, the model receives:

1. Image Tensor
   - Shape: (1, 3, 224, 224)
   - Type : torch.float32
   - Preprocessing:
       - Resize to 224 x 224
       - Convert to RGB
       - ImageNet normalization

2. Log Tensor
   - Shape: (1, 4)
   - Order: [GR, RHOB, NPHI, DT]
   - Type : torch.float32

Model Outputs:

- Raw model output:
    Tensor of shape (1, 5), representing logits for each facies class.

- Final prediction:
    An integer facies label obtained via argmax over the output logits.


Outputs of This Script:

1. A list of predicted facies_id values along depth.
2. A list of true facies_id values (for evaluation purposes).
3. A depth-based visualization comparing predicted and true facies.


Assumptions and Limitations:

- The blind well data contains no missing values in log measurements.
- Since different wireline log data and npy images and 
    depth files after corebreakout process need to be input, 
    the model input must strictly correspond.
"""


# 1. Set Pipeline
class FaciesInferencePipeline:
    def __init__(self, model_path, scaler_params=None):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = self.load_model(model_path)
        self.transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        ])
        # Facies Encoding Map
        self.facies_labels = {0: 'ih', 1: 'is', 2: 'os', 3: 's', 4: 'sh'}

    def load_model(self, path):
        model = MultiModalSEResNet(num_classes=5)
        model.load_state_dict(torch.load(path, map_location=self.device))
        model.to(self.device)
        model.eval()
        return model

    def preprocess_blind_data(self, csv_path):
        """
        Deleting the unnecessary columns.
        """
        df = pd.read_csv(csv_path)
        df = df[~df['facies'].isin(['No Core', 'Bad Section'])]

        return df


# 2. Prediction and Evaluation

def run_blind_test(pipeline, blind_csv, image_dir):
    print(f"--- Starting Inference on Blind Well Data ---")

    # Get the data after cleaning
    data = pipeline.preprocess_blind_data(blind_csv, image_dir)

    predictions = []
    actuals = []

    with torch.no_grad():
        for index, row in data.iterrows():
            # Load and process the corresponding depth images
            img_path = f"{image_dir}/{row['image_name']}.npy"
            img_array = np.load(img_path)
            img = Image.fromarray(img_array.astype('uint8')).convert('RGB')
            img_tensor = pipeline.transform(img).unsqueeze(0).to(pipeline.device)

            # Load log feature
            log_tensor = torch.tensor(row[['GR', 'RHOB', 'NPHI', 'DT']].values.astype(np.float32)).unsqueeze(0).to(
                pipeline.device)

            # Predict the model
            outputs = pipeline.model(img_tensor, log_tensor)
            _, predicted = torch.max(outputs, 1)

            predictions.append(predicted.item())
            actuals.append(row['facies_id'])

    return data, actuals, predictions


# 3. Visualization

def visualize_results(data, actuals, predictions):
    plt.figure(figsize=(12, 6))
    plt.subplot(1, 2, 1)
    plt.step(actuals, data['Depth'], label='Actual Facies', color='blue', where='post')
    plt.step(predictions, data['Depth'], label='Predicted Facies', color='red', linestyle='--', where='post')
    plt.gca().invert_yaxis()
    plt.xlabel('Facies ID')
    plt.ylabel('Depth (m)')
    plt.title('Blind Well Prediction Comparison')
    plt.legend()
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    # The model Path
    inference = FaciesInferencePipeline(model_path='geo_facies_perm_tool/best_facies_model.pth')

    # The Test Path
    blind_data, y_true, y_pred = run_blind_test(inference, 'blind_well.csv', 'blind_images/')

    # Evaluation and Visualization
    visualize_results(blind_data, y_true, y_pred)