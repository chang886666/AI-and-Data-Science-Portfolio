"""
Subsurface Permeability Prediction Engine
-----------------------------------------
This script handles the end-to-end inference workflow for predicting 
formation permeability using XGBoost and petrophysical logs.

Workflow:
1. Load wireline data (LAS or CSV).
2. Standardize mnemonics and merge sonic components (DTS).
3. Apply petrophysical feature engineering via the preprocessing module.
4. Align features with the 32-dimensional space used during training.
5. Generate predictions and export results with calculated physical indices.

How to Use:
python predictor.py /204-20-6a_logs.las 
--model /local_compatible_model.json 
--metadata /feature_metadata.json

"""

import pandas as pd
import numpy as np
import xgboost as xgb
import argparse
import os
import sys
import lasio
import json
from extras.perm_preprocess import get_preprocessor

class PermeabilityPredictor:
    """
    Main predictor class for managing model loading and inference.
    
    Attributes:
        trained_features (list): Ordered list of feature names required by the model.
        model (xgb.Booster): The loaded XGBoost model instance.
    """
    def __init__(self, model_path, metadata_path):
        # Load the feature metadata (32 required features)
        with open(metadata_path, 'r') as f:
            self.trained_features = json.load(f)

        self.model = xgb.Booster()
        try:
            self.model.load_model(model_path)
            print(f"Status: Model successfully loaded -> {os.path.basename(model_path)}")
        except Exception as e:
            print(f"Error: Failed to load model. {e}")
            sys.exit(1)

    def predict(self, X_raw):
        """
        Processes raw log data and returns permeability predictions.
        
        Args:
            X_raw (pd.DataFrame): Raw log data from file.
            
        Returns:
            tuple: (predictions in mD, engineered features DataFrame)
        """
        # 1. Column Standardization
        X_raw.columns = X_raw.columns.str.strip().str.upper()
        
        # Mapping common mnemonics to internal standards
        name_map = {
            'DTS_1': 'DTS1', 'DTS_2': 'DTS2',
            'RHOB': 'DENS', 'NPHI': 'NEUT', 
            'DT': 'DTC', 'RT': 'RDEP'
        }
        X_raw = X_raw.rename(columns=name_map)

        # 2. Sonic Log Logic: Merge DTS components if primary DTS is missing
        if 'DTS' not in X_raw.columns:
            if 'DTS1' in X_raw.columns and 'DTS2' in X_raw.columns:
                X_raw['DTS'] = (X_raw['DTS1'] + X_raw['DTS2']) / 2.0
                print("Note: Automatically merged DTS1 and DTS2 components.")
            elif 'DTS1' in X_raw.columns:
                X_raw['DTS'] = X_raw['DTS1']
                print("Note: Using DTS1 as primary DTS.")

        # 3. Feature Engineering
        # Calculate VSHALE, RES_RATIO, log transforms, etc.
        pipe = get_preprocessor()
        X_engineered = pipe.fit_transform(X_raw)

        # 4. Feature Alignment
        # Strictly enforce the 32-feature matrix used in training
        X_final = pd.DataFrame(np.nan, index=X_raw.index, columns=self.trained_features)
        for col in self.trained_features:
            if col in X_engineered.columns:
                X_final[col] = X_engineered[col]

        matched_count = X_final.notna().any().sum()
        print(f"--- Feature Alignment Stats ---")
        print(f"Matched Features: {matched_count} / 32")
        
        # 5. Inference
        dmat = xgb.DMatrix(X_final)
        y_log10 = self.model.predict(dmat)
        
        # Convert Log10(Perm) back to milliDarcy (mD)
        return np.power(10, y_log10), X_engineered

def load_data(file_path):
    """Loads wireline data from LAS or CSV formats."""
    ext = os.path.splitext(file_path)[1].lower()
    if ext == '.las':
        las = lasio.read(file_path)
        return las.df().reset_index()
    return pd.read_csv(file_path)

def main():
    parser = argparse.ArgumentParser(description="Subsurface Permeability Inference Script")
    parser.add_argument('input', type=str, help="Input LAS or CSV file path")
    parser.add_argument('--model', type=str, required=True, help="Path to the .json model file")
    parser.add_argument('--metadata', type=str, required=True, help="Path to the feature metadata JSON")
    parser.add_argument('--output', type=str, default='PREDICTIONS.csv', help="Output filename")
    args = parser.parse_args()

    predictor = PermeabilityPredictor(args.model, args.metadata)
    raw_df = load_data(args.input)
    
    print("Status: Starting inference pipeline...")
    preds, engineered_df = predictor.predict(raw_df)

    # Merge Logic: 
    # Extract only newly generated columns to avoid duplicates with raw data
    new_cols = engineered_df.columns.difference(raw_df.columns)
    
    output_df = pd.concat([raw_df, engineered_df[new_cols]], axis=1)
    output_df['PRED_PERM_MD'] = preds

    output_df.to_csv(args.output, index=False)
    print(f"Success: Results saved to {args.output} (including derived physical indices).")

if __name__ == "__main__":
    main()