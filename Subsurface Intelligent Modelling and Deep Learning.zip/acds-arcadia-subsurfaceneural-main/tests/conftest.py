import numpy as np
import pandas as pd
import pytest


@pytest.fixture
def dummy_data():
    rng = np.random.default_rng(0)
    n = 60

    X = pd.DataFrame({
        "GR": rng.normal(80, 10, n),
        "RHOB": rng.normal(2.35, 0.08, n),
        "NPOR": rng.normal(0.25, 0.04, n),
        "DTC": rng.normal(80, 7, n),
        "RESD": rng.lognormal(1.0, 0.4, n),
    })

    # Facies: 3 classes based on GR
    facies = pd.cut(X["GR"], bins=[-1e9, 75, 90, 1e9], labels=[0, 1, 2]).astype(int)

    # Permeability: continuous target
    perm = (50 - 0.25 * X["GR"] + 15 * X["NPOR"] + 2.0 * X["RESD"] + rng.normal(0, 2, n)).astype(float)

    return X, perm
