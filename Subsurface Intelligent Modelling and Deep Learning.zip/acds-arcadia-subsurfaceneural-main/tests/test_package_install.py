import importlib
import pkgutil
import sys
import os


Package = 'geo_facies_perm_tool'


def test_package_importable():
    '''Package can be imported (installed or on PYTHONPATH)'''
    mod = importlib.import_module(Package)
    assert mod is not None


def test_submodules_exist():
    '''Check core modules exist inside the package'''
    importlib.import_module(f'{Package}.classifier')
    importlib.import_module(f'{Package}.predictor')
    importlib.import_module(f'{Package}.visualizer')


def test_extras_subpackage_importable():
    """extras is a real subpackage."""
    importlib.import_module(f"{Package}.extras")
    importlib.import_module(f"{Package}.extras.preprocess")

def test_package_is_discoverable():
    spec = importlib.util.find_spec(Package)
    assert spec is not None





