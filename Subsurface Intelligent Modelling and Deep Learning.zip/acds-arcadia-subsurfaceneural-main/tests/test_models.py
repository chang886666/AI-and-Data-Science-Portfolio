import numpy as np
import pandas as pd
import pytest

from geo_facies_perm_tool.predictor import PermeabilityPredictor


def test_permeability_predictor_fit_predict(dummy_data):
    """Model fits and returns predictions of correct shape."""
    X, y = dummy_data

    model = PermeabilityPredictor(
        n_estimators=25,  # keep tests fast
        max_depth=3,
        learning_rate=0.1,
        subsample=0.9,
        colsample_bytree=0.9,
        random_state=42,
    )

    model.fit(X, y)
    y_pred = model.predict(X)

    assert isinstance(y_pred, np.ndarray)
    assert y_pred.shape == (len(X),)
    assert np.isfinite(y_pred).all()
    assert (y_pred >= 0).all()


def test_permeability_predictor_predict_before_fit_raises(dummy_data):
    """Calling predict before fit should raise RuntimeError."""
    X, _ = dummy_data
    model = PermeabilityPredictor(n_estimators=5, max_depth=2)

    with pytest.raises(RuntimeError):
        _ = model.predict(X)


def test_permeability_predictor_evaluate_returns_metrics(dummy_data):
    """Evaluate returns r2 and mse as floats."""
    X, y = dummy_data
    model = PermeabilityPredictor(n_estimators=25, max_depth=3, random_state=42)

    model.fit(X, y)
    y_pred = model.predict(X)

    metrics = model.evaluate(y_actual=y, y_pred=pd.Series(y_pred))

    assert isinstance(metrics, dict)
    assert "r2" in metrics and "mse" in metrics
    assert isinstance(metrics["r2"], float)
    assert isinstance(metrics["mse"], float)
    assert np.isfinite(metrics["r2"])
    assert np.isfinite(metrics["mse"])
