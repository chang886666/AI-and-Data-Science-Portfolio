# Individual Contributions 

Sykes-Scott Archie: Visualization, Debugging, Feature Engineering, Report

Deng Kaiqing: Facies Classification, Packaging, Debugging, Github handling, Data Cleaning

Ge Erni: Permeability Prediction, Debugging, Data Cleaning

WAN BAZLAN FARID Wan Nur Balqish: Permeability Prediction, Core segmentation, Debugging, Demonstation.ipynb, Documentation

Kokkiligadda Varun: Permeability Prediction, Packaging, Depth Alignment, Documentation

TANG Miaozhou: Permeability Prediction, Core Segmentation, Feature Engineering, Packaging, Depth Alignment, Debugging, Data 
Cleaning, PowerPoint Presentation, Preprocesing

Abdullayev Rza: Facies Classification, Debugging, Feature Engineering, Core Segmentation, Depth Alignment, Data Cleaning
 
Cao Chang: Permeability Prediction, Report, PowerPoint Presentation
