## Websites
- [Corebreakout](https://github.com/rgmyr/corebreakout)
- [sort() key syntax](https://stackoverflow.com/a/42966511)
- [lasio](https://lasio.readthedocs.io/en/latest/index.html)
- [matplotlib major, minor ticks](https://matplotlib.org/3.4.3/gallery/ticks_and_spines/major_minor_demo.html)
- [matplotlib legend anchoring](https://stackoverflow.com/a/44414858)
- [matplotlib FuncFormatter() for custom ticks](https://stackoverflow.com/q/40511476)
- [matplotlib.ticker](https://matplotlib.org/stable/api/ticker_api.html)
- [Pytest](https://docs.pytest.org/en/stable/explanation/pythonpath.html)
- [Pytorch](https://www.learnpytorch.io/03_pytorch_computer_vision/)

## AI Usage
Our group used ChatGpt to debug the code, generate ideas, to learn about creating test cases to validate models and  packages. 

https://chatgpt.com/share/697c9115-4fac-8003-8ea3-b475d69f1e0b


