import folium
import pandas as pd
import numpy as np

from .live import get_latest_rainfall_readings, get_stations

__all__ = [
    "plot_circle",
    "plot_stations",
    "plot_postcodes",
    "plot_postcodes_with_live_rain",
    "plot_live_rain_map",
    "level_to_color",
    "level_to_red",
    "get_postcode_prediction",
    "show_postcode_prediction_on_map",
]


BLUES = {
    1: "#deebf7",
    2: "#c6dbef",
    3: "#9ecae1",
    4: "#6baed6",
    5: "#4292c6",
    6: "#2171b5",
    7: "#084594",
}


def level_to_color(level: int) -> str:
    """Risk levels 1 to 7 are mapped to shades of blue."""
    level = max(1, min(7, int(level)))
    return BLUES[level]


def level_to_red(level: int) -> str:
    """Deprecated alias."""
    return level_to_color(level)


def plot_circle(lat, lon, radius, map_obj=None, **kwargs):
    if map_obj is None:
        map_obj = folium.Map(
            location=[lat, lon],
            zoom_start=10,
            control_scale=True,
        )
    folium.Circle(
        location=[lat, lon],
        radius=radius,
        fill=True,
        fillOpacity=0.6,
        **kwargs,
    ).add_to(map_obj)
    return map_obj


def plot_stations(df_stations, map_obj=None, pin_color="blue"):
    if map_obj is None:
        map_obj = folium.Map(location=[53, 0], zoom_start=6)

    df = df_stations.dropna(subset=["latitude", "longitude"])

    for _, row in df.iterrows():
        popup = (
            f"{row.get('stationReference', '')}<br>"
            f"{row.get('stationName', '')}"
        )
        folium.Marker(
            location=[row["latitude"], row["longitude"]],
            popup=popup,
            icon=folium.Icon(color=pin_color, icon="info-sign"),
        ).add_to(map_obj)

    return map_obj


def add_flood_legend(map_obj):
    """Add a small HTML legend for the 1–7 flood risk scale."""
    legend_html = """
    <div style="
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        background-color: white;
        padding: 10px;
        border-radius: 8px;
        box-shadow: 0px 0px 6px rgba(0,0,0,0.3);
        font-size: 12px;
    ">
        <b>Flood Risk Level (1–7)</b><br>
        <i>Low → High</i>
        <div style="margin-top:6px; display:flex;">
            <div style="width:20px;height:20px;background:#deebf7"></div>
            <div style="width:20px;height:20px;background:#c6dbef"></div>
            <div style="width:20px;height:20px;background:#9ecae1"></div>
            <div style="width:20px;height:20px;background:#6baed6"></div>
            <div style="width:20px;height:20px;background:#4292c6"></div>
            <div style="width:20px;height:20px;background:#2171b5"></div>
            <div style="width:20px;height:20px;background:#084594"></div>
        </div>
        <div style="
            display:flex;
            justify-content:space-between;
            margin-top:2px;
        ">
            <span>1</span><span>7</span>
        </div>
    </div>
    """
    map_obj.get_root().html.add_child(folium.Element(legend_html))
    return map_obj


def plot_postcodes(df_postcodes, map_obj=None):
    """
    Plot postcodes with:
        - riskLabel (colour)
        - medianPrice (popup)
        - historicallyFlooded (popup)

    latestRainfall is not shown here.
    """
    if map_obj is None:
        map_obj = folium.Map(location=[53, -1], zoom_start=6)

    df = df_postcodes.dropna(subset=["latitude", "longitude"])

    for _, row in df.iterrows():
        postcode = row["postcode"]
        lvl = row.get("riskLabel", None)
        price = row.get("medianPrice", None)
        hist = row.get("historicallyFlooded", None)

        popup_parts = [f"<b>Postcode:</b> {postcode}"]
        if pd.notna(lvl):
            popup_parts.append(f"<b>Risk level:</b> {int(lvl)} / 7")
        if pd.notna(price):
            popup_parts.append(f"<b>Median price:</b> £{price:,.0f}")
        if pd.notna(hist):
            label = (
                "Yes"
                if str(hist).strip() in ("1", "True", "true")
                else "No"
            )
            popup_parts.append(f"<b>Historically flooded:</b> {label}")

        popup_html = "<br>".join(popup_parts)

        color = level_to_color(int(lvl)) if pd.notna(lvl) else "#999999"

        folium.CircleMarker(
            location=[row["latitude"], row["longitude"]],
            radius=4,
            color=color,
            fill=True,
            fill_opacity=0.85,
            popup=popup_html,
        ).add_to(map_obj)

    add_flood_legend(map_obj)
    return map_obj


def _attach_latest_rain_to_postcodes(df_postcodes, df_rain_stations):
    """Nearest-neighbour join of live rainfall onto postcode centroids."""
    df = df_postcodes.copy()

    stn_lats = df_rain_stations["latitude"].values
    stn_lons = df_rain_stations["longitude"].values
    stn_vals = df_rain_stations["rainfall_mm"].values

    rains = []
    for _, row in df.iterrows():
        d2 = (
            (stn_lats - row["latitude"]) ** 2
            + (stn_lons - row["longitude"]) ** 2
        )
        rains.append(float(stn_vals[int(np.argmin(d2))]))

    df["latestRainfall"] = rains
    return df


def plot_postcodes_with_live_rain(df_postcodes, map_obj=None):
    """Plot postcodes, enriching them with nearest live rainfall reading."""
    df_rain = get_latest_rainfall_readings().reset_index()
    df_stations = get_stations()

    df_rain_stn = df_rain.merge(
        df_stations[["stationReference", "latitude", "longitude"]],
        on="stationReference",
        how="inner",
    ).dropna(subset=["latitude", "longitude"])

    df_rain_stn = df_rain_stn.rename(columns={"value": "rainfall_mm"})
    df_with_rain = _attach_latest_rain_to_postcodes(df_postcodes, df_rain_stn)

    return plot_postcodes(df_with_rain, map_obj)


def plot_live_rain_map(zoom_start=7):
    """
    Plot only the stations with live rainfall readings.

    Marker colour is deep red and not linked to riskLabel.
    """
    df_rain = get_latest_rainfall_readings().reset_index()
    df_stations = get_stations()

    df_rain_stn = df_rain.merge(
        df_stations[
            ["stationReference", "stationName", "latitude", "longitude"]
        ],
        on="stationReference",
        how="inner",
    ).dropna(subset=["latitude", "longitude"])

    df_rain_stn = df_rain_stn.rename(columns={"value": "rainfall_mm"})

    center_lat = df_rain_stn["latitude"].mean()
    center_lon = df_rain_stn["longitude"].mean()
    map_obj = folium.Map(
        location=[center_lat, center_lon],
        zoom_start=zoom_start,
    )

    for _, row in df_rain_stn.iterrows():
        popup = (
            f"<b>Station:</b> {row['stationReference']}<br>"
            f"<b>Name:</b> {row.get('stationName', '')}<br>"
            f"<b>Rainfall:</b> {float(row['rainfall_mm']):.1f} mm<br>"
            f"<b>Time:</b> {pd.to_datetime(row['dateTime'])}"
        )

        folium.CircleMarker(
            location=[row["latitude"], row["longitude"]],
            radius=6,
            color="#cb181d",
            fill=True,
            fill_opacity=0.85,
            popup=popup,
        ).add_to(map_obj)

    return map_obj


def get_postcode_prediction(postcode, df_postcodes):
    """Look up the model prediction row for a single postcode."""
    norm = postcode.replace(" ", "").upper()
    df = df_postcodes.copy()
    df["__pc_norm"] = df["postcode"].str.replace(" ", "").str.upper()

    match = df[df["__pc_norm"] == norm]
    if match.empty:
        return None

    row = match.iloc[0]
    return {
        "postcode": row["postcode"],
        "riskLabel": row.get("riskLabel"),
        "medianPrice": row.get("medianPrice"),
        "historicallyFlooded": row.get("historicallyFlooded"),
        "latitude": row["latitude"],
        "longitude": row["longitude"],
    }


def show_postcode_prediction_on_map(postcode, df_postcodes):
    """Create a zoomed-in map centred on a single postcode."""
    info = get_postcode_prediction(postcode, df_postcodes)
    if info is None:
        raise ValueError(f"Postcode {postcode} not found")

    lat, lon = info["latitude"], info["longitude"]
    map_obj = folium.Map(location=[lat, lon], zoom_start=14)

    flooded_flag = str(info["historicallyFlooded"])
    flooded = flooded_flag in ("1", "True")

    popup = (
        f"<b>Postcode:</b> {info['postcode']}<br>"
        f"<b>Risk level:</b> {info['riskLabel']} / 7<br>"
        f"<b>Median price:</b> £{info['medianPrice']:,.0f}<br>"
        f"<b>Historically flooded:</b> {'Yes' if flooded else 'No'}"
    )

    folium.CircleMarker(
        location=[lat, lon],
        radius=10,
        color=level_to_color(int(info["riskLabel"])),
        fill=True,
        fill_opacity=0.9,
        popup=popup,
    ).add_to(map_obj)

    add_flood_legend(map_obj)
    return map_obj
