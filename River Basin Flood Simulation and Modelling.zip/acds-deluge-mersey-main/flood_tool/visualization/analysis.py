"""Analysis tools for flood data.

Functions to visualise and analyse flood risk and weather data."""

import math

import numpy as np
import pandas as pd

import matplotlib
import matplotlib.pyplot as plt

from ..utils import read_csv_from_example_data

from sklearn.neighbors import NearestNeighbors

__all__ = [
    "plot_postcode_density",
    "plot_risk_map",
    "plot_daily_rainfall_totals",
    "plot_station_rainfall_timeseries",
    "add_wetday_rainfall_to_predictions",
    "plot_rainfall_vs_risk_by_region",
    "plot_prediction_outputs",
    "plot_risk_impact_map",
    "plot_risk_by_historical_flood",
    "plot_risk_distribution_by_historical_flood",
    "plot_rainfall_vs_risk_scatter",
]

DEFAULT_POSTCODE_DATA = read_csv_from_example_data("postcodes_unlabelled.csv")


def plot_postcode_density(
    postcodes: str | pd.DataFrame = DEFAULT_POSTCODE_DATA,
    coordinate=["easting", "northing"],
    dx: float = 1000.0,
    **kwargs,
):
    """
    plot_postcode_density(postcodes=DEFAULT_POSTCODE_DATA,
                          coordinate=['easting', 'northing'],
                            dx=1000.0, **kwargs)

    Plot a postcode density map from a postcode file.


    Parameters
    ----------
    postcodese : str or pd.DataFrame, optional
        Path to postcode CSV file or DataFrame containing postcode data.
        Default is DEFAULT_POSTCODE_FILE.

    coordinate : list of str, optional
        List of two strings specifying the coordinate columns to use.
        Default is ['easting', 'northing'].

    dx : float, optional
        Grid spacing in coordinate units. Default is 1000.

    kwargs : dict, optional
        Additional keyword arguments to pass to matplotlib.pcolormesh.

    Returns
    -------

    matplotlib.axes.Axes
        The Axes object containing the plot.
    """

    if isinstance(postcodes, str):
        pdb = pd.read_csv(postcodes)
    else:
        pdb = postcodes.copy()

    bbox = (
        pdb[coordinate[0]].min() - 0.5 * dx,
        pdb[coordinate[0]].max() + 0.5 * dx,
        pdb[coordinate[1]].min() - 0.5 * dx,
        pdb[coordinate[1]].max() + 0.5 * dx,
    )

    nx = (
        math.ceil((bbox[1] - bbox[0]) / dx),
        math.ceil((bbox[3] - bbox[2]) / dx),
    )

    x = np.linspace(bbox[0] + 0.5 * dx, bbox[0] + (nx[0] - 0.5) * dx, nx[0])
    y = np.linspace(bbox[2] + 0.5 * dx, bbox[2] + (nx[1] - 0.5) * dx, nx[1])

    X, Y = np.meshgrid(x, y)

    Z = np.zeros(nx, int)

    for x, y in pdb[coordinate].values:
        Z[math.floor((x - bbox[0]) / dx), math.floor((y - bbox[2]) / dx)] += 1

    plt.pcolormesh(
        X,
        Y,
        np.where(Z > 0, Z, np.nan).T,
        norm=matplotlib.colors.LogNorm(),
        **kwargs,
    )
    plt.axis("equal")
    plt.colorbar()

    return plt.gca()


def plot_risk_map(risk_data, coordinate=["easting", "northing"], dx=10000):
    """
    Plot a risk map.

    Parameters
    ----------
    risk_data : pd.DataFrame
        DataFrame containing risk data with coordinate and riskLabel columns.
    coordinate : list of str, optional
        List of two strings specifying the coordinate columns to use.
        Default is ['easting', 'northing'].
    dx : float, optional
        Grid spacing in coordinate units. Default is 1000.
    Returns
    -------
    matplotlib.axes.Axes
        The Axes object containing the plot.
    """

    bbox = (
        risk_data[coordinate[0]].min() - 0.5 * dx,
        risk_data[coordinate[0]].max() + 0.5 * dx,
        risk_data[coordinate[1]].min() - 0.5 * dx,
        risk_data[coordinate[1]].max() + 0.5 * dx,
    )

    nx = (
        math.ceil((bbox[1] - bbox[0]) / dx),
        math.ceil((bbox[3] - bbox[2]) / dx),
    )

    x = np.linspace(bbox[0] + 0.5 * dx, bbox[0] + (nx[0] - 0.5) * dx, nx[0])
    y = np.linspace(bbox[2] + 0.5 * dx, bbox[2] + (nx[1] - 0.5) * dx, nx[1])

    X, Y = np.meshgrid(x, y)

    Z = np.zeros(nx, float)
    Zn = np.zeros(nx, int)

    for x, y, val in risk_data[coordinate + ["riskLabel"]].values:
        Z[math.floor((x - bbox[0]) / dx),
          math.floor((y - bbox[2]) / dx)] += val
        Zn[math.floor((x - bbox[0]) / dx),
           math.floor((y - bbox[2]) / dx)] += 1

    Z = Z / np.where(Zn > 0, Zn, 1)

    plt.pcolormesh(
        X, Y, np.where(Z > 0, Z, np.nan).T,
    )
    plt.axis("equal")
    plt.colorbar()

    return plt.gca()


def plot_daily_rainfall_totals(
    typical: pd.DataFrame,
    wet: pd.DataFrame,
    bins: int = 30,
    max_mm: float | None = 200.0,
):
    """Compare 24 h rainfall totals per station for a typical and a wet day.

    Parameters
    ----------
    typical : pd.DataFrame
        Data for the typical day, from ``typical_day.csv``.
    wet : pd.DataFrame
        Data for the wet day, from ``wet_day.csv``.
    bins : int, optional
        Number of bins in the histogram, by default 30.
    max_mm : float, optional
        Maximum rainfall (mm) shown on the axes to prevent a few
        extreme outliers dominating the scale. Set to None to
        disable truncation.

    Returns
    -------
    (fig, axes)
        Matplotlib figure and axes.
    """
    typical_rain = typical[typical["parameter"] == "rainfall"].copy()
    wet_rain = wet[wet["parameter"] == "rainfall"].copy()

    typical_rain["value"] = pd.to_numeric(
        typical_rain["value"],
        errors="coerce",
    )
    wet_rain["value"] = pd.to_numeric(
        wet_rain["value"],
        errors="coerce",
    )

    total_typ = typical_rain.groupby("stationReference")["value"].sum()
    total_wet = wet_rain.groupby("stationReference")["value"].sum()

    total_typ = total_typ[(total_typ >= 0) & np.isfinite(total_typ)]
    total_wet = total_wet[(total_wet >= 0) & np.isfinite(total_wet)]

    totals_df = pd.DataFrame(
        {
            "Typical day": total_typ,
            "Wet day": total_wet,
        },
    ).dropna(how="all")

    fig, axes = plt.subplots(1, 2, figsize=(12, 4))

    # left: histogram of 24 h totals
    axes[0].hist(
        total_typ,
        bins=bins,
        alpha=0.7,
        label="Typical day",
    )
    axes[0].hist(
        total_wet,
        bins=bins,
        alpha=0.7,
        label="Wet day",
    )
    axes[0].set_xlabel("24 h rainfall per station (mm)")
    axes[0].set_ylabel("Number of gauges")
    axes[0].set_title("Distribution of 24 h rainfall totals")
    axes[0].legend()

    if max_mm is not None:
        axes[0].set_xlim(0, max_mm)

    # right: boxplot comparison
    axes[1].boxplot(
        [
            totals_df["Typical day"].dropna(),
            totals_df["Wet day"].dropna(),
        ],
        labels=["Typical day", "Wet day"],
        showfliers=True,
    )
    axes[1].set_ylabel("24 h rainfall per station (mm)")
    axes[1].set_title("24 h rainfall totals per gauge")

    if max_mm is not None:
        axes[1].set_ylim(0, max_mm)

    fig.tight_layout()
    return fig, axes


def plot_station_rainfall_timeseries(
    typical: pd.DataFrame,
    wet: pd.DataFrame,
    station_id: str | None = None,
):
    """Plot rainfall time series for one gauge on a typical and a wet day.

    Parameters
    ----------
    typical : pd.DataFrame
        Data for the typical day, from ``typical_day.csv``.
    wet : pd.DataFrame
        Data for the wet day, from ``wet_day.csv``.
    station_id : str, optional
        ID of the gauge (stationReference) to plot. If None, the
        function chooses the wettest gauge on the wet day.

    Returns
    -------
    fig : matplotlib.figure.Figure
        Figure object.
    ax : matplotlib.axes.Axes
        Axes object.
    chosen_station : str
        The stationReference that was actually plotted.
    """
    typical_rain = typical[typical["parameter"] == "rainfall"].copy()
    wet_rain = wet[wet["parameter"] == "rainfall"].copy()

    typical_rain["value"] = pd.to_numeric(
        typical_rain["value"],
        errors="coerce",
    )
    wet_rain["value"] = pd.to_numeric(
        wet_rain["value"],
        errors="coerce",
    )

    if station_id is None:
        totals = (
            wet_rain.groupby("stationReference")["value"]
            .sum()
            .replace([np.inf, -np.inf], np.nan)
            .dropna()
        )
        if totals.empty:
            msg = "No rainfall data available in wet_day dataframe."
            raise ValueError(msg)
        station_id = totals.idxmax()

    typical_station = typical_rain[
        typical_rain["stationReference"] == station_id
    ].copy()
    wet_station = wet_rain[
        wet_rain["stationReference"] == station_id
    ].copy()

    for df_ in (typical_station, wet_station):
        df_["dateTime"] = pd.to_datetime(df_["dateTime"])
        df_.sort_values("dateTime", inplace=True)

    fig, ax = plt.subplots(figsize=(10, 4))

    ax.plot(
        typical_station["dateTime"],
        typical_station["value"],
        label="Typical day",
        linestyle="--",
        marker="o",
        linewidth=1,
    )
    ax.plot(
        wet_station["dateTime"],
        wet_station["value"],
        label="Wet day",
        linestyle="-",
        marker="o",
        linewidth=1.2,
    )

    ax.set_xlabel("Time")
    ax.set_ylabel("Rainfall (mm / 15 min)")
    ax.set_title(
        f"Rainfall at gauge {station_id}: typical vs wet day",
    )
    ax.legend()
    fig.autofmt_xdate()

    return fig, ax, station_id


def add_wetday_rainfall_to_predictions(
    pred_df: pd.DataFrame,
    wet_day: pd.DataFrame,
    stations: pd.DataFrame,
) -> pd.DataFrame:
    """Attach wet-day 24 h rainfall totals to each postcode.

    For every postcode we take the rainfall from the nearest gauge
    on the wet day. Postcode lat/lon are approximated from OS grid
    coordinates (easting/northing), so this is a rough spatial join
    rather than a full GIS projection.
    """
    df = pred_df.copy()

    wet_rain = wet_day[wet_day["parameter"] == "rainfall"].copy()
    wet_rain["value"] = pd.to_numeric(
        wet_rain["value"],
        errors="coerce",
    )

    rain_station = (
        wet_rain.groupby("stationReference")["value"]
        .sum()
        .replace([np.inf, -np.inf], np.nan)
        .dropna()
        .reset_index(name="rain_24h_mm")
    )

    station_meta = stations[
        ["stationReference", "latitude", "longitude"]
    ].dropna()
    station_rain = rain_station.merge(
        station_meta,
        on="stationReference",
        how="inner",
    )

    if "easting" not in df.columns or "northing" not in df.columns:
        msg = "pred_df must contain 'easting' and 'northing' columns."
        raise ValueError(msg)

    north_min = df["northing"].min()
    north_max = df["northing"].max()
    east_min = df["easting"].min()
    east_max = df["easting"].max()

    lat_min = station_rain["latitude"].min()
    lat_max = station_rain["latitude"].max()
    lon_min = station_rain["longitude"].min()
    lon_max = station_rain["longitude"].max()

    a_north = (lat_max - lat_min) / (north_max - north_min)
    b_north = lat_min - a_north * north_min
    a_east = (lon_max - lon_min) / (east_max - east_min)
    b_east = lon_min - a_east * east_min

    df["lat_approx"] = a_north * df["northing"] + b_north
    df["lon_approx"] = a_east * df["easting"] + b_east

    X_stations = station_rain[["latitude", "longitude"]].values
    nbrs = NearestNeighbors(
        n_neighbors=1,
        algorithm="ball_tree",
    ).fit(X_stations)

    X_pc = df[["lat_approx", "lon_approx"]].values
    _, indices = nbrs.kneighbors(X_pc)
    nearest_idx = indices[:, 0]

    df["nearest_station"] = station_rain.iloc[
        nearest_idx
    ]["stationReference"].values
    df["rain_24h_mm_wet"] = station_rain.iloc[
        nearest_idx
    ]["rain_24h_mm"].values

    return df


def plot_rainfall_vs_risk_by_region(
    pred_df: pd.DataFrame,
    region_col: str = "localAuthority",
    top_n: int = 10,
):
    """Plot wet-day rainfall vs flood risk at regional level.

    The input dataframe must already contain:
    - rain_24h_mm_wet  (from add_wetday_rainfall_to_predictions)
    - some notion of flood risk (predicted or labelled)
    - some notion of impact (or the pieces to build one)
    """
    df = pred_df.copy()

    # Build a single risk score per postcode if needed
    if "total_risk_pred" not in df.columns:
        if (
            "river_risk_pred" in df.columns
            and "surface_risk_pred" in df.columns
        ):
            df["total_risk_pred"] = (
                df["river_risk_pred"] + df["surface_risk_pred"]
            ) / 2.0
        elif "riskLabel" in df.columns:
            df["total_risk_pred"] = df["riskLabel"].astype(float)
        else:
            msg = (
                "pred_df must contain 'total_risk_pred', "
                "'river_risk_pred' + 'surface_risk_pred', "
                "or 'riskLabel'."
            )
            raise ValueError(msg)

    # Simple expected impact proxy if not present
    if "expected_impact" not in df.columns:
        if "medianPrice" in df.columns:
            df["expected_impact"] = (
                df["total_risk_pred"] * df["medianPrice"]
            )
        else:
            df["expected_impact"] = df["total_risk_pred"]

    if "rain_24h_mm_wet" not in df.columns:
        msg = (
            "pred_df must contain 'rain_24h_mm_wet'. "
            "Run add_wetday_rainfall_to_predictions() first."
        )
        raise ValueError(msg)

    region_stats = (
        df.groupby(region_col)
        .agg(
            mean_rain=("rain_24h_mm_wet", "mean"),
            mean_risk=("total_risk_pred", "mean"),
            total_impact=("expected_impact", "sum"),
            n_postcodes=("total_risk_pred", "size"),
        )
        .reset_index()
    )

    # Scatter: rainfall vs mean risk (bubble size = total impact)
    fig_scatter, ax_scatter = plt.subplots(figsize=(7, 5))

    sizes = region_stats["total_impact"].values
    if sizes.max() > 0:
        sizes = 200 * (sizes / sizes.max())
    else:
        sizes = np.full_like(sizes, 50)

    ax_scatter.scatter(
        region_stats["mean_rain"],
        region_stats["mean_risk"],
        s=sizes,
        alpha=0.7,
    )

    ax_scatter.set_xlabel("Mean wet-day 24 h rainfall (mm)")
    ax_scatter.set_ylabel("Mean predicted flood risk (score)")
    ax_scatter.set_title(
        "Regional rainfall intensity vs predicted flood risk",
    )
    fig_scatter.tight_layout()

    # Bar: top regions by total expected impact
    top = region_stats.sort_values(
        "total_impact",
        ascending=False,
    )
    if top_n is not None:
        top = top.head(top_n)

    fig_bar, ax_bar = plt.subplots(figsize=(8, 4))
    ax_bar.bar(
        top[region_col].astype(str),
        top["total_impact"].values,
    )
    ax_bar.set_ylabel("Total expected impact (relative units)")
    ax_bar.set_title(
        "Regions with highest predicted flood impact",
    )
    ax_bar.tick_params(axis="x", rotation=45)
    fig_bar.tight_layout()

    return fig_scatter, ax_scatter, fig_bar, ax_bar


def _ensure_prediction_columns(pred_df: pd.DataFrame) -> pd.DataFrame:
    """Return a copy of pred_df with standard prediction columns.

    The returned dataframe will always contain:
    - total_risk_pred
    - house_price
    - expected_impact

    If these columns are missing, they are constructed from
    reasonable proxies (labels, medianPrice, etc.).
    """
    df = pred_df.copy()

    # Build a single risk score per row
    if "total_risk_pred" not in df.columns:
        if (
            "river_risk_pred" in df.columns
            and "surface_risk_pred" in df.columns
        ):
            df["total_risk_pred"] = (
                df["river_risk_pred"] + df["surface_risk_pred"]
            ) / 2.0
        elif "riskLabel" in df.columns:
            df["total_risk_pred"] = df["riskLabel"].astype(float)
        else:
            msg = (
                "pred_df must contain 'total_risk_pred', "
                "'river_risk_pred' + 'surface_risk_pred', "
                "or 'riskLabel'."
            )
            raise ValueError(msg)

    # Standardise house price column
    if "house_price" not in df.columns:
        if "house_price_pred" in df.columns:
            df["house_price"] = df["house_price_pred"]
        elif "medianPrice" in df.columns:
            df["house_price"] = df["medianPrice"]
        else:
            # As a last resort, create a dummy price column
            df["house_price"] = 1.0

    # Expected impact
    if "expected_impact" not in df.columns:
        df["expected_impact"] = (
            df["total_risk_pred"] * df["house_price"]
        )

    return df


def plot_prediction_outputs(
    pred_df: pd.DataFrame,
    bins_risk: int = 20,
    bins_price: int = 20,
):
    """Plot summary visualisations of model outputs.

    This function shows:
    1) Histogram of flood risk scores.
    2) Histogram of house prices.
    3) Scatter of risk vs house price, with marker size
       proportional to expected impact.

    Parameters
    ----------
    pred_df : pd.DataFrame
        Postcode-level predictions. It should contain either:
        - total_risk_pred, or
        - river_risk_pred + surface_risk_pred, or
        - riskLabel (used as a proxy),
        and one of:
        - house_price_pred, or
        - medianPrice.
    bins_risk : int, optional
        Number of bins in the risk histogram, by default 20.
    bins_price : int, optional
        Number of bins in the price histogram, by default 20.

    Returns
    -------
    (fig_risk, ax_risk, fig_price, ax_price, fig_scatter, ax_scatter)
        Matplotlib figures and axes for the three plots.
    """
    df = _ensure_prediction_columns(pred_df)

    # 1) Risk score distribution
    fig_risk, ax_risk = plt.subplots(figsize=(6, 4))
    ax_risk.hist(
        df["total_risk_pred"].dropna(),
        bins=bins_risk,
        alpha=0.8,
    )
    ax_risk.set_xlabel("Predicted flood risk score")
    ax_risk.set_ylabel("Number of postcodes")
    ax_risk.set_title("Distribution of predicted flood risk")
    fig_risk.tight_layout()

    # 2) House price distribution
    fig_price, ax_price = plt.subplots(figsize=(6, 4))
    ax_price.hist(
        df["house_price"].dropna(),
        bins=bins_price,
        alpha=0.8,
    )
    ax_price.set_xlabel("House price")
    ax_price.set_ylabel("Number of postcodes")
    ax_price.set_title("Distribution of house prices")
    fig_price.tight_layout()

    # 3) Risk vs price scatter (size = expected impact)
    fig_scatter, ax_scatter = plt.subplots(figsize=(6, 5))

    sizes = df["expected_impact"].values
    if np.isfinite(sizes).any() and sizes.max() > 0:
        sizes = 50 * (sizes / sizes.max())
    else:
        sizes = np.full_like(sizes, 20)

    ax_scatter.scatter(
        df["house_price"],
        df["total_risk_pred"],
        s=sizes,
        alpha=0.5,
    )
    ax_scatter.set_xlabel("House price")
    ax_scatter.set_ylabel("Predicted flood risk score")
    ax_scatter.set_title(
        "Flood risk vs house price "
        "(marker size = expected impact)",
    )
    fig_scatter.tight_layout()

    return (
        fig_risk,
        ax_risk,
        fig_price,
        ax_price,
        fig_scatter,
        ax_scatter,
    )


def plot_risk_impact_map(
    pred_df: pd.DataFrame,
    x_col: str = "easting",
    y_col: str = "northing",
    risk_col: str = "total_risk_pred",
    impact_col: str = "expected_impact",
):
    """Plot a postcode map with colour = risk and marker size = impact.

    Parameters
    ----------
    pred_df : pd.DataFrame
        Postcode-level dataframe. It should contain at least
        coordinates (x_col, y_col) and some notion of risk
        and impact. If total_risk_pred / expected_impact are
        missing, reasonable proxies are constructed.
    x_col : str, optional
        Name of the horizontal coordinate column, by default
        "easting".
    y_col : str, optional
        Name of the vertical coordinate column, by default
        "northing".
    risk_col : str, optional
        Name of the risk column, by default "total_risk_pred".
        If this column is missing, it is built from
        river_risk_pred + surface_risk_pred or riskLabel.
    impact_col : str, optional
        Name of the impact column, by default "expected_impact".
        If this column is missing, it is built as
        total_risk_pred * house_price (or a simple proxy).

    Returns
    -------
    (fig, ax)
        Matplotlib figure and axes.
    """
    # Start from a copy and reuse the helper to standardise columns
    df = _ensure_prediction_columns(pred_df)

    # Ensure coordinates exist
    if x_col not in df.columns or y_col not in df.columns:
        msg = (
            "pred_df must contain coordinate columns "
            f"'{x_col}' and '{y_col}'."
        )
        raise ValueError(msg)

    # Use the standardised columns if requested names are missing
    if risk_col not in df.columns:
        risk_col = "total_risk_pred"
    if impact_col not in df.columns:
        impact_col = "expected_impact"

    risk = df[risk_col].astype(float)
    impact = df[impact_col].astype(float)

    # Normalise marker sizes for plotting (smaller and less overlapping)
    impact_values = impact.to_numpy(dtype=float)
    finite = np.isfinite(impact_values) & (impact_values > 0)

    if finite.any():
        impact_min = impact_values[finite].min()
        impact_max = impact_values[finite].max()
        if impact_max > impact_min:
            scaled = (impact_values[finite] - impact_min) / (
                impact_max - impact_min
            )
        else:
            scaled = np.zeros_like(impact_values[finite])

        sizes = np.full_like(impact_values, 6.0, dtype=float)
        sizes[finite] = 10.0 * scaled + 4.0  # sizes in roughly [4, 14]
    else:
        sizes = np.full_like(impact_values, 8.0, dtype=float)

    fig, ax = plt.subplots(figsize=(8, 6))

    sc = ax.scatter(
        df[x_col],
        df[y_col],
        c=risk,
        s=sizes,
        cmap="viridis_r",
        vmin=risk.min(),
        vmax=risk.max(),
        alpha=0.35,
        linewidths=0,
    )

    ax.set_xlabel(x_col)
    ax.set_ylabel(y_col)
    ax.set_title(
        "Postcode map: colour = flood risk, size = expected impact",
    )

    cbar = fig.colorbar(sc, ax=ax)
    cbar.set_label("Flood risk score")

    ax.set_aspect("equal", adjustable="box")
    fig.tight_layout()

    return fig, ax


def plot_risk_by_historical_flood(
    pred_df: pd.DataFrame,
    historical_col: str = "historical_flooded",
    region_col: str = "localAuthority",
    max_regions_per_group: int | None = 20,
):
    """Compare predicted risk with/without historical flooding.

    The left panel shows overall mean risk for postcodes that have
    and do not have historical flooding. The right panel shows
    region-level mean risks, with one small bar per region, grouped
    into two clusters (no historical flood vs historical flood).
    """
    # Standardise prediction columns: total_risk_pred, house_price,
    # expected_impact
    df = _ensure_prediction_columns(pred_df)

    # Locate the historical flooding indicator column
    if historical_col not in df.columns:
        for alt in ["historical", "historicalFlood", "historical_flood"]:
            if alt in df.columns:
                historical_col = alt
                break
        else:
            msg = (
                "pred_df must contain a binary historical flooding "
                "column, for example 'historical_flooded'."
            )
            raise ValueError(msg)

    # Convert historical flag to numeric 0/1
    hist = pd.to_numeric(df[historical_col], errors="coerce")
    risk = df["total_risk_pred"].astype(float)

    # --- Left panel: postcode-level mean risk by historical flag ---
    risk_not_flooded = risk[hist == 0]
    risk_flooded = risk[hist == 1]

    if risk_not_flooded.empty or risk_flooded.empty:
        msg = (
            "One of the historical flooding groups is empty at "
            "postcode level. Check the values in the historical "
            "column."
        )
        raise ValueError(msg)

    mean_not = risk_not_flooded.mean()
    mean_flooded = risk_flooded.mean()

    n_not = risk_not_flooded.shape[0]
    n_flooded = risk_flooded.shape[0]

    # --- Right panel: region-level mean risk, grouped by history ---
    if region_col not in df.columns:
        msg = (
            f"pred_df must contain a region column '{region_col}' "
            "to plot regional risk distributions."
        )
        raise ValueError(msg)

    df_region = df.copy()
    df_region["hist_flag"] = hist

    # For each region, compute:
    # - mean historical flag (share of historically flooded postcodes)
    # - mean predicted risk
    region_hist_mean = (
        df_region.groupby(region_col)["hist_flag"]
        .mean()
        .rename("hist_mean")
    )
    region_risk_mean = (
        df_region.groupby(region_col)["total_risk_pred"]
        .mean()
        .rename("mean_risk")
    )

    region_stats = pd.concat(
        [region_hist_mean, region_risk_mean],
        axis=1,
    ).dropna()

    # Assign each region to group 0/1 based on majority of postcodes
    region_stats["hist_group"] = (region_stats["hist_mean"] > 0.0).astype(int)

    reg0 = region_stats[region_stats["hist_group"] == 0].sort_values(
        "mean_risk",
        ascending=False,
    )
    reg1 = region_stats[region_stats["hist_group"] == 1].sort_values(
        "mean_risk",
        ascending=False,
    )

    if max_regions_per_group is not None:
        reg0 = reg0.head(max_regions_per_group)
        reg1 = reg1.head(max_regions_per_group)

    if reg0.empty or reg1.empty:
        msg = (
            "One of the historical flooding groups is empty at "
            "region level. Check the historical and region columns."
        )
        raise ValueError(msg)

    # --- Build the figure with two subplots ---
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))

    # Left: overall mean risk (your原图)
    labels_left = [
        f"No historical flood\n(n={n_not})",
        f"Historical flood\n(n={n_flooded})",
    ]
    means_left = [mean_not, mean_flooded]
    colors_left = ["tab:blue", "tab:orange"]

    axes[0].bar(labels_left, means_left, color=colors_left, alpha=0.8)
    axes[0].set_ylabel("Mean predicted flood risk score")
    axes[0].set_title(
        "Postcode-level mean risk by\nhistorical flooding status",
    )

    # Right: many small bars per region, in two clusters
    ax1 = axes[1]
    n0 = reg0.shape[0]
    n1 = reg1.shape[0]
    gap = 3  # visual gap between the two clusters

    x0 = np.arange(n0)
    x1 = np.arange(n1) + n0 + gap

    ax1.bar(
        x0,
        reg0["mean_risk"].values,
        color="tab:blue",
        alpha=0.7,
        label="No historical flood",
    )
    ax1.bar(
        x1,
        reg1["mean_risk"].values,
        color="tab:orange",
        alpha=0.7,
        label="Historical flood",
    )

    # X tick labels: region names (may be many, so rotate)
    xticks = np.concatenate([x0, x1])
    xtick_labels = list(reg0.index.astype(str)) + list(
        reg1.index.astype(str),
    )
    ax1.set_xticks(xticks)
    ax1.set_xticklabels(xtick_labels, rotation=90)

    ax1.set_ylabel("Mean predicted flood risk score")
    ax1.set_title(
        "Regional mean risk by historical flooding status",
    )
    ax1.legend(loc="upper right")

    fig.tight_layout()
    return fig, axes


def plot_risk_distribution_by_historical_flood(
    pred_df: pd.DataFrame,
    historical_col: str = "historical_flooded",
):
    """Plot the distribution of predicted risk for historical=0 vs 1.

    The figure has two panels. Each panel shows a bar chart where
    the x-axis is the discrete risk value (e.g. 1–7) and the y-axis
    is the number of postcodes with that risk level.
    """
    # Ensure we have total_risk_pred
    df = _ensure_prediction_columns(pred_df)

    # Locate the historical flooding column
    if historical_col not in df.columns:
        for alt in ["historical", "historicalFlood", "historical_flood"]:
            if alt in df.columns:
                historical_col = alt
                break
        else:
            msg = (
                "pred_df must contain a binary historical flooding "
                "column, for example 'historical_flooded'."
            )
            raise ValueError(msg)

    hist = pd.to_numeric(df[historical_col], errors="coerce")
    risk = df["total_risk_pred"].astype(float)

    # Split into two groups
    risk_not = risk[hist == 0]
    risk_flooded = risk[hist == 1]

    if risk_not.empty or risk_flooded.empty:
        msg = (
            "One of the historical flooding groups is empty. "
            "Check the values in the historical column."
        )
        raise ValueError(msg)

    # Treat risk as discrete levels (round to nearest int)
    risk_not_int = risk_not.round().astype(int)
    risk_flooded_int = risk_flooded.round().astype(int)

    # Common set of risk levels so the x-axes line up
    min_level = min(risk_not_int.min(), risk_flooded_int.min())
    max_level = max(risk_not_int.max(), risk_flooded_int.max())
    levels = np.arange(min_level, max_level + 1)

    counts_not = (
        risk_not_int.value_counts()
        .reindex(levels, fill_value=0)
        .sort_index()
    )
    counts_flooded = (
        risk_flooded_int.value_counts()
        .reindex(levels, fill_value=0)
        .sort_index()
    )

    n_not = risk_not.shape[0]
    n_flooded = risk_flooded.shape[0]

    fig, axes = plt.subplots(1, 2, figsize=(11, 4))

    # Left: historical = 0
    axes[0].bar(
        levels,
        counts_not.values,
        color="tab:blue",
        alpha=0.8,
    )
    axes[0].set_xlabel("Predicted flood risk score")
    axes[0].set_ylabel("Number of postcodes")
    axes[0].set_title(
        "Risk distribution\n(no historical flood, "
        f"n={n_not})",
    )
    axes[0].set_xticks(levels)
    # Give a small margin on top for nicer look
    axes[0].set_ylim(0, counts_not.max() * 1.05)

    # Right: historical = 1
    axes[1].bar(
        levels,
        counts_flooded.values,
        color="tab:orange",
        alpha=0.8,
    )
    axes[1].set_xlabel("Predicted flood risk score")
    axes[1].set_title(
        "Risk distribution\n(historical flood, "
        f"n={n_flooded})",
    )
    axes[1].set_xticks(levels)
    # Separate y-scale so small counts become visible
    axes[1].set_ylim(0, counts_flooded.max() * 1.05)

    fig.tight_layout()
    return fig, axes


def plot_rainfall_vs_risk_scatter(
    pred_df: pd.DataFrame,
    max_points: int = 20000,
):
    """
    Scatter plot of wet-day rainfall vs predicted flood risk
    at postcode level.

    Parameters
    ----------
    pred_df : pd.DataFrame
        Postcode-level dataframe. Must contain:
        - rain_24h_mm_wet  (from add_wetday_rainfall_to_predictions)
        and either:
        - total_risk_pred, or
        - predicted_risk, or
        - riskLabel (used as proxy).
    max_points : int, optional
        Maximum number of points to plot (randomly sampled if more),
        by default 20000.

    Returns
    -------
    fig : matplotlib.figure.Figure
        Figure object.
    ax : matplotlib.axes.Axes
        Axes object.
    """
    df = pred_df.copy()

    # Make sure we have a single risk column
    df = _ensure_prediction_columns(df)

    if "rain_24h_mm_wet" not in df.columns:
        msg = (
            "pred_df must contain 'rain_24h_mm_wet'. "
            "Run add_wetday_rainfall_to_predictions() first."
        )
        raise ValueError(msg)

    # Keep only finite values
    df = df[
        np.isfinite(df["rain_24h_mm_wet"])
        & np.isfinite(df["total_risk_pred"])
    ].copy()

    # Down-sample if there are too many points
    if len(df) > max_points:
        df = df.sample(n=max_points, random_state=0)

    fig, ax = plt.subplots(figsize=(7, 5))

    ax.scatter(
        df["rain_24h_mm_wet"],
        df["total_risk_pred"],
        alpha=0.3,
        s=10,
    )

    ax.set_xlabel("Wet-day 24h rainfall (mm)")
    ax.set_ylabel("Predicted flood risk (score)")
    ax.set_title("Postcode rainfall vs predicted flood risk")

    fig.tight_layout()
    return fig, ax
