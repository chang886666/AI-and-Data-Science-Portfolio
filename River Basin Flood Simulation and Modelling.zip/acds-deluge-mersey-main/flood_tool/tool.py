"""Example module in template package."""

from collections.abc import Sequence
from typing import List
from sklearn.impute import KNNImputer
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans

from flood_tool.geo import get_easting_northing_from_gps_lat_long
from flood_tool.geo import get_gps_lat_long_from_easting_northing
from .utils import read_csv_from_resources, read_csv_from_example_data
from .models import (
    AllMinimumRiskModel,
    AllEnglandMedianPriceModel,
    AllFalseModel,
    RandomBinaryClassifierModel,
    ModalLocalAuthorityModel,
    RF_LocalAuthorityModel,
    RandomForestFloodRiskModel,
    RF_MedianPriceModel,
    RandomForestFloodModel
)
from .models.RF_hfmodel import (
    HistoricallyFloodedModel,
)

from .models.HFmodel import (
    HistoricallyFloodedRf,
    # HistoricallyFloodedXgb,
)

# from .models.HFmodel1 import (
#     HistoricallyFloodedModel,
# )

__all__ = [
    "Tool",
    "flood_class_from_postcode_models",
    "flood_class_from_location_models",
    "house_price_models",
    "local_authority_models",
    "historic_flooding_models",
]

# dictionaries with keys of short name and values of long name of
# classification/regression models

# You should add your own models in the relevant dictionary here
# in the format 'short_name': 'Long Name'
flood_class_from_postcode_models = {
    "all_minimum_risk": "All minimum risk",
    "rf_balanced": "Random Forest Balanced Classifier",
    "random_forest": "RandomForest Weighted Classifier"
}
flood_class_from_location_models = {
    "all_minimum_risk": "All minimum risk",
    "random_forest_location": "RandomForest Weighted Classifier Location"
}
historic_flooding_models = {
    "all_false": "All False",
    "random_classification": "Random Classification",
    "historically_flooded": "HFModel",
    "historically_flooded_rf": "HFRfModel",
    # "historically_flooded_xgb": "HFXGBModel",
    # "historicallt_flooded": "HFModel",
}
house_price_models = {
    "all_england_median": "All England median price",
    "rf_median_price": "Random Forest"
    "(Optimized, Numerical + Categorical + Clusters)"
}
local_authority_models = {
    "modal_local_authority": "Modal Local Authority",
    "rf_local_authority": "Random Forest (Easting/Northing)"
}

IMPUTATION_CONSTANTS = {
    "soilType": "Unsurveyed/Urban",
    "elevation": 60.0,
    "nearestWatercourse": "",
    "distanceToWatercourse": 80,
    "localAuthority": np.nan,
}

DEFAULT_FEATURE_DATA = read_csv_from_example_data("postcodes_unlabelled.csv")
DEFAULT_UNIT_DATA = read_csv_from_resources("postcodes_labelled.csv")
DEFAULT_SECTOR_DATA = read_csv_from_resources("sector_data.csv")
DEFAULT_DISTRICT_DATA = read_csv_from_resources("district_data.csv")

RAW_FEATURES = [
    "postcode",
    "easting",
    "northing",
    "soilType",
    "elevation",
    "nearestWatercourse",
    "distanceToWatercourse",
    "localAuthority",
]


class Tool(object):
    """
    Tool(X=DEFAULT_FEATURE_DATA, unit_data=DEFAULT_UNIT_DATA,
                sector_data=DEFAULT_SECTOR_DATA,
                district_data=DEFAULT_DISTRICT_DATA,
                additional_data={})

                Class to interact with a postcode database file.
    """

    def __init__(
        self,
        X: pd.DataFrame | None = DEFAULT_FEATURE_DATA,
        unit_data: pd.DataFrame = DEFAULT_UNIT_DATA,
        sector_data: pd.DataFrame = DEFAULT_SECTOR_DATA,
        district_data: pd.DataFrame = DEFAULT_DISTRICT_DATA,
        additional_data: dict = {},
    ):
        """


        Parameters
        ----------

        X: DataFrame, optional
            DataFrame containing unlabelled feature data (see the example
            unlabelled postcode data file for the expected format) for use
            in models and lookups.

        unit_data: DataFrame, optional
            DataFrame containing features and class labels for specific
            postcodes.

        sector_data : DataFrame, optional
            DataFrame containing information on households by postcode sector.

        district_data : DataFrame, optional
            DataFrame containing information on households by postcode
            district.

        additional_data: dict, optional
            Dictionary containing additional DataFrames with additional
            information on households.
        """

        self.unit_data = unit_data
        self.sector_data = sector_data
        self.district_data = district_data
        self.additional_data = additional_data

        self._postcodedb = unit_data[RAW_FEATURES].copy()

        if X is not None:
            self._postcodedb = pd.concat([X, self._postcodedb], axis=0)
            self._postcodedb = self._postcodedb.drop_duplicates(
                subset=["postcode"], keep="first"
            )

        # uniform the format of postcode
        self._postcodedb["postcode"] = (
            self._postcodedb["postcode"]
            .astype(str)
            .str.upper()
            # remove most front and behind blankspace
            .str.strip()
            # remove multiple blankspaces into one
            .str.replace(r"\s+", " ", regex=True)
        )
        self._postcodedb = self._postcodedb.set_index("postcode", drop=False)

        # get the coordinate according to postcode
        all_postcodes = self._postcodedb["postcode"].tolist()

        # Use lookup_lat_long function to fetch latitude/longitude
        latlon_df = self.lookup_lat_long(all_postcodes)

        # Store full DataFrame(lat_lon)
        self.latlon = latlon_df

        # lat/lon system(WGS84)
        self.coordinates = latlon_df[[
            "latitude", "longitude"]].to_numpy(dtype=float)
        self.models = {}

        # continue your work here
        if additional_data is None:
            additional_data = {}

        self.additional_data = additional_data

        # Try to load stations.csv automatically if missing
        if "stations" not in self.additional_data:
            try:
                stations_df = read_csv_from_resources("stations.csv")
                self.additional_data["stations"] = stations_df
            except Exception:
                print(
                    "Warning: stations.csv not found in resources"
                    "If needed, pass it via "
                    "Tool(additional_data={'stations': df})."
                )

    def fit_to_data(
        self,
        unit_data: pd.DataFrame | None = None,
        models: str | List[str] = [],
        update_hyperparameters: bool = False,
        **kwargs,
    ):
        """
        fit_to_data(unit_data=None, models=[], update_hyperparameters=False
                    **kwargs)

        Fit/train model or models using the initialised data, optionally
        updating training set and hyperparameters.

        Parameters
        ----------

        unit_data : DataFrame, optional
            DataFrame containing additional features and class labels for
            specific postcodes.
        models : str or list of model keys
            Models to fit/train
        update_hyperparameters : bool, optional
            If True, models may tune their hyperparameters, where
            possible. If False, models will use their default hyperparameters.
        **kwargs : dict, optional
            Additional keyword arguments to pass to model fitting methods.

        Examples
        --------
        >>> tool = Tool()
        >>> fcp_models = list(flood_class_from_postcode_models.keys())
        >>> tool.fit_to_data(fcp_models[0])  # doctest: +SKIP
        >>> classes = tool.predict_flood_class_from_postcode(
        ...    ['M34 7QL'], fcp_models[0])  # doctest: +SKIP
        """

        # Perform any necessary updates to the data

        if unit_data is not None:
            self.unit_data = pd.concat([self.unit_data, unit_data], axis=0)
            self.unit_data = self.unit_data.drop_duplicates(
                subset=["postcode"], keep="last"
            )

            self._postcodedb = pd.concat(
                [self._postcodedb, unit_data[RAW_FEATURES]], axis=0
            )

            self._postcodedb = self._postcodedb.drop_duplicates(
                subset=["postcode"], keep="last"
            )

        if isinstance(models, str):
            models = [models]

        # Do any necessary preprocessing of the data

        # Next fit/train each model in turn
        for model in models:
            if update_hyperparameters:
                print(f"tuning {model} hyperparameters")
            else:
                print(f"training {model}")

                if model == "random_classification":
                    # fitting th model
                    X = self.unit_data[["easting", "northing"]]
                    y = self.unit_data["historicallyFlooded"]
                    self.models[model] = RandomBinaryClassifierModel(
                        seed=42
                    ).fit(X, y)

                elif model == "all_england_median":
                    self.models[model] = AllEnglandMedianPriceModel().fit(
                        None, None
                    )

                elif model == "rf_median_price":
                    """fitting the Random Forest Median Price Model.
                    This include data preprocessing steps like including
                    data from sector and district data, handling missing,
                    clustering with KMeans, and preparing the feature matrix.
                    The clustering with Kmeans is included to capture spatial
                    of the house prices using easting and northing."""
                    df = self.unit_data.copy()
                    self.sector_data["postcodeSector"] = (
                        self.sector_data["postcodeSector"]
                        .astype(str)
                        .str.replace(".0", "", regex=False)
                        .str.strip()
                        .str.replace(r"\s+", " ", regex=True)
                    )

                    self.district_data["postcodeDistrict"] = (
                        self.district_data["postcodeDistrict"]
                        .astype(str)
                        .str.replace(".0", "", regex=False)
                        .str.strip()
                    )

                    if "sector_key" not in df.columns:
                        df["sector_key"] = df["postcode"].apply(
                            lambda x: (
                                x.replace(" ", "").upper()[:-3]
                                + " "
                                + x.replace(" ", "").upper()[-3:]
                            )
                            if isinstance(x, str)
                            else x
                        )

                    if "district_key" not in df.columns:
                        df["district_key"] = df["postcode"].apply(
                            lambda x: x.replace(" ", "").upper()[:-3]
                            if isinstance(x, str)
                            else x
                        )

                    df = df.merge(
                        self.sector_data,
                        left_on="sector_key",
                        right_on="postcodeSector",
                        how="left",
                    )

                    df = df.merge(
                        self.district_data,
                        left_on="district_key",
                        right_on="postcodeDistrict",
                        how="left",
                    )

                    fill_cols = [
                        "headcount",
                        "households",
                        "numberOfPostcodeUnits",
                        "catsPerHousehold",
                        "dogsPerHousehold",
                    ]

                    for col in fill_cols:
                        if col in df.columns:
                            df[col] = df[col].fillna(0)
                        else:
                            df[col] = 0

                    df["petsPerHousehold"] = (
                        df["catsPerHousehold"] + df["dogsPerHousehold"]
                    )

                    df = df.dropna(subset=["medianPrice"])
                    kmeans = KMeans(n_clusters=12,
                                    random_state=42, n_init="auto")
                    df["cluster"] = kmeans.fit_predict(
                        df[["easting", "northing"]])
                    y = np.log1p(df["medianPrice"])

                    num_cols = [
                        "elevation",
                        "distanceToWatercourse",
                        "headcount",
                        "households",
                        "catsPerHousehold",
                        "dogsPerHousehold",
                        "petsPerHousehold",
                        "numberOfPostcodeUnits",
                        "riskLabel",
                        "easting",
                        "northing",
                        "pre_1900",
                        "1900_1929",
                        "1930_1945",
                        "1945_1964",
                        "1965_1982",
                        "1983_1999",
                        "2000_present",
                        "unknown",
                    ]

                    cat_cols = ["soilType", "cluster"]

                    X = df[num_cols + cat_cols]

                    n_estimators = kwargs.pop("n_estimators", 200)
                    print(f"Using n_estimators={n_estimators} for {model}")

                    self.models[model] = RF_MedianPriceModel(
                        num_cols=num_cols,
                        cat_cols=cat_cols,
                        random_state=42,
                    ).fit(X, y)

                    self.models[model].kmeans = kmeans

                elif model == "modal_local_authority":
                    X = self._postcodedb[["easting", "northing"]]
                    y = self._postcodedb["localAuthority"]
                    self.models[model] = ModalLocalAuthorityModel().fit(X, y)

                elif model == "historically_flooded_rf":
                    self.models[model] = HistoricallyFloodedRf(
                        postcodedb=self._postcodedb).fit(self.unit_data)
                # elif model == "historically_flooded_xgb":
                #     self.models[model] = HistoricallyFloodedXgb(
                #         postcodedb=self._postcodedb).fit(self.unit_data)
                # elif model == "historically_flooded":
                #     self.models[model] = HistoricallyFloodedModel(
                #         postcodedb=self._postcodedb).fit(self.unit_data)

                elif model == "rf_local_authority":
                    frame = self._postcodedb[["easting", "northing",
                                              "localAuthority"]].dropna()
                    if frame.empty:
                        raise ValueError("No labelled rows available")
                    X = frame[["easting", "northing"]]
                    y = frame["localAuthority"]
                    self.models[model] = RF_LocalAuthorityModel().fit(X, y)

                elif model == "rf_balanced":
                    # print("training flood risk model")

                    stations = self.additional_data.get("stations")
                    if stations is None:
                        raise ValueError("Pass additional stations dataframe")

                    frame = self.unit_data.dropna(subset=["riskLabel"]).copy()
                    if frame.empty:
                        raise ValueError("No labelled rows")

                    model_i = RandomForestFloodRiskModel(stations_df=stations)
                    model_i.fit(frame, frame["riskLabel"].astype(int))

                    self.models[model] = model_i
                elif model == "random_forest":
                    X = self.unit_data.dropna(subset=["riskLabel"]).copy()

                    y = self.unit_data["riskLabel"]
                    self.models[model] = RandomForestFloodModel().fit(
                        X, y.astype(int))

                elif model == "random_forest_location":
                    X = self.unit_data.dropna(subset=["riskLabel"]).copy()
                    y = self.unit_data["riskLabel"]
                    self.models[model] = RandomForestFloodModel().fit(
                        X, y.astype(int))
                elif model == "historically_flooded":
                    m = HistoricallyFloodedModel()
                    self.models[model] = m.fit(self.unit_data)

    def postcode_cleaner(postcode: Sequence):
        """ Cleans a series of postcodes by removing
        spaces/special chars and converting to uppercase.
        Parameters
        ----------
        postcode : sequence of strs
            Sequence of postcode units.

        Returns
        -------
        pandas.Series
            Series of cleaned postcodes.
        """

        dfp = postcode.astype(str)

        # replace special characters with spaces
        dfp = dfp.str.replace(r'[^A-Za-z0-9]', ' ', regex=True)

        # convert to uppercase
        dfp = dfp.str.upper()

        # transform multiple spaces to single space
        dfp = dfp.str.replace(r'\s+', ' ', regex=True)

        # Robust UK pattern: outward + inward
        dfp = dfp.str.replace(
            r'^([A-Z]{1,2}\d[A-Z\d]?)(\d[A-Z]{2})$',
            r'\1 \2',
            regex=True
        )

        return dfp

    def lookup_easting_northing(
        self, postcodes: Sequence, dtype: np.dtype = np.float64
    ) -> pd.DataFrame:
        """
        lookup_easting_northing(postcodes, dtype=np.float64)

        Get a dataframe of OS eastings and northings from a sequence of
        input postcodes in the labelled or unlabelled datasets.

        Parameters
        ----------

        postcodes: sequence of strs
            Sequence of postcodes.

        dtype: numpy.dtype, optional
            Data type to return the easting and northing columns.
            Default is np.float64 to allow for NaN values.

        Returns
        -------

        pandas.DataFrame
            DataFrame containing columns of 'easthing' and 'northing', for
            the input postcodes. Missing or invalid postcodes (i.e. those not
            in the postcodes supplied, labelled or unlabelled) return as NaNs
            in the latitude and longitude columns.

        Examples
        --------

        >>> tool = Tool()
        >>> results = tool.lookup_easting_northing(['BN3 7QN'])
        >>> results  # doctest: +NORMALIZE_WHITESPACE
                   easting  northing
        BN3 7QN   528161.0  106811.0
        >>> results = tool.lookup_easting_northing(['BN3 7QN', 'AB1 2PQ'])
        >>> results  # doctest: +NORMALIZE_WHITESPACE
                   easting  northing
        BN3 7QN   528161.0  106811.0
        AB1 2PQ        NaN       NaN
        """

        postcodes = pd.Index(postcodes)

        frame = self._postcodedb.copy()
        frame = frame.set_index("postcode")
        frame = frame.reindex(postcodes)

        return frame.loc[postcodes, ["easting", "northing"]].astype(dtype)

    # Function: input a postcode and find its
    # corresponding location in lat_long system
    def lookup_lat_long(
        self, postcodes: Sequence, dtype: np.dtype = np.float64
    ) -> pd.DataFrame:
        """
        lookup_lat_long(postcodes, dtype=np.float64)

        Get a Pandas dataframe containing GPS latitude and longitude
        information for a sequence of postcodes in the labelled or
        unlabelled datasets.

        Parameters
        ----------

        postcodes: sequence of strs
            Sequence of postcodes.

        dtype: numpy.dtype, optional
            Data type of the latitude and longitude columns.

        Returns
        -------

        pandas.DataFrame
            DataFrame containing only WGS84 latitude and longitude pairs for
            the input postcodes. Missing or invalid postcodes (i.e. those not
            in the postcodes supplied, labelled or unlabelled) return as NaNs
            in the latitude and longitude columns.

        Examples
        --------
        >>> tool = Tool()
        >>> tool.lookup_lat_long(['M34 7QL']) # doctest: +SKIP
                latitude  longitude
        postcode
        M34 7QL  53.4461    -2.0997
        """
        # 1. Clean postcodes
        pc_clean = Tool.postcode_cleaner(pd.Series(postcodes))
        pc_clean.index = postcodes  # keep original labels

        # 2. Prefer coordinates from unit_data
        unit = self.unit_data.set_index("postcode").reindex(pc_clean)

        # 3. Fallback to _postcodedb if missing
        db = self._postcodedb.set_index("postcode").reindex(pc_clean)

        # 3. Combine: prefer unit_data eastings/northings
        east = unit["easting"].fillna(db["easting"])
        north = unit["northing"].fillna(db["northing"])

        result = pd.DataFrame(
            index=postcodes,
            columns=["latitude", "longitude"],
            dtype=dtype
        )

        valid = east.notna() & north.notna()

        if valid.any():
            e = east[valid].astype(float).values
            n = north[valid].astype(float).values

            lat, lon = get_gps_lat_long_from_easting_northing(
                e, n, rads=False, dms=False
            )

            result.loc[valid, "latitude"] = lat.astype(dtype)
            result.loc[valid, "longitude"] = lon.astype(dtype)

        return result

    def impute_missing_values(
        self,
        dataframe: pd.DataFrame,
        method: str = "knn",
        constant_values: dict = IMPUTATION_CONSTANTS,
    ) -> pd.DataFrame:
        """
        impute_missing_values(dataframe, method='mean',
                                constant_values=IMPUTATION_CONSTANTS)

        Impute missing values in an unlabelled dataframe.

        Parameters
        ----------

        dataframe : pandas.DataFrame
            DataFrame (in the format of the unlabelled postcode data)
            potentially containing missing values as NaNs, or with missing
            columns.

        method : str, optional
            Method to use for imputation. Options include:
            * ``'mean'``, to use the mean for the labelled dataset
            * ``'constant'``, to use a constant value for imputation
            * ``'knn'`` to use k-nearest neighbours imputation from the
              labelled dataset

        constant_values : dict, optional
            Dictionary containing constant values to
            use for imputation in the format ``{column_name: value}``.
            Only used if method is ``'constant'``.

        Returns
        -------

        pandas.DataFrame
            DataFrame with missing values imputed.

        Examples
        --------

        >>> tool = Tool()
        >>> data = read_csv_from_example_data('postcodes_missing_data.csv')
        >>> full_data = tool.impute_missing_values(data)  # doctest: +SKIP
        """
        df = dataframe.copy()
        constant_values = constant_values or {}

        if method in ["mean", "median"]:
            for col in df.columns:
                if df[col].dtype.kind in 'bifc' and df[col].isna().any():
                    value = (self.unit_data[col].mean() if method == "mean"
                             else self.unit_data[col].median())
                    df[col] = df[col].fillna(value)
            return df

        elif method == "knn":
            num_cols = df.select_dtypes(include='number').columns.tolist()

            if len(num_cols) == 0:
                return df  # nothing to impute

            # Stack labelled numeric data on top of unlabelled numeric data
            labelled_num = self.unit_data[num_cols]
            unlabelled_num = df[num_cols]

            combined_num = pd.concat(
                [labelled_num, unlabelled_num], axis=0, ignore_index=True)

            imputer = KNNImputer(n_neighbors=5)
            imputed_array = imputer.fit_transform(combined_num)

            # Convert back to DataFrame with proper columns and index
            imputed_df = pd.DataFrame(imputed_array, columns=num_cols)

            # Replace only the unlabelled part
            df[num_cols] = imputed_df.iloc[len(
                labelled_num):].reset_index(drop=True).values

        return df

# ----Model required for the following functions----
    def predict_flood_class_from_postcode(
        self, postcodes: Sequence[str], model: str = "all_minimum_risk"
    ) -> pd.Series:
        """
        Generate series predicting flood probability classification
        for a collection of poscodes.

        Parameters
        ----------

        postcodes : sequence of strs
            Sequence of postcode units.
        model : str (optional)
            optionally specify (via a key in the
            ``flood_class_from_postcode_models`` dict) the classification
            model to be used.

        Returns
        -------

        pandas.Series
            Series of flood risk classification labels indexed by postcodes.
            Returns NaN for invalid postcodes.
        """

        pc_clean = Tool.postcode_cleaner(pd.Series(postcodes)).tolist()

        if model == "all_minimum_risk":
            # Do matching call to model
            # Might involve feature lookup or other preprocessing here

            model_instance = AllMinimumRiskModel()  # No training required

            return model_instance.predict_from_postcodes(pc_clean)

        elif model == "rf_balanced":
            model_instance = self.models[model]

            # extract postcode rows - return nan (dont break) for invalids
            df = self._postcodedb.set_index("postcode").reindex(pc_clean)
            df = df.copy()

            # predict
            preds = model_instance.predict(df)

            return pd.Series(preds, index=postcodes)
        elif model == "random_forest":
            model_instance = self.models[model]
            # extract postcode rows
            postcodes = Tool.postcode_cleaner(postcodes)
            pc_list = list(postcodes)
            df = self.unit_data.set_index("postcode").reindex(pc_list).copy()
            # predict
            preds = model_instance.predict(df)

            return pd.Series(preds, index=postcodes)

    def predict_flood_class_from_OSGB36_location(
        self,
        eastings: Sequence[float],
        northings: Sequence[float],
        model: str = "all_minimum_risk",
    ) -> pd.Series:
        """
        Generate series predicting flood probability classification
        for a collection of locations given as eastings and northings
        on the Ordnance Survey National Grid (OSGB36) datum.
        """

        if model == "all_minimum_risk":
            # Create a MultiIndex for the coordinates
            idx = pd.MultiIndex.from_arrays(
                [eastings, northings], names=["easting", "northing"]
            )
            model_instance = AllMinimumRiskModel()  # No training required
            return model_instance.predict_from_locations(idx)
        elif model == "random_forest_location":
            model_instance = self.models["random_forest_location"]

            eastings = pd.Series(eastings).astype(float)
            northings = pd.Series(northings).astype(float)
            coord_idx = pd.MultiIndex.from_arrays(
                [eastings, northings],
                names=["easting", "northing"],
            )

            df = (self.unit_data
                  .set_index(["easting", "northing"])
                  .reindex(coord_idx)
                  .reset_index())

            missing_mask = df.isna().all(axis=1)
            df = df.loc[~missing_mask].copy()

            # prediction
            preds = model_instance.predict(df)

            clean_idx = coord_idx[~missing_mask]
            return pd.Series(preds, index=clean_idx)
        else:
            raise NotImplementedError(f"model {model} not implemented")

    def predict_flood_class_from_WGS84_locations(
        self,
        longitudes: Sequence[float],
        latitudes: Sequence[float],
        model: str = "all_minimum_risk",
    ) -> pd.Series:
        """
        Generate series predicting flood probability classification
        for a collection of WGS84 datum locations.

        Parameters
        ----------

        longitudes : sequence of floats
            Sequence of WGS84 longitudes.
        latitudes : sequence of floats
            Sequence of WGS84 latitudes.
        model : str (optional)
            optionally specify (via a key in
            ``flood_class_from_location_models`` ``dict``) the classification
            model to be used.

        Returns
        -------

        pandas.Series
            Series of flood risk classification labels multi-indexed by
            location as a longitude, latitude pair.
        """

        if model == "all_minimum_risk":
            # Do matching call to model
            idx = pd.MultiIndex.from_arrays(
                [longitudes, latitudes], names=["longitude", "latitude"]
            )
            model_instance = (
                AllMinimumRiskModel()
            )  # No training required so can instantiate here
            return model_instance.predict_from_locations(idx)
        elif model == "random_forest_location":
            idx = pd.MultiIndex.from_arrays(
                [longitudes, latitudes], names=["longitude", "latitude"]
            )
            eastings, northings = get_easting_northing_from_gps_lat_long(idx)
            model_instance = self.models["random_forest_location"]

            eastings = pd.Series(eastings).astype(float)
            northings = pd.Series(northings).astype(float)

            coord_idx = pd.MultiIndex.from_arrays(
                [eastings, northings],
                names=["eastings", "northings"],
            )

            df = (self.unit_data
                  .set_index(["eastings", "northings"])
                  .reindex(coord_idx)
                  .reset_index())

            missing_mask = df.isna().all(axis=1)
            df = df.loc[~missing_mask].copy()

            # prediction
            preds = model_instance.predict(df)

            clean_idx = coord_idx[~missing_mask]
            return pd.Series(preds, index=clean_idx)
        else:
            raise NotImplementedError(f"model {model} not implemented")

    def predict_median_house_price(
        self, postcodes: Sequence[str], model: str = "all_england_median"
    ) -> pd.Series:
        """
        Generate a Pandas Series containing predicted median house price for an
        input sequence of postcodes.

        Parameters
        ----------

        postcodes : sequence of strs
            Sequence of postcode units.
        model : str (optional)
            optionally specify (via a key in the
            ``median_house_price_models`` ``dict``) the regression
            model to be used.

        Returns
        -------

        pandas.Series
            Series of median house price estimates indexed by postcodes.
        """

        if model == "all_england_median":
            # No training required, so can instantiate here
            model_instance = AllEnglandMedianPriceModel()

            return model_instance.predict_from_postcodes(postcodes)
        elif model == "rf_median_price":
            if model not in self.models:
                print(f"Model '{model}' is not trained. Training now...")
                try:
                    self.fit_to_data(models=[model], n_estimators=5)
                except Exception as e:
                    # Raise a more informative error if training fails
                    raise RuntimeError(
                        f"Failed to auto-train model '{model}'. "
                        "Ensure 'unit_data' is not empty and "
                        "required additional data is loaded. "
                        f"Original error: {e}"
                    )

            """Predict median house prices using the Random Forest
            Median Price Model. This include data preprocessing steps like
            including data from sector and district data, handling missing,
            clustering with KMeans, and preparing the feature matrix."""
            cond = self._postcodedb["postcode"].isin(postcodes)
            df = self._postcodedb[cond].copy()
            # 2. Prepare Feature DataFrame
            df = df.set_index("postcode").reindex(postcodes).reset_index()
            if df.empty or df["easting"].isnull().all():
                return pd.Series(data=np.nan, index=postcodes)
            df["sector_key"] = df["postcode"].apply(
                lambda x: str(x).replace(" ", "").upper()[:-3]
                + " "
                + str(x).replace(" ", "").upper()[-3]
                if pd.notnull(x)
                else x
            )
            df["district_key"] = df["postcode"].apply(
                lambda x: str(x).replace(" ", "").upper()[:-3]
                if pd.notnull(x) else x
            )

            df = df.merge(
                self.sector_data,
                left_on="sector_key",
                right_on="postcodeSector",
                how="left",
            )
            df = df.merge(
                self.district_data,
                left_on="district_key",
                right_on="postcodeDistrict",
                how="left",
            )

            # 4. Handle Missing Data / Fill NaNs (Same as training)
            fill_cols = [
                "headcount",
                "households",
                "numberOfPostcodeUnits",
                "catsPerHousehold",
                "dogsPerHousehold",
            ]
            for col in fill_cols:
                if col in df.columns:
                    df[col] = df[col].fillna(0)
                else:
                    df[col] = 0

            df["petsPerHousehold"] = df["catsPerHousehold"] + df[
                "dogsPerHousehold"]

            # 6. Apply the Trained KMeans Clusterer
            kmeans = self.models["rf_median_price"].kmeans
            # Here to keep the shape aligned.
            loc_cols = df[["easting", "northing"]].fillna(0)
            df["cluster"] = kmeans.predict(loc_cols)

            # 7. Prepare Final Feature Matrix
            num_cols = [
                "elevation",
                "distanceToWatercourse",
                "headcount",
                "households",
                "catsPerHousehold",
                "dogsPerHousehold",
                "petsPerHousehold",
                "numberOfPostcodeUnits",
                "riskLabel",
                "easting",
                "northing",
                "pre_1900",
                "1900_1929",
                "1930_1945",
                "1945_1964",
                "1965_1982",
                "1983_1999",
                "2000_present",
                "unknown",
            ]
            cat_cols = ["soilType", "cluster"]

            # Ensure all columns exist
            for col in num_cols:
                if col not in df.columns:
                    df[col] = 0
            for col in cat_cols:
                if col not in df.columns:
                    df[col] = "unknown"
            X = df[num_cols + cat_cols]
            # 8. Predict
            X.index = df["postcode"]
            return self.models["rf_median_price"].predict_gbp(X)
        else:
            raise NotImplementedError(f"model {model} not implemented")

    def predict_high_risk_near_watercourses(
        self,
        watercourse_names: Sequence[str],
        postcodes: Sequence[str] | None = None,
        risk_above: int = 4
    ) -> pd.DataFrame:
        """
        Generate a DataFrame of unit areas with flood risk above a threshold
        that are near specified watercourses.

        Parameters
        ----------

        watercourse_names : sequence of strs
            Sequence of watercourse names to report nearby high-risk areas for.

        postcodes : sequence of strs or None, optional
            Sequence of postcode units to report on.

        risk_above : int, optional
            Threshold flood risk level above which to report areas.

        Returns

        pandas.DataFrame
            DataFrame of postcode units with flood risk above the specified
            threshold that are near the specified watercourses. Columns are
            the standard feature columns plus a 'riskLabel' column.
        """
        # 0. ensure RF model exists, if not train it automatically
        if "rf_balanced" not in self.models:
            stations = self.additional_data.get("stations")
            if stations is None:
                raise ValueError("Please pass additional stations df")

            frame = self.unit_data.dropna(subset=["riskLabel"]).copy()
            if frame.empty:
                raise ValueError("No labelled rows available for RF model.")

            model_i = RandomForestFloodRiskModel(stations_df=stations)
            model_i.fit(frame, frame["riskLabel"].astype(int))
            self.models["rf_balanced"] = model_i

        # 1. if no postcodes provided, use all given
        if postcodes is None:
            postcodes = self._postcodedb.postcode.tolist()

        # Clean postcodes
        pc_clean = Tool.postcode_cleaner(pd.Series(postcodes))

        # 2. Retrieve rows from main data
        df_raw = (
            self._postcodedb
            .set_index("postcode")
            .reindex(pc_clean)
            .reset_index()
            .rename(columns={"index": "postcode"})
        )

        if df_raw.empty:
            print('No high risk areas found near specified watercourses.')
            return pd.DataFrame()  # empty dataframe

        # 3. Apply feature engineering
        model_instance = self.models["rf_balanced"]
        feat_eng = model_instance.pipeline.named_steps["feat_eng"]
        df_eng = feat_eng.transform(df_raw.copy())
        df_eng["postcode"] = df_raw["postcode"].values  # ensure postcode exist

        # 4. Predict flood risk labels using trained model above
        preds = self.predict_flood_class_from_postcode(
            df_eng["postcode"],
            model="rf_balanced"
        )
        df_eng["predictedRisk"] = preds.values

        # 5. Filter by pred risk threshold
        df_filtered = df_eng[df_eng["predictedRisk"] > risk_above]  # exclude
        if df_filtered.empty:
            return df_filtered

        # 6. Filter by nearest watercourses
        patterns = [wc.lower() for wc in watercourse_names]

        df_filtered = df_filtered[
            df_filtered["nearestWatercourse"]
            .astype(str)
            .str.lower()
            .isin(patterns)
        ]

        # return sorted - high first
        return df_filtered.sort_values("predictedRisk", ascending=False)

    def predict_local_authority(
        self,
        eastings: Sequence[float],
        northings: Sequence[float],
        model: str = "modal_local_authority",
    ) -> pd.Series:
        """
        Generate a Pandas Series predicting local authorities for a sequence
        of OSGB36 locations.

        Parameters
        ----------

        eastings : sequence of floats
            Sequence of OSGB36 eastings.
        northings : sequence of floats
            Sequence of OSGB36 northings.
        model : str (optional)
            optionally specify (via a key in the
            ``local_authority_models`` ``dict``) the classification
            model to be used.

        Returns
        -------

        pandas.Series
            Series of predicted local authorities for the input
            locations, and multi-indexed by the location as a
            an easting and northing.
        """

        if model == "modal_local_authority":
            idx = pd.MultiIndex.from_tuples(
                [(est, nth) for est, nth in zip(eastings, northings)]
            )
            return self.models["modal_local_authority"].predict_from_location(
                idx
            )

        elif model == "rf_local_authority":
            idx = pd.MultiIndex.from_tuples(
                [(est, nth) for est, nth in zip(eastings, northings)]
            )
            return self.models["rf_local_authority"].predict_from_location(idx)

        else:
            raise NotImplementedError(f"model {model} not implemented")

    def predict_historic_flooding(
        self, postcodes: Sequence[str], model: str = "all_false"
    ) -> pd.Series:
        """
        Generate series predicting whether a collection of postcodes
        has experienced historic flooding.

        Parameters
        ----------

        postcodes : sequence of strs
            Sequence of postcode units.
        model : str (optional)
            optionally specify (via a key in the
            ``historic_flooding_models`` ``dict``) the classification
            model to be used.

        Returns
        -------

        pandas.Series
            Series indicating whether a postcode experienced historic
            flooding, indexed by the postcodes.
        """

        if model == "all_false":
            model_instance = AllFalseModel()  # No training required
            return model_instance.predict(postcodes)
        elif model == "random_classification":
            return self.models["random_classification"].predict(postcodes)
        elif model == "historically_flooded":
            return self.models["historically_flooded"].predict(
                postcodes, self._postcodedb)
            return self.models["random_classification"].predict(
                postcodes, self._postcodedb)
        elif model == "historically_flooded_rf":
            return self.models["historically_flooded_rf"].predict(
                postcodes, self._postcodedb)
        # elif model == "historically_flooded_xgb":
        #     return self.models["historically_flooded_xgb"].predict(
        # #         postcodes, self._postcodedb)
        # elif model == "historically_flooded":
        #     return self.models["historically_flooded"].predict(
        #         postcodes, self._postcodedb)
        else:
            raise NotImplementedError(f"model {model} not implemented")

    def estimate_total_value(self, postal_data: Sequence[str]) -> pd.Series:
        """
        Return a series of estimates of the total property values
        of a sequence of postcode units or postcode sectors.
        The estimate is based on the median house price for the area and an
        estimate of the number of properties it contains.
        Parameters
        ----------

        postal_data : sequence of strs
            Sequence of postcode units or postcode sectors (either
            may be used).

        Returns
        -------

        pandas.Series
            Series of total property value estimates indexed by locations.
        """

        # Ensure 'postcode' column exists (recover if only index)
        if (
            "postcode" not in self._postcodedb.columns
            and self._postcodedb.index.name == "postcode"
        ):
            self._postcodedb = self._postcodedb.reset_index()

        cleaned_postcodes = Tool.postcode_cleaner(pd.Series(postal_data))
        df = pd.DataFrame({"postcode": cleaned_postcodes})

        # Determine if postcode is a sector (e.g., 'AA1 1') or full postcode
        sector_pattern = r"^[A-Z]{1,2}\d[A-Z\d]? \d$"
        df["is_sector"] = df["postcode"].str.match(sector_pattern)

        # Lookup households for sectors directly
        df["households"] = df["postcode"].where(df["is_sector"], None)
        df.loc[df["is_sector"], "households"] = df.loc[
            df["is_sector"],
            "postcode"
        ].map(
            lambda x: float(
                self.sector_data.loc[
                    self.sector_data["postcodeSector"] == x, "households"
                ]
            )
            if x in self.sector_data["postcodeSector"].values
            else float("nan")
        )

        full_pcm = ~df["is_sector"]
        # Extract sector from full postcode
        full_postcodes = df.loc[full_pcm, "postcode"]
        # Regex to extract outward + sector digit
        sector_series = full_postcodes.str.replace(
            r"^([A-Z]{1,2}\d[A-Z\d]?) (\d)[A-Z]{2}$", r"\1 \2", regex=True
        )

        def houses_per_unit(sector):
            if sector in self.sector_data["postcodeSector"].values:
                row = self.sector_data.loc[
                    self.sector_data["postcodeSector"] == sector
                ].iloc[0]
                n_hh = float(row["households"])
                n_pu = float(row["numberOfPostcodeUnits"])
                return n_hh / n_pu
            else:
                return float("nan")

        df.loc[full_pcm, "households"] = sector_series.map(houses_per_unit)
        df.set_index("postcode", inplace=True)

        if "rf_median_price" not in self.models:
            model_to_test = "all_england_median"
        else:
            model_to_test = "rf_median_price"

        median_prices = self.predict_median_house_price(
            postal_data, model=model_to_test
        )
        df = pd.concat([df, median_prices.rename("median_price")], axis=1)
        df["households"] = df["households"].astype(float)

        # Step 7: Compute total property value
        total_values = df["households"] * df["median_price"]

        return total_values

    def estimate_annual_human_flood_risk(
        self, postcodes: Sequence[str], risk_labels: pd.Series | None = None
    ) -> pd.Series:
        """
        Return a series of estimates of the risk to human life for a
        collection of postcodes.

        Risk is defined here as an impact coefficient multiplied by the
        estimated number of people under threat multiplied by the probability
        of an event.

        Parameters
        ----------

        postcodes : sequence of strs
            Sequence of postcode units.
        risk_labels: pandas.Series (optional)
            Series containing flood risk classifiers, as
            predicted by ``predict_flood_class_from_postcode``.

        Returns
        -------

        pandas.Series
            Series of total annual human flood risk estimates
            indexed by postcode.
        """
        # 0. ensure RF model exists, if not train it automatically
        if "rf_balanced" not in self.models:
            stations = self.additional_data.get("stations")
            if stations is None:
                raise ValueError("Please pass additional stations df")

            frame = self.unit_data.dropna(subset=["riskLabel"]).copy()
            if frame.empty:
                raise ValueError("No labelled rows available for RF model.")

            model_i = RandomForestFloodRiskModel(stations_df=stations)
            model_i.fit(frame, frame["riskLabel"].astype(int))
            self.models["rf_balanced"] = model_i

        # Ensure 'postcode' column exists (recover if only index)
        if (
            "postcode" not in self._postcodedb.columns
            and self._postcodedb.index.name == "postcode"
        ):
            self._postcodedb = self._postcodedb.reset_index()

        cleaned_postcodes = Tool.postcode_cleaner(pd.Series(postcodes))
        df = pd.DataFrame({"postcode": cleaned_postcodes})
        if df.empty:
            return pd.Series(dtype=float, index=cleaned_postcodes)

        # Identify sectors
        sector_pattern = r"^[A-Z]{1,2}\d[A-Z\d]? \d$"
        df["is_sector"] = df["postcode"].str.match(sector_pattern)

        df["headcount"] = (
            np.nan
        )
        df.loc[df["is_sector"], "headcount"] = df.loc[
            df["is_sector"],
            "postcode"
        ].map(
            lambda x: float(
                self.sector_data.loc[
                    self.sector_data["postcodeSector"] == x, "headcount"
                ]
            )
            if x in self.sector_data["postcodeSector"].values
            else float("nan")
        )

        full_mask = ~df["is_sector"]
        full_postcodes = df.loc[full_mask, "postcode"]

        # Extract sector from full postcode
        sectors = full_postcodes.str.replace(
            r"^([A-Z]{1,2}\d[A-Z\d]?) (\d)[A-Z]{2}$", r"\1 \2", regex=True
        )

        # Look up population per postcode unit
        def population_per_unit(sector):
            if sector in self.sector_data["postcodeSector"].values:
                row = self.sector_data.loc[
                    self.sector_data["postcodeSector"] == sector
                ].iloc[0]

                hc = float(row["headcount"])
                nop = float(row["numberOfPostcodeUnits"])
                return hc / nop
            else:
                return float("nan")

        df.loc[full_mask, "headcount"] = sectors.map(population_per_unit)
        df.set_index("postcode", inplace=True)

        if risk_labels is None:
            risk_labels = self.predict_flood_class_from_postcode(
                postcodes, model="rf_balanced"
            )
        risk_labels = risk_labels.reindex(cleaned_postcodes)

        i_c = 0.1
        df = pd.concat([df, risk_labels.rename("risk_label")], axis=1)
        df["risk_label"] = df["risk_label"].astype(float)

        human_risk = df["headcount"] * df["risk_label"] * i_c
        # human_risk.index = cleaned_postcodes
        return human_risk

    def estimate_annual_economic_flood_risk(
        self, postcodes: Sequence[str], risk_labels: pd.Series | None = None
    ) -> pd.Series:
        """
        Return a series of estimates of the total economic property risk
        for a collection of postcodes.

        Risk is defined here as a damage coefficient multiplied by the
        value under threat multiplied by the probability of an event.

        Parameters
        ----------

        postcodes : sequence of strs
            Sequence of postcode units.
        risk_labels: pandas.Series (optional)
            optionally provide a Pandas Series containing flood risk
            classifiers, as predicted by ``predict_flood_class_from_postcode``.

        Returns
        -------

        pandas.Series
            Series of total annual economic flood risk estimates indexed
            by postcode.
        """
        # 0. ensure RF model exists, if not train it automatically
        if "rf_balanced" not in self.models:
            stations = self.additional_data.get("stations")
            if stations is None:
                raise ValueError("Please pass additional stations df")

            frame = self.unit_data.dropna(subset=["riskLabel"]).copy()
            if frame.empty:
                raise ValueError("No labelled rows available for RF model.")

            model_i = RandomForestFloodRiskModel(stations_df=stations)
            model_i.fit(frame, frame["riskLabel"].astype(int))
            self.models["rf_balanced"] = model_i

        if (
            "postcode" not in self._postcodedb.columns
            and self._postcodedb.index.name == "postcode"
        ):
            self._postcodedb = self._postcodedb.reset_index()

        cleaned_postcodes = Tool.postcode_cleaner(pd.Series(postcodes))
        df = pd.DataFrame({"postcode": cleaned_postcodes})
        total_values = self.estimate_total_value(list(cleaned_postcodes))

        if risk_labels is None:
            risk_labels = self.predict_flood_class_from_postcode(
                postcodes, model="rf_balanced"
            )
        risk_labels = risk_labels.reindex(cleaned_postcodes)

        d_c = 0.05
        df = pd.concat(
            [
                risk_labels.rename("risk_label"),
                total_values.rename("total_value"),
            ],
            axis=1,
        )
        # Compute economic risk
        economic_risk = df["total_value"] * df["risk_label"] * d_c

        return economic_risk
