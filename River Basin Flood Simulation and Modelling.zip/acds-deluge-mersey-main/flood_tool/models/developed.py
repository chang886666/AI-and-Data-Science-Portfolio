# from flood_tool.models.pipelines import LA_pipeline
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler, RobustScaler, OneHotEncoder
from sklearn.preprocessing import FunctionTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import TargetEncoder
from sklearn.utils.class_weight import compute_class_weight
from sklearn.impute import KNNImputer, SimpleImputer
from .preprocessing import FeatureEngineeringTransformer


class RF_LocalAuthorityModel:
    def __init__(
        self,
        pipeline: Pipeline | None = None,
        random_state: int = 42,
    ):
        self.pipeline = pipeline or Pipeline(
            [
                ("imputer", SimpleImputer(strategy="median")),
                ("scaler", StandardScaler()),
                ("clf", RandomForestClassifier(random_state=random_state)),
            ]
        )

    def fit(self, X: pd.DataFrame, y: pd.Series):
        # Expect X with columns ['easting','northing']
        self.pipeline.fit(X[["easting", "northing"]], y)
        return self

    def predict_from_location(self, idx: pd.MultiIndex) -> pd.Series:
        try:
            eastings = idx.get_level_values("easting")
            northings = idx.get_level_values("northing")
        except KeyError:
            eastings = idx.get_level_values(0)
            northings = idx.get_level_values(1)
        X = pd.DataFrame({
            "easting": pd.to_numeric(eastings, errors="coerce"),
            "northing": pd.to_numeric(northings, errors="coerce")},
            index=idx)
        yhat = self.pipeline.predict(X)
        return pd.Series(yhat, index=idx, name="local_authority")


class RandomForestFloodRiskModel:
    """
    Pipeline for flood risk classification using a
    Random Forest classifier with feature engineering and
    preprocessing steps.
    """

    def __init__(self, stations_df, random_state=42):

        # Feature groups
        num_plain = ["elevation", "minMaxAmplitude", "typicalRangeAmplitude"]
        num_skewed = ["distanceToWatercourse", "distanceToStation"]
        geo_features = ["latitude", "longitude"]
        cat_features = ["soilType"]

        # Pipelines
        log_t = FunctionTransformer(np.log1p, validate=False)

        num_plain_pipe = Pipeline([
            ("impute", SimpleImputer(strategy="constant", fill_value=np.nan)),
            ("scale", RobustScaler())
        ])

        num_skewed_pipe = Pipeline([
            ("log", log_t),
            ("scale", RobustScaler())
        ])

        cat_pipe = Pipeline([
            ("impute", SimpleImputer(
                strategy="constant",
                fill_value="unknown"
            )),
            ("encode", TargetEncoder(smooth=10))
        ])

        preprocessor = ColumnTransformer(
            transformers=[
                ("num_plain", num_plain_pipe, num_plain),
                ("num_skewed", num_skewed_pipe, num_skewed),
                ("geo", "passthrough", geo_features),  # skip so not dropped
                ("cat", cat_pipe, cat_features)
            ],
            remainder="drop"
        )

        # Store needed later
        self.stations_df = stations_df
        self.preprocessor = preprocessor
        self.random_state = random_state

        # will build the classifier in fit
        self.pipeline = None

    def fit(self, X, y):
        # Compute class weights here where we have y
        classes = np.unique(y)
        weights = compute_class_weight(
            class_weight="balanced",
            classes=classes,
            y=y
        )

        # Add class weights because imbalanced still
        weights = [1, 1, 1.5, 1.5, 12, 30, 40]

        # Create classifier with computed weights
        rf = RandomForestClassifier(
            n_estimators=600,
            max_depth=None,
            class_weight=dict(zip(classes, weights)),
            random_state=self.random_state,
            n_jobs=-1
        )

        # Build full pipeline with classifier
        self.pipeline = Pipeline([
            ("feat_eng", FeatureEngineeringTransformer(self.stations_df)),
            ("preprocess", self.preprocessor),
            ("clf", rf)
        ])

        # Fit pipeline
        self.pipeline.fit(X, y)
        return self

    def predict(self, X):
        preds = self.pipeline.predict(X)
        return np.clip(preds, 1, 7).astype(int)


class RF_MedianPriceModel:
    def __init__(
        self,
        num_cols: list,
        cat_cols: list,
        pipeline: Pipeline | None = None,
        random_state: int = 42,
        n_estimators: int = 120,
        min_samples_split: int = 4,
        min_samples_leaf: int = 2,
    ):
        """Random Forest model to predict median house prices.
        this include the pipeline for preprocessing
        numerical and categorical features. Also
        includes hyperparameters for the Random Forest model."""
        self.num_cols = num_cols
        self.cat_cols = cat_cols

        self.pipeline = pipeline or Pipeline(
            [
                (
                    "preprocessor",
                    ColumnTransformer(
                        transformers=[
                            (
                                "num",
                                Pipeline(
                                    [
                                        (
                                            "impute",
                                            SimpleImputer(strategy="median")
                                        ),
                                        (
                                            "identity",
                                            FunctionTransformer(lambda x: x)
                                        ),
                                    ]
                                ),
                                self.num_cols,
                            ),
                            (
                                "cat",
                                Pipeline(
                                    [
                                        (
                                            "impute",
                                            SimpleImputer(
                                                strategy="most_frequent"
                                            )
                                        ),
                                        (
                                            "ohe",
                                            OneHotEncoder(
                                                handle_unknown="ignore",
                                                sparse_output=False
                                            ),
                                        ),
                                    ]
                                ),
                                self.cat_cols,
                            ),
                        ]
                    ),
                ),
                (
                    "model",
                    RandomForestRegressor(
                        n_estimators=n_estimators,
                        min_samples_split=min_samples_split,
                        min_samples_leaf=min_samples_leaf,
                        n_jobs=-1,
                        random_state=random_state,
                    ),
                ),
            ]
        )

    def fit(self, X: pd.DataFrame, y: pd.Series):
        """this is to fit the Random Forest model with the pipeline."""
        self.pipeline.fit(X, y)
        return self

    def predict(self, X: pd.DataFrame) -> pd.Series:
        """Predict median house prices in log scale.
        the reason of using log scale is because the
        target variable is highly skewed and does not
        provide a good result in original scale."""
        y_pred_log = self.pipeline.predict(X)
        return pd.Series(y_pred_log, index=X.index, name="medianPrice_log")

    def predict_gbp(self, X: pd.DataFrame) -> pd.Series:
        """Predict median house prices in GBP where
        the log transformation is reversed."""
        y_pred_log = self.pipeline.predict(X)
        return pd.Series(
            np.expm1(y_pred_log), index=X.index, name="medianPrice_gbp"
        )


class RandomForestFloodModel:
    def __init__(self, random_state=42):
        self.random_state = random_state
        self.pipeline = None
        self.preprocessor = None

    def fit(self, X, y):
        # Remove columns
        X = X.drop(columns=["nearestWatercourse", "postcode"])

        # detect cols AFTER X exists
        num_cols = X.select_dtypes(include="number").columns.tolist()
        cat_cols = X.select_dtypes(include="object").columns.tolist()

        num_pipe = Pipeline([
            ("imputer", KNNImputer(n_neighbors=8)),
            ("scaler", RobustScaler())
        ])

        cat_pipe = Pipeline([
            ("imputer", SimpleImputer(strategy="constant",
                                      fill_value="missing")),
            ("target_encoder", TargetEncoder(smooth=10))
        ])

        self.preprocessor = ColumnTransformer(
            transformers=[
                ("num", num_pipe, num_cols),
                ("cat", cat_pipe, cat_cols)
            ],
            remainder="drop"
        )

        class_weight = {
            1: 100, 2: 100, 3: 150, 4: 150,
            5: 150, 6: 1500, 7: 3000
        }

        rf = RandomForestClassifier(
            n_estimators=600,
            max_depth=None,
            class_weight=class_weight,
            random_state=self.random_state,
            n_jobs=-1
        )

        self.pipeline = Pipeline([
            ("preprocess", self.preprocessor),
            ("clf", rf)
        ])

        self.pipeline.fit(X, y)
        return self

    def predict(self, X):
        preds = self.pipeline.predict(X)
        return np.clip(preds, 1, 7).astype(int)
