import pandas as pd
import numpy as np
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer, KNNImputer
from sklearn.preprocessing import StandardScaler, TargetEncoder

from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import precision_recall_curve
from sklearn.model_selection import train_test_split

HF_NUM_COLS = ["easting", "northing", "elevation", "distanceToWatercourse"]
HF_CAT_COLS = ["soilType", "localAuthority"]
HF_FEATURE_COLS = HF_NUM_COLS + HF_CAT_COLS


def _normalize_postcodes(pcs):
    s = pd.Series(pcs, dtype=str)
    s = s.str.upper().str.strip()
    return s.str.replace(r"\s+", " ", regex=True)


def _build_preprocessor():
    return ColumnTransformer(
        transformers=[
            ("num", Pipeline(steps=[
                ("knn", KNNImputer(n_neighbors=5)),
                ("scaler", StandardScaler(with_mean=False)),
            ]), HF_NUM_COLS),
            ("cat", Pipeline(steps=[
                ("imputer", SimpleImputer(strategy="constant",
                                          fill_value="missing")),
                ("target_encoder", TargetEncoder(smooth=10)),
            ]), HF_CAT_COLS),
        ],
        remainder="drop", verbose_feature_names_out=False,
    )


def _prepare_data(unit_df):
    target_col = "historicallyFlooded"
    df = unit_df[HF_FEATURE_COLS + [target_col]].copy()
    df = df.dropna(subset=[target_col])
    X = df[HF_FEATURE_COLS]
    y = df[target_col].astype(int)
    return X, y


class HistoricallyFloodedRf:
    def __init__(self, postcodedb=None, random_state=42,
                 target_recall=None, target_precision=None,
                 n_estimators=800, max_depth=None, min_samples_leaf=10,
                 class_weight="balanced"):
        self._postcodedb = postcodedb
        self.feature_cols = HF_FEATURE_COLS
        self.random_state = random_state
        self.target_recall = target_recall
        self.target_precision = target_precision
        self.threshold = 0.5

        pre = _build_preprocessor()
        clf = RandomForestClassifier(
            n_estimators=n_estimators,
            max_depth=max_depth,
            min_samples_leaf=min_samples_leaf,
            random_state=random_state,
            n_jobs=-1,
            class_weight=class_weight,
        )
        self.pipe = Pipeline([("preprocessor", pre), ("classifier", clf)])

    def fit(self, unit_df):
        X, y = _prepare_data(unit_df)
        X_tr, X_va, y_tr, y_va = train_test_split(
            X, y, test_size=0.2, random_state=self.random_state, stratify=y
        )
        self.pipe.fit(X_tr, y_tr)

        if hasattr(self.pipe.named_steps["classifier"], "predict_proba"):
            proba = self.pipe.predict_proba(X_va)[:, 1]
            prec, rec, thr = precision_recall_curve(y_va, proba)

            f1 = (2 * (prec[:-1] * rec[:-1])) / (prec[:-1] + rec[:-1] + 1e-12)
            best = float(thr[int(np.argmax(f1))])

            if self.target_recall is not None:
                mask_r = rec[:-1] >= float(self.target_recall)
                if mask_r.any():
                    best = float(thr[int(np.argmax(prec[:-1][mask_r]))])
            if self.target_precision is not None:
                mask_p = prec[:-1] >= float(self.target_precision)
                if mask_p.any():
                    best = float(thr[int(np.argmax(rec[:-1][mask_p]))])

            self.threshold = best
        else:
            self.threshold = 0.3

        return self

    def predict(self, postcodes, postcodedb):
        cols = ["postcode"] + self.feature_cols
        frame = postcodedb[cols].copy()
        frame.set_index("postcode", inplace=True)

        pcs = _normalize_postcodes(postcodes)
        X_pred = frame.reindex(pcs)[self.feature_cols]
        if hasattr(self.pipe.named_steps["classifier"], "predict_proba"):
            proba = self.pipe.predict_proba(X_pred)[:, 1]
            y_hat = (proba >= float(self.threshold)).astype(bool)
        else:
            y_hat = self.pipe.predict(X_pred).astype(bool)
        return pd.Series(y_hat, index=X_pred.index, name="historicallyFlooded")
