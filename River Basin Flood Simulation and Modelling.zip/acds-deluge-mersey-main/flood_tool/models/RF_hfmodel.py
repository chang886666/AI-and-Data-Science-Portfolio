import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder

from sklearn.ensemble import RandomForestClassifier

from sklearn.metrics import f1_score


class HistoricallyFloodedModel:
    """
    Random Forest pipeline for imbalanced historic flood classification.

    - Preprocessing: numeric(median+standardize), categorical(constant+one-hot)
    - Optimization: thresholding tuning
    - Output: boolean pd.Series indexed by input postcodes

    Required columns (train): ["easting", "northing", "elevation", "soilType"
                               "distanceToWatercourse", "localAuthority",
                               "historicallyFlooded"]
    Required columns (predict source): "postcode" + features above
    """

    def __init__(self, objective="f1"):
        self.objective = objective
        self.model = None
        self.preprocessor = None
        self.best_threshold = 0.5

    def fit(self, df):
        """
        - Splits data with stratification and train the models
        - Scan thresholds within the set range and store

        Parameters
        - df: pd.DataFrame with required feature and target columns.

        Returns
        - self
        """
        feature_cols = [
            "easting",
            "northing",
            "elevation",
            "distanceToWatercourse",
            "soilType",
            "localAuthority",
        ]
        target_col = "historicallyFlooded"

        X = df[feature_cols]
        y = df[target_col]

        X_tr, X_val, y_tr, y_val = train_test_split(
            X, y, test_size=0.3, random_state=42, stratify=y
        )

        num_features = ["easting", "northing", "elevation",
                        "distanceToWatercourse"]
        cat_features = ["soilType", "localAuthority"]

        num_pipe = Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler())
        ])

        cat_pipe = Pipeline([
            ("imputer", SimpleImputer(strategy="constant",
                                      fill_value="missing")),
            ("onehot", OneHotEncoder(handle_unknown="ignore"))
        ])

        self.preprocessor = ColumnTransformer([
            ("num", num_pipe, num_features),
            ("cat", cat_pipe, cat_features),
        ])

        self.model = RandomForestClassifier(
            n_estimators=1000,
            max_depth=800,
            max_features="sqrt",
            class_weight="balanced",
            random_state=42,
            n_jobs=-1
        )

        pipe = Pipeline([
            ("preprocessor", self.preprocessor),
            ("clf", self.model),
        ])

        pipe.fit(X_tr, y_tr)

        probas = pipe.predict_proba(X_val)[:, 1]

        best_f1 = -1
        best_t = 0.5

        for t in np.linspace(0.05, 0.95, 100):
            preds = (probas >= t).astype(int)
            f1 = f1_score(y_val, preds)
            if f1 > best_f1:
                best_f1 = f1
                best_t = t

        self.best_threshold = best_t

        self.pipeline = pipe
        return self

    def predict(self, postcodes, postcodedb=None):
        """
        - Look up features in `postcodedb` (indexed by "postcode")
        - Compute positive-class probabilities via the fitted pipeline
        - Apply the tuned threshold to predict

        Parameters
        - postcodes: list-like of str
        - postcodedb: pd.DataFrame with "postcode" and required feature columns
        """
        db = postcodedb.set_index("postcode")
        X = db.loc[postcodes]

        prob = self.pipeline.predict_proba(X)[:, 1]
        pred = (prob >= self.best_threshold)

        return pd.Series(pred, index=postcodes, name="historicallyFlooded")
