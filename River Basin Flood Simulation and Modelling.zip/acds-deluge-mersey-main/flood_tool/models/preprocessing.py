import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin

from flood_tool.geo import get_gps_lat_long_from_easting_northing
from flood_tool.geo import haversine_distance


class FeatureEngineeringTransformer(BaseEstimator, TransformerMixin):
    """
    Custom transformer that performs:
      - Convert eastings/northings to lat/lon
      - Compute nearest station distance
      - Compute river amplitude features
    """

    def __init__(self, stations_df: pd.DataFrame):
        self.stations_df = stations_df.dropna(
            subset=["latitude", "longitude"]
        ).copy()

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        X = X.copy()

        # 1. Lat/lon conversion
        if "latitude" not in X or "longitude" not in X:
            E = pd.to_numeric(X["easting"], errors="coerce")
            N = pd.to_numeric(X["northing"], errors="coerce")

            lat = np.full(len(X), np.nan)
            lon = np.full(len(X), np.nan)

            mask = E.notna() & N.notna()
            lat_m, lon_m = get_gps_lat_long_from_easting_northing(
                E[mask].values, N[mask].values, rads=False, dtype=np.float64
            )
            lat[mask] = lat_m
            lon[mask] = lon_m

            X["latitude"] = lat
            X["longitude"] = lon

        # 2. Compute distances to stations
        post_lats = X["latitude"].to_numpy()
        post_lons = X["longitude"].to_numpy()

        stat_lats = self.stations_df["latitude"].to_numpy()
        stat_lons = self.stations_df["longitude"].to_numpy()

        dist_matrix = haversine_distance(
            lat1=post_lats,
            long1=post_lons,
            lat2=stat_lats,
            long2=stat_lons,
            deg=True
        )

        nearest_idx = dist_matrix.argmin(axis=0)
        nearest_dist = dist_matrix.min(axis=0)

        X["distanceToStation"] = nearest_dist/1000.0  # km

        # 3. Compute river amplitude features
        X["minMaxAmplitude"] = (
            self.stations_df["maxOnRecord"].iloc[nearest_idx].values
            - self.stations_df["minOnRecord"].iloc[nearest_idx].values
        )

        X["typicalRangeAmplitude"] = (
            self.stations_df["typicalRangeHigh"].iloc[nearest_idx].values
            - self.stations_df["typicalRangeLow"].iloc[nearest_idx].values
        )

        return X
