# References
NumPy Documentation
Referenced for array operations, numerical manipulation, masking logic, and handling NaN values across all transformers and model pipelines.

Pandas Documentation
Used extensively for DataFrame transformation, type coercion, missing-value handling, column creation, and intermediate feature engineering, especially in
FeatureEngineeringTransformer.transform().

Scikit-Learn Documentation
Used for:
Custom transformers (BaseEstimator, TransformerMixin)
Machine-learning pipeline design (Pipeline, ColumnTransformer)
Modelling (RandomForestClassifier, RandomForestRegressor)
Imputation (SimpleImputer, KNNImputer)
Feature scaling (StandardScaler, RobustScaler)
Encoding (OneHotEncoder, TargetEncoder where applicable)
Class balancing (compute_class_weight)

These references guided the implementation of:
FeatureEngineeringTransformer
RF_LocalAuthorityModel
RandomForestFloodRiskModel
RF_MedianPriceModel
RandomForestFloodModel
Matplotlib Documentation

Consulted when interpreting optional visualisation outputs.

Domain-Specific Code References
Geospatial Conversion (get_gps_lat_long_from_easting_northing)

Used to convert Easting/Northing to WGS84 latitude/longitude inside FeatureEngineeringTransformer.
Referenced from internal project utilities (flood_tool.geo).

Haversine Distance Function (haversine_distance)

Used to compute nearest monitoring station distance for each postcode.
Referenced from internal project utilities (flood_tool.geo).

Link: https://python-visualization.github.io/folium/latest/user_guide/map.html
Link: https://python-visualization.github.io/folium/latest/user_guide/vector_layers/circle_and_circle_marker.html
in the mapping.py file under flood_tool > visualisation for customising the folium map 
Used to customise the displayed flood map, including base map configuration, CircleMarker styling, popups, and interactive map behaviour.
Map — Folium 0.20.0 documentation

Link: https://webapps.bgs.ac.uk/data/webservices/convertForm.cfm#bngToLatLng for checking lookup longitude and latitude funciton in tool.py
Used to verify the correctness of the BNG-to-Lat/Lng conversion logic in the postcode lookup utility to ensure accurate geospatial mapping.

Link: https://stackoverflow.com/questions/52096050/seaborn-title-position
used to check how to adjust the title vertical position in Seaborn/Matplotlib plots to ensure the figure title does not overlap with the pairplot layout.

Link: # https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.TargetEncoder.html
Used to understand how TargetEncoder can encode categorical features based on the mean of the target (risk label 1–7) with built-in cross-fitting to avoid leakage.

ChatGPT Sessions

The following ChatGPT conversation(s) were used to support understanding of key concepts, debugging, and improving the machine learning workflow.
Relevant sections of the code contain comments referencing the corresponding session.

ChatGPT Session 1 — Machine learning discussion on Flood Risk Label prediction, model structure, and debugging assistance
Link: https://chatgpt.com/share/691f6fc0-7d48-800e-87b3-f28896ea309f
Used to clarify the design of the FloodRiskLabelRegressor class, handling of numeric vs categorical features, the preprocessor pipeline, HGBClassifier configuration, cross-validation strategy, and postcode lookup implementation.

StackOverflow Q&A: Proper way to handle highly imbalanced data for binary classification — Provided community discussions on resampling vs class weights, and practical tips for imbalanced classes.
Link：https://stackoverflow.com/questions/59409967/proper-way-to-handle-highly-imbalanced-data-binary-classification

Berkeley Statistics Technical Report: Title Unknown — Analysis of class imbalance, cost-sensitive learning, and sampling strategies.
Link：https://statistics.berkeley.edu/sites/default/files/tech-reports/666.pdf

Analytics Vidhya Blog: Imbalanced Data Classification — Practical guide discussing SMOTE, under- and over-sampling, and weighting methods.
Link：https://www.analyticsvidhya.com/blog/2017/03/imbalanced-data-classification

ChatGPT Session 2 — Code refactoring discussion
Link: https://chatgpt.com/share/6920398e-617c-8007-a435-f70c29ad4a07
Used to restructure the codebase, improve readability, modularity, and maintainability of model classes and pipelines.

ChatGPT Session 3 — Fix long line formatting issues
Link: https://chatgpt.com/share/692039d3-0fa4-8007-9aaf-6ca4df8c5d36
Used to identify formatting violations, apply PEP8 line-length standards, and correct structural formatting problems.

Seaborn Title Position
The position of my graph title is terrible on this jointplot.

Additional Resources

Imperial College ACDS coursework notes (general guidance).

No videos or additional AI tools were used.