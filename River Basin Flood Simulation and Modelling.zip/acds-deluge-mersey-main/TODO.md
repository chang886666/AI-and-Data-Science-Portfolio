# A Flood Prediction/Visualization Tool

See the [GiHub documentation](https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax#task-lists) for the task list syntax if you choose to use this.

## Description

Flood prediction tool using machine learning for UK [Environment Agency](https://www.gov.uk/government/organisations/environment-agency) data.

### Flood Risk Tool

#### Prediction Models

- [ ] Create models
  - [X] Minimum risk
  - [X] Random classification
  - [X] England median price
  - [X] Modal local authority
- [ ] Decide on best models for defaults.

#### Analysis & Visualisation

- [ ] Analyse example flood risk data
- [ ] Analyse example weather data
- [ ] Display data
- [ ] Access live data
  - [X] Get weather data for a date
- [ ] Combine with prediction models
- [ ] Visualise flood risk

#### Coordinate

- [X] Convert from lat/long to OSGB36
