import sys
import os

# Add the parent directory to the path so that we can import flood_tool
sys.path.insert(0, os.path.abspath(os.path.join(os.curdir, "..")))

project = "Flood Tool"
extensions = ["sphinx.ext.autodoc", "sphinx.ext.napoleon", "numpydoc"]
source_suffix = ".rst"
master_doc = "index"
exclude_patterns = ["_build"]
autoclass_content = "init"
autodoc_typehints = "none"
numpydoc_show_class_members = False
numpydoc_class_members_toctree = False
