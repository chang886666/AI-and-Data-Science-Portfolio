***************************
Visualising Risk & Rainfall
***************************

This project focuses on "Flood Risk Prediction and Visualization," 
building a lightweight decision support tool for UK postcode areas, 
scalable to other countries and administrative units. 
The tool integrates historical/real-time rainfall, river levels, tides, 
topography, population, and asset data into a unified data model, 
outputting clear and interpretable risk indicators presented in 
interactive maps and time series. It is applicable to local governments 
and emergency departments, infrastructure operators, 
insurance and reinsurance companies, communities, and public education.
*Expand this section appropriately to describe the project and your tool.*

Analysis part of visualisation by Hongzhao Yu:

Rainfall forcing is visualised using the supplied “typical” and
“wet” day data.  We compare 24-hour rainfall totals per gauge with
histograms and boxplots, and show an example 15-minute time series
for a representative gauge to illustrate how the wet day differs
from normal conditions.  These plots make the severity and timing of
the wet-day event easy to interpret.

To link rainfall to flood risk, wet-day 24-hour totals are attached
to each postcode via the nearest rain gauge, using station metadata.
At regional level (e.g. local authority), we then plot how mean
wet-day rainfall, mean predicted risk and total expected impact vary
across regions, using a combination of scatter plots and bar charts.
This allows us to identify areas where intense rainfall coincides
with high risk and large potential losses.

The visualiser also includes simple summaries of model outputs: the
distribution of predicted risk scores, the distribution of house
prices, and a scatter plot of risk vs. price with marker size
proportional to expected impact.  These views help to understand how
the model allocates risk across the housing stock.

Finally, several plots compare predictions for locations with and
without recorded historical flooding, both in terms of mean risk and
the full risk distribution.  This provides a basic sanity check on
whether historically flooded locations are systematically assigned
higher risk by the model.  Taken together, the visualisations offer
a concise but coherent picture of where flood risk is greatest, how
it is influenced by heavy rainfall, and how this relates to both
past flood experience and potential economic impact.

Flood risk visualization
========================
The tool provides functions to visualise predicted flood risk across individual
postcodes, sectors, or Local Authority areas. These plots help users understand
the spatial distribution of flood risk and identify high-risk clusters.
outputs:
Scatter maps of predicted risk, coloured by risk band  
Choropleth-style heatmaps aggregated at Local Authority level  
Comparative plots showing predicted vs. historical risk  
Distribution plots showing risk frequency across the dataset  

These visualisations assist with identifying areas that may require emergency
planning or further investigation.

