====================================
Regression and Classification models
====================================

This section introduces all the predictive models implemented in the project, including the flood risk classification model, house price regression model, Local Authority classification model, and historical trend analysis model. Each model includes the following:
Objective Task
Features and Data Sources Used
Introduction to Model Methodology
Performance Evaluation Metrics

Risk Class Prediction Models
============================
This project implements flood risk prediction for the UK postcode, with the target output being
river and ocean flood risk (levels 1–10) and surface water flood risk (levels 1–10).

This project primarily uses a classification model (multi-class classification), including the following methods:

FloodRiskLabelRegressor (Main Model)

---------------------------------

This model is the core model used in this project to predict the flood risk level of the postcode.

Its main features are as follows:

Input: Geographic and hydrological features corresponding to the UK postcode
Output: River flood risk level (1–3), a simplified mapping of the 10-level risk required by the course

The model uses a custom ``FeatureEngineeringTransformer`, 

Easting/Northing → WGS84 latitude/longitude conversion
Haversine distance to the nearest river observation station
River water level amplitude features
Statistical features such as average and maximum rainfall station values
Postcode geographic information (LA, LSOA, regional coding, etc.)
Soil type and elevation (if data is available)

Use a tree-based multi-classifier (such as RandomForest) or

Logistic Regression + One-vs-Rest (depending on your final implementation)

All Zero Risk
-------------

This model assumes all unlabeled flood risk data is near zero risk (band 1), which is the modal class for the data set. Since the dataset is strongly unbalanced, this is significantly more probable for a random class than any other band.

This is a baseline model to compare other more skillful models against. While it achieve a moderately good accuracy, it is not a useful model for risk prediction, and performs poorly on most other metrics, including the scoring metric specified in the instructions.

House Price Prediction Models
=============================
In addition to flood risk classification, this project also includes models that
predict the median house price for an area. These models support downstream
analysis such as estimating the economic exposure associated with flood risk.

All England median
------------------
This baseline model assumes that all house prices can be imputed with the national
median house price for England. It does not incorporate any postcode-level or
geospatial characteristics.

While this model achieves moderate performance on MAE and RMSE metrics due to the
central tendency of the data, it has no predictive skill and cannot capture local
variation in housing markets. It is used purely as a reference to evaluate more
capable models.

This model assumes all house price data can be imputed with the median house price for England. This is a baseline model to compare against. While it achieve a moderate error metric scores, it is not a useful model for risk prediction, and has very little skill.

The exact feature set varies depending on data availability, but typically involves
a combination of:
Geographic attributes  
Local Authority characteristics  
Structural or environmental indicators  
Statistical summaries of nearby postcode areas  

The model can be implemented using a standard regression algorithm such as:
Linear Regression  
Random Forest Regressor  
Gradient Boosting Regressor  
Other tree-based or ensemble methods  

The final model is selected based on performance on validation metrics such as:
Mean Absolute Error (MAE)  
Mean Squared Error (MSE)  
Root Mean Squared Error (RMSE)  

Local Authority Prediction Models
=================================
These models aim to infer the Local Authority associated with a given postcode.
This task is treated as a multi-class classification problem, with potentially
hundreds of possible output classes depending on the dataset.

Modal Local Authority Model
---------------------------
This baseline model assumes that all unlabeled postcodes belong to the most common
(Local Authority) category appearing in the training dataset. While trivial to
implement, this model performs poorly in practice due to the large number of
classes and the highly imbalanced distribution across Local Authorities.

This model uses a machine-learning classifier to predict the Local Authority for a
postcode. The model structure is flexible and may use any standard multi-class
classifier such as:、

Logistic Regression (One-vs-Rest)  
Random Forest Classifier  
Gradient Boosted Trees  
k-Nearest Neighbours (KNN)  

The model may incorporate general features such as:
Postcode structural components (e.g., outward code or sector)  
Geographic coordinates  
Neighbourhood-level aggregated attributes  

Evaluation metrics typically include:
Accuracy  
Macro-averaged F1 score 

This model assumes all unlabeled data belongs to the most common Local Authority in the available training data. This is a baseline model to compare against. In this case, it does not achieve good accuracy and is generally a poor model to use.

