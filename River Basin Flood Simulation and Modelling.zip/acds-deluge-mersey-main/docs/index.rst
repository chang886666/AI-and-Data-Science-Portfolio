################################
The Team X Flood Prediction Tool
################################

This package implements a flood risk prediction, analysis, and visualization toolkit.
It supports postcode-level and local-authority–level flood risk prediction, integrates
Environment Agency rainfall and river data, and provides geospatial utilities for
coordinate conversion and feature engineering.

Installation Instructions
-------------------------

pip install folium
conda create -n acds-mersey python=3.13
conda activate acds-mersey
pip install -e .


Quick Usage guide
-----------------
1. Train and use the flood risk prediction model*
code-block:: python
   from flood_tool.models.flood_ml import FloodRiskLabelRegressor

   model = FloodRiskLabelRegressor()
   model.fit_to_data()   # Load built-in training data
   result = model.predict_flood_class_from_postcode("SW1A 1AA")
   print(result)

2. Convert OSGB36 coordinates to WGS84 (lat/lon)**
code-block:: python
   from flood_tool.geo import convert_osgb36_to_wgs84

   lat, lon = convert_osgb36_to_wgs84(530000, 180000)
   print(lat, lon)

3. Example visualization: river amplitude**
code-block:: python
   from flood_tool.visualization.river import plot_river_amplitude

   plot_river_amplitude("012345")

Further Documentation
---------------------

.. toctree::
   :maxdepth: 2

   data_formats
   models
   coordinates
   visualization


Function APIs
-------------

.. automodule:: flood_tool
  :members:
  :imported-members:


